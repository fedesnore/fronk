// Reuse decoded weight vectors across up to four causal positions.
// Each position retains dot()'s accumulation and reduction order.
template<int P> __attribute__((noinline)) static void dot_panel(
 const uint8_t*p,const float*const x[P],int type,int n,float out[P]){
 __m256 acc[P];for(int t=0;t<P;t++)acc[t]=_mm256_setzero_ps();
 if(type==12){
  for(int b=0;b<n/256;b++,p+=144*block_stride){float d=half(p),dm=half(p+2);
   for(int g=0;g<8;g++){int sc,mi;sm(p+4,g,sc,mi);__m256 scale=_mm256_set1_ps(d*sc),minimum=_mm256_set1_ps(dm*mi);
    for(int k=0;k<32;k+=8){__m128i q=_mm_loadl_epi64((const __m128i*)(p+16+g/2*32+k));if(g%2)q=_mm_srli_epi16(q,4);q=_mm_and_si128(q,_mm_set1_epi8(15));
     __m256 v=_mm256_sub_ps(_mm256_mul_ps(scale,_mm256_cvtepi32_ps(_mm256_cvtepu8_epi32(q))),minimum);
     for(int t=0;t<P;t++)acc[t]=_mm256_fmadd_ps(v,_mm256_loadu_ps(x[t]+b*256+g*32+k),acc[t]);
    }
   }
  }
 }else if(type==39){
  const __m128i lut=_mm_setr_epi8(0,1,2,3,4,6,8,12,0,-1,-2,-3,-4,-6,-8,-12);
  for(int b=0;b<n/32;b++,p+=17*block_stride){__m256 d=_mm256_set1_ps(scale_e(p[0])*.5f);__m128i q=_mm_loadu_si128((const __m128i*)(p+1));
   for(int h=0;h<2;h++){__m128i z=h?_mm_srli_epi16(q,4):q;z=_mm_shuffle_epi8(lut,_mm_and_si128(z,_mm_set1_epi8(15)));
    __m256 lo=_mm256_mul_ps(d,_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(z))),hi=_mm256_mul_ps(d,_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(_mm_srli_si128(z,8))));
    for(int t=0;t<P;t++){acc[t]=_mm256_fmadd_ps(lo,_mm256_loadu_ps(x[t]+b*32+h*16),acc[t]);acc[t]=_mm256_fmadd_ps(hi,_mm256_loadu_ps(x[t]+b*32+h*16+8),acc[t]);}
   }
  }
 }else{for(int t=0;t<P;t++)out[t]=dot(p,x[t],type,n);return;}
 for(int t=0;t<P;t++)out[t]=hsum(acc[t]);
}
static void panel(const uint8_t*p,const float*const*x,int type,int n,int count,float*out){
 switch(count){case 1:out[0]=dot(p,x[0],type,n);break;case 2:dot_panel<2>(p,x,type,n,out);break;case 3:dot_panel<3>(p,x,type,n,out);break;case 4:dot_panel<4>(p,x,type,n,out);break;default:die("panel count");}
}
