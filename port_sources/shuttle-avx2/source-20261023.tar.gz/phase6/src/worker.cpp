// Independent CPU expert engine. Q4_K/MXFP4/Q8_0 layouts follow the documented
// GGUF/DwarfStar formats (upstream MIT notice retained in src/ds4/LICENSE).
// No activation requantization or source-weight approximation is introduced.
#include <immintrin.h>
#include <omp.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <poll.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <sys/mman.h>
#include <stdint.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <map>
#include <chrono>
#include <algorithm>
using clock_tandem=std::chrono::steady_clock;
static uint64_t ns(){return std::chrono::duration_cast<std::chrono::nanoseconds>(clock_tandem::now().time_since_epoch()).count();}
static void die(const char*s){fprintf(stderr,"tandem worker: %s\n",s);exit(2);}
static uint64_t physical_read_bytes(){
 FILE*f=fopen("/proc/self/io","r");if(!f)die("process I/O telemetry");char line[128];unsigned long long value=0;bool found=false;
 while(fgets(line,sizeof(line),f))if(sscanf(line,"read_bytes: %llu",&value)==1){found=true;break;}
 fclose(f);if(!found)die("read_bytes unavailable");return value;
}
static bool io(int fd,void*p,size_t n,bool write){auto*b=(uint8_t*)p;while(n){ssize_t k=write ? ::write(fd,b,n) : ::read(fd,b,n);if(k<=0)return false;b+=k;n-=k;}return true;}
static bool q4_lanes=false;
static unsigned block_stride=1; // 4 in the lossless execution-ready row-tile image
static float half(const uint8_t*p){uint16_t h;memcpy(&h,p,2);return _cvtsh_ss(h);}
static float silu(float g){
 const float e=expf(g>=0.f?-g:g);
 const float sigmoid=g>=0.f?1.f/(1.f+e):e/(1.f+e);
 return g*sigmoid;
}
static float hsum(__m256 x){__m128 a=_mm_add_ps(_mm256_castps256_ps128(x),_mm256_extractf128_ps(x,1));a=_mm_hadd_ps(a,a);a=_mm_hadd_ps(a,a);return _mm_cvtss_f32(a);}
static int rb(int type,int n){return type==12?n/256*144:type==39?n/32*17:type==8?n/32*34:0;}
static uint64_t row_offset(int type,int n,unsigned row){
 const uint64_t stride=rb(type,n);const unsigned unit=type==12?144:type==39?17:34;
 return block_stride==1?uint64_t(row)*stride:uint64_t(row/4)*4*stride+(row%4)*unit;
}
static void sm(const uint8_t*s,int g,int &sc,int &mi){if(g<4){sc=s[g]&63;mi=s[g+4]&63;}else{sc=(s[g+4]&15)|((s[g-4]&192)>>2);mi=(s[g+4]>>4)|((s[g]&192)>>2);}}
static float scale_e(uint8_t e){uint32_t u=e?uint32_t(e)<<23:0x00400000;float f;memcpy(&f,&u,4);return f;}
static const float mx[16]={0,.5,1,1.5,2,3,4,6,-0.,-.5,-1,-1.5,-2,-3,-4,-6};
static float weight(const uint8_t*p,int type,int j){
 if(type==12){p+=j/256*144*block_stride;int g=j%256/32,k=j%32,sc,mi;sm(p+4,g,sc,mi);int q=(p[16+(g/2)*32+(q4_lanes?(k%8)*4+k/8:k)]>>(g%2*4))&15;return half(p)*sc*q-half(p+2)*mi;}
 if(type==39){p+=j/32*17*block_stride;int k=j%32;return scale_e(p[0])*mx[(p[1+k%16]>>(k/16*4))&15];}
 p+=j/32*34*block_stride;return half(p)*(int8_t)p[2+j%32];
}
__attribute__((noinline)) static float dot(const uint8_t*p,const float*x,int type,int n){
 __m256 sum=_mm256_setzero_ps();
 if(type==12){
  for(int b=0;b<n/256;b++,p+=144*block_stride){float d=half(p),dm=half(p+2);
   for(int g=0;g<8;g++){int sc,mi;sm(p+4,g,sc,mi);__m256 s=_mm256_set1_ps(d*sc),m=_mm256_set1_ps(dm*mi);
    for(int k=0;k<32;k+=8){__m128i q=_mm_loadl_epi64((const __m128i*)(p+16+g/2*32+k));q=g%2?_mm_srli_epi16(q,4):q;q=_mm_and_si128(q,_mm_set1_epi8(15));__m256 v=_mm256_cvtepi32_ps(_mm256_cvtepu8_epi32(q));v=_mm256_sub_ps(_mm256_mul_ps(s,v),m);sum=_mm256_fmadd_ps(v,_mm256_loadu_ps(x+b*256+g*32+k),sum);}
   }
  }
 }else if(type==39){
  const __m128i lut=_mm_setr_epi8(0,1,2,3,4,6,8,12,0,-1,-2,-3,-4,-6,-8,-12);
  for(int b=0;b<n/32;b++,p+=17*block_stride){__m256 d=_mm256_set1_ps(scale_e(p[0])*.5f);__m128i q=_mm_loadu_si128((const __m128i*)(p+1));
   for(int h=0;h<2;h++){__m128i z=h?_mm_srli_epi16(q,4):q;z=_mm_shuffle_epi8(lut,_mm_and_si128(z,_mm_set1_epi8(15)));
    __m256 lo=_mm256_mul_ps(d,_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(z)));__m256 hi=_mm256_mul_ps(d,_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(_mm_srli_si128(z,8))));
    sum=_mm256_fmadd_ps(lo,_mm256_loadu_ps(x+b*32+h*16),sum);sum=_mm256_fmadd_ps(hi,_mm256_loadu_ps(x+b*32+h*16+8),sum);
   }
  }
 }else{
  for(int b=0;b<n/32;b++,p+=34*block_stride){__m256 d=_mm256_set1_ps(half(p));for(int k=0;k<32;k+=8){__m256 q=_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(_mm_loadl_epi64((const __m128i*)(p+2+k))));sum=_mm256_fmadd_ps(_mm256_mul_ps(d,q),_mm256_loadu_ps(x+b*32+k),sum);}}
 }
 return hsum(sum);
}
#include "q21.h"
#include "row4.h"
#include "panel4.h"
#include "metal32.h"
#pragma pack(push,1)
struct Entry{uint64_t key;uint32_t expert,type[3];uint64_t off[3];};
struct Request{uint32_t magic,count,E,F,T,reserved;uint64_t seq;};
struct Job{uint64_t key;uint32_t expert,slot;};
struct Reply{uint32_t magic,count;uint64_t seq,compute_ns,begin_ns,end_ns;};
#pragma pack(pop)
int main(int argc,char**argv){
 const bool metal32=getenv("TANDEM_KERNEL")&&!strcmp(getenv("TANDEM_KERNEL"),"metal32");
 const bool panels=getenv("TANDEM_KERNEL")&&!strcmp(getenv("TANDEM_KERNEL"),"panel4");
 const bool rows4=getenv("TANDEM_KERNEL")&&!strcmp(getenv("TANDEM_KERNEL"),"row4");
 const bool use21=getenv("TANDEM_ARITH")&&!strcmp(getenv("TANDEM_ARITH"),"q21");
 if(argc<2)die("image required");
 FILE*f=fopen(argv[1],"rb");if(!f)die("image open");
 char magic[8];uint32_t count,E;uint64_t F; if(fread(magic,8,1,f)!=1||(memcmp(magic,"QWTAND01",8)&&memcmp(magic,"QWTAND04",8)&&memcmp(magic,"QWTAND32",8))||fread(&count,4,1,f)!=1||fread(&E,4,1,f)!=1||fread(&F,8,1,f)!=1||count>24576+48||E!=2560||F!=640)die("bad image header");
 block_stride=!memcmp(magic,"QWTAND04",8)?4:1;
 q4_lanes=!memcmp(magic,"QWTAND32",8);if(q4_lanes&&(!metal32||use21))die("lane image requires metal32 kernel");
 if(block_stride==4&&use21)die("row-tile image requires FP32 activation kernel");
 std::vector<Entry> entries(count);if(fread(entries.data(),sizeof(Entry),count,f)!=count)die("entries");long base=(ftell(f)+63)/64*64;fseek(f,0,SEEK_END);long total=ftell(f);if(total<base)die("size");fseek(f,base,SEEK_SET);
 // Optional dedicated data plane. SSH carries only launch/supervision and
 // the ephemeral 256-bit capability. The listener is bound to the existing
 // direct-link address and accepts one authenticated connection, then closes.
 if(argc>2&&!strcmp(argv[2],"--socket")){
  uint8_t secret[32];int random=open("/dev/urandom",O_RDONLY);if(random<0||!io(random,secret,sizeof(secret),false))die("socket entropy");close(random);
  int server=socket(AF_INET,SOCK_STREAM,0);if(server<0)die("socket");
  sockaddr_in addr{};addr.sin_family=AF_INET;addr.sin_port=0;if(inet_pton(AF_INET,"10.10.10.2",&addr.sin_addr)!=1||bind(server,(sockaddr*)&addr,sizeof(addr))||listen(server,1))die("direct-link listener");
  socklen_t size=sizeof(addr);if(getsockname(server,(sockaddr*)&addr,&size))die("listener port");uint32_t bootstrap[2]={0x43505751,ntohs(addr.sin_port)};
  if(!io(1,bootstrap,sizeof(bootstrap),true)||!io(1,secret,sizeof(secret),true))die("bootstrap");
  pollfd waiting{server,POLLIN,0};if(poll(&waiting,1,15000)<=0)die("socket connect deadline");
  int client=accept(server,nullptr,nullptr);close(server);if(client<0)die("socket accept");
  timeval timeout{15,0};setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));int yes=1;if(setsockopt(client,IPPROTO_TCP,TCP_NODELAY,&yes,sizeof(yes)))die("TCP_NODELAY");
  uint8_t offered[32];if(!io(client,offered,sizeof(offered),false))die("socket authentication read");unsigned mismatch=0;for(unsigned i=0;i<32;i++)mismatch|=offered[i]^secret[i];if(mismatch)die("socket authentication");
  memset(secret,0,sizeof(secret));memset(offered,0,sizeof(offered));
  timeout={0,0};if(setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout)))die("session receive timeout");
  if(dup2(client,0)<0||dup2(client,1)<0)die("socket bind descriptors");if(client>1)close(client);
  fprintf(stderr,"{\"transport\":\"direct_tcp_capability_authenticated\",\"listener_closed_after_accept\":true}\n");
 }
 const uint64_t load_reads=physical_read_bytes(),load_begin=ns();
 void *mapping=mmap(nullptr,total,PROT_READ,MAP_PRIVATE,fileno(f),0);if(mapping==MAP_FAILED)die("mmap");
 struct WeightView{uint8_t*p;size_t n;uint8_t*data(){return p;}size_t size(){return n;}} weights{(uint8_t*)mapping+base,(size_t)(total-base)};
 // File-backed, read-only residency avoids a second anonymous full-image copy.
 // Explicit prefault and mincore audit happen before the handshake/timed work.
 volatile uint8_t checksum=0;
 for(size_t off=0;off<(size_t)total;off+=4u<<20){size_t n=std::min<size_t>(4u<<20,total-off);madvise((uint8_t*)mapping+off,n,MADV_WILLNEED);for(size_t j=0;j<n;j+=4096)checksum^=((const uint8_t*)mapping)[off+j];}
 (void)checksum;std::vector<unsigned char> residency((total+4095)/4096);if(mincore(mapping,total,residency.data()))die("mincore");size_t present=0;for(auto v:residency)present+=v&1;if(present!=residency.size())die("image not fully resident after prefault");
 fprintf(stderr,"{\"resident_image_bytes\":%ld,\"resident_pages\":%zu,\"total_pages\":%zu}\n",total,present,residency.size());fclose(f);
 const uint64_t initial_reads=physical_read_bytes();
 fprintf(stderr,"{\"prefault_wall_ns\":%llu,\"prefault_physical_read_bytes\":%llu}\n",(unsigned long long)(ns()-load_begin),(unsigned long long)(initial_reads-load_reads));
 rusage initial_usage;getrusage(RUSAGE_SELF,&initial_usage);
 std::map<std::pair<uint64_t,uint32_t>,int> lookup;
 for(unsigned i=0;i<count;i++){auto&e=entries[i];for(int j=0;j<3;j++){uint64_t bytes=uint64_t(rb(e.type[j],j==2?F:E))*(j==2?E:F);if(!bytes||e.off[j]+bytes>weights.size())die("bad tensor");}if(!lookup.emplace(std::make_pair(e.key,e.expert),i).second)die("duplicate");}
 omp_set_dynamic(0);omp_set_num_threads(getenv("TANDEM_THREADS")?atoi(getenv("TANDEM_THREADS")):8);
 if(argc>2&&!strcmp(argv[2],"--test")){
  std::vector<float>x(E),prepared(E);std::vector<Q21>qx(E/32);for(unsigned i=0;i<E;i++)x[i]=sinf(i*.31f)*.4f;quant21(x.data(),qx.data(),E);double worst=0,sumerr=0,sumref=0;uint64_t checks=0,row4_checks=0;
  for(auto&e:entries)for(int role=0;role<3;role++){int n=role==2?F:E,rows=role==2?E:F;for(int r=0;r<rows;r+=31){auto*p=weights.data()+e.off[role]+row_offset(e.type[role],n,r);double ref=0;for(int j=0;j<n;j++)ref+=(double)weight(p,e.type[role],j)*x[j];if(metal32)prepare32(x.data(),prepared.data(),e.type[role],n);float v=metal32?dot_metal32(p,prepared.data(),e.type[role],n):use21?dot21(p,qx.data(),e.type[role],n):dot(p,x.data(),e.type[role],n);double err=v-ref;worst=std::max(worst,fabs(err));sumerr+=err*err;sumref+=ref*ref;checks++;}}
  if(!q4_lanes)for(auto&e:entries)for(int role=0;role<3;role++){
   const int n=role==2?F:E,rows=role==2?E:F;
   for(int r=0;r+3<rows;r+=124){const uint8_t*ptr[4];float v[4];for(int k=0;k<4;k++)ptr[k]=weights.data()+e.off[role]+row_offset(e.type[role],n,r+k);dot4(ptr,x.data(),e.type[role],n,v);
    for(int k=0;k<4;k++){float ref=dot(ptr[k],x.data(),e.type[role],n);if(memcmp(&v[k],&ref,4))die("row4 differs from original float accumulation");row4_checks++;}
   }
  }
  fprintf(stderr,"{\"row4_bitexact_checks\":%llu}\n",(unsigned long long)row4_checks);
  printf("{\"checks\":%llu,\"max_abs\":%.9g,\"relative_l2\":%.9g}\n",(unsigned long long)checks,worst,sqrt(sumerr/sumref));return sqrt(sumerr/sumref)>1e-5;
 }
 uint32_t hello[4]={0x32545751,count,E,(uint32_t)F};if(!io(1,hello,sizeof(hello),true)||!io(1,entries.data(),entries.size()*sizeof(Entry),true))die("hello");
 std::vector<float>xp(32*E),mp(352*F);
 std::vector<float>x(32*E),mid(352*F),out(352*E),aggregate(32*E),routing(352);std::vector<Q21>qx(32*E/32),qm(352*F/32);Job jobs[352];int indices[352];uint64_t calls=0,computed=0,start=ns();
 while(true){Request req;if(!io(0,&req,sizeof(req),false))break;if(req.magic!=0x32545751||req.count>352||req.E!=E||req.F!=F||!req.T||req.T>32||req.reserved>1)die("request bounds");if(!req.count){uint64_t t=ns();Reply pong={0x32545751,0,req.seq,0,t,t};if(!io(1,&pong,sizeof(pong),true))die("ping");continue;}if(!io(0,jobs,req.count*sizeof(Job),false)||!io(0,x.data(),req.T*E*4,false))die("truncated request");for(unsigned i=0;i<req.T*E;i++)if(!std::isfinite(x[i]))die("nonfinite activation");
  if(req.reserved){if(!io(0,routing.data(),req.count*4,false))die("truncated routing weights");for(unsigned j=0;j<req.count;j++)if(!std::isfinite(routing[j]))die("nonfinite router weight");}
  for(unsigned j=0;j<req.count;j++){if(jobs[j].slot>=req.T*11||jobs[j].slot%11>=10)die("job slot bounds");auto it=lookup.find({jobs[j].key,jobs[j].expert});if(it==lookup.end())die("unowned expert");indices[j]=it->second;}
  struct Group{int index,count,jobs[4];};Group groups[352];unsigned group_count=0;
  if(panels&&req.T>1){
   int order[352];for(unsigned j=0;j<req.count;j++)order[j]=j;
   std::sort(order,order+req.count,[&](int a,int b){return indices[a]<indices[b]||(indices[a]==indices[b]&&a<b);});
   for(unsigned k=0;k<req.count;k++){int j=order[k];if(!group_count||groups[group_count-1].index!=indices[j]||groups[group_count-1].count==4)groups[group_count++]={indices[j],0,{0,0,0,0}};Group&g=groups[group_count-1];g.jobs[g.count++]=j;}
  }
  uint64_t begin=ns();if(metal32)for(unsigned t=0;t<req.T;t++)prepare32(x.data()+t*E,xp.data()+t*E,12,E);if(use21)quant21(x.data(),qx.data(),req.T*E);
  #pragma omp parallel
  {
   if(metal32){
    #pragma omp for schedule(static)
    for(unsigned jr=0;jr<req.count*F;jr++){
     unsigned j=jr/F,r=jr%F,t=jobs[j].slot/11;auto&e=entries[indices[j]];
     float g=dot_metal32(weights.data()+e.off[0]+row_offset(e.type[0],E,r),xp.data()+t*E,e.type[0],E),u=dot_metal32(weights.data()+e.off[1]+row_offset(e.type[1],E,r),xp.data()+t*E,e.type[1],E);mid[jr]=silu(g)*u;
    }
    #pragma omp for schedule(static)
    for(unsigned j=0;j<req.count;j++)prepare32(mid.data()+j*F,mp.data()+j*F,39,F);
    #pragma omp for schedule(static)
    for(unsigned jr=0;jr<req.count*E;jr++){
     unsigned j=jr/E,r=jr%E;auto&e=entries[indices[j]];out[jr]=dot_metal32(weights.data()+e.off[2]+row_offset(e.type[2],F,r),mp.data()+j*F,e.type[2],F);
    }
   }else if(group_count&&!use21){
    #pragma omp for schedule(static)
    for(unsigned gr=0;gr<group_count*F;gr++){
     Group&g=groups[gr/F];unsigned r=gr%F;auto&e=entries[g.index];const float*inputs[4];for(int t=0;t<g.count;t++)inputs[t]=x.data()+(jobs[g.jobs[t]].slot/11)*E;
     float gate[4],up[4];panel(weights.data()+e.off[0]+row_offset(e.type[0],E,r),inputs,e.type[0],E,g.count,gate);panel(weights.data()+e.off[1]+row_offset(e.type[1],E,r),inputs,e.type[1],E,g.count,up);
     for(int t=0;t<g.count;t++)mid[g.jobs[t]*F+r]=silu(gate[t])*up[t];
    }
    #pragma omp for schedule(static)
    for(unsigned gr=0;gr<group_count*E;gr++){
     Group&g=groups[gr/E];unsigned r=gr%E;auto&e=entries[g.index];const float*inputs[4];for(int t=0;t<g.count;t++)inputs[t]=mid.data()+g.jobs[t]*F;
     float values[4];panel(weights.data()+e.off[2]+row_offset(e.type[2],F,r),inputs,e.type[2],F,g.count,values);
     for(int t=0;t<g.count;t++)out[g.jobs[t]*E+r]=values[t];
    }
   }else if(rows4&&!use21){
    #pragma omp for schedule(static)
    for(unsigned tile=0;tile<req.count*F/2;tile++){
     unsigned j=tile/(F/2),r=(tile%(F/2))*2,t=jobs[j].slot/11;auto&e=entries[indices[j]];
     if(e.type[0]!=e.type[1])die("GU quantization mismatch");
     const uint8_t *ptr[4]={weights.data()+e.off[0]+row_offset(e.type[0],E,r),weights.data()+e.off[1]+row_offset(e.type[0],E,r),weights.data()+e.off[0]+row_offset(e.type[0],E,r+1),weights.data()+e.off[1]+row_offset(e.type[0],E,r+1)};
     float v[4];dot4(ptr,x.data()+t*E,e.type[0],E,v);
     mid[j*F+r]=silu(v[0])*v[1];mid[j*F+r+1]=silu(v[2])*v[3];
    }
    #pragma omp for schedule(static)
    for(unsigned tile=0;tile<req.count*E/4;tile++){
     unsigned j=tile/(E/4),r=(tile%(E/4))*4;auto&e=entries[indices[j]];
     const uint8_t*ptr[4];for(int k=0;k<4;k++)ptr[k]=weights.data()+e.off[2]+row_offset(e.type[2],F,r+k);
     dot4(ptr,mid.data()+j*F,e.type[2],F,out.data()+j*E+r);
    }
   }else{
    #pragma omp for schedule(static)
    for(unsigned jr=0;jr<req.count*F;jr++){unsigned j=jr/F,r=jr%F;auto&e=entries[indices[j]];const uint8_t *gp=weights.data()+e.off[0]+row_offset(e.type[0],E,r),*up=weights.data()+e.off[1]+row_offset(e.type[1],E,r);const unsigned t=jobs[j].slot/11;float g=use21?dot21(gp,qx.data()+t*E/32,e.type[0],E):dot(gp,x.data()+t*E,e.type[0],E);float u=use21?dot21(up,qx.data()+t*E/32,e.type[1],E):dot(up,x.data()+t*E,e.type[1],E);mid[jr]=silu(g)*u;}
    #pragma omp for schedule(static)
    for(unsigned b=0;b<req.count*F/32;b++)if(use21)quant21(mid.data()+b*32,qm.data()+b,32);
    #pragma omp for schedule(static)
    for(unsigned jr=0;jr<req.count*E;jr++){unsigned j=jr/E,r=jr%E;auto&e=entries[indices[j]];const uint8_t *dp=weights.data()+e.off[2]+row_offset(e.type[2],F,r);out[jr]=use21?dot21(dp,qm.data()+j*F/32,e.type[2],F):dot(dp,mid.data()+j*F,e.type[2],F);}
   }
  }
  if(req.reserved){
   std::fill(aggregate.begin(),aggregate.begin()+req.T*E,0.f);
   for(unsigned j=0;j<req.count;j++){
    float *sum=aggregate.data()+(jobs[j].slot/11)*E;const float*src=out.data()+j*E;__m256 w=_mm256_set1_ps(routing[j]);
    for(unsigned i=0;i<E;i+=8)_mm256_storeu_ps(sum+i,_mm256_fmadd_ps(w,_mm256_loadu_ps(src+i),_mm256_loadu_ps(sum+i)));
   }
  }
  uint64_t elapsed=ns()-begin;Reply rep={0x32545751,req.count,req.seq,elapsed,begin,begin+elapsed};if(!io(1,&rep,sizeof(rep),true)||!io(1,req.reserved?aggregate.data():out.data(),(req.reserved?req.T:req.count)*E*4,true))die("reply");calls++;computed+=elapsed;
 }
 if(mincore(mapping,total,residency.data()))die("final residency audit");present=0;for(auto v:residency)present+=v&1;
 fprintf(stderr,"{\"final_resident_pages\":%zu,\"total_image_pages\":%zu}\n",present,residency.size());
 rusage ru;getrusage(RUSAGE_SELF,&ru);fprintf(stderr,"{\"worker_calls\":%llu,\"compute_ns\":%llu,\"wall_ns\":%llu,\"maxrss_kib\":%ld,\"image_bytes\":%ld,\"user_s\":%.6f,\"system_s\":%.6f}\n",(unsigned long long)calls,(unsigned long long)computed,(unsigned long long)(ns()-start),ru.ru_maxrss,total,(ru.ru_utime.tv_sec-initial_usage.ru_utime.tv_sec)+(ru.ru_utime.tv_usec-initial_usage.ru_utime.tv_usec)*1e-6,(ru.ru_stime.tv_sec-initial_usage.ru_stime.tv_sec)+(ru.ru_stime.tv_usec-initial_usage.ru_stime.tv_usec)*1e-6);
 fprintf(stderr,"{\"execution_physical_read_bytes\":%llu}\n",(unsigned long long)(physical_read_bytes()-initial_reads));
 fprintf(stderr,"{\"execution_major_faults\":%ld,\"execution_minor_faults\":%ld}\n",ru.ru_majflt-initial_usage.ru_majflt,ru.ru_minflt-initial_usage.ru_minflt);
}
