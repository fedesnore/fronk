#!/bin/sh
set -eu
cd /home/netlab/shuttle-accelerator
mkdir -p r4/native/build
test ! -e r4/native/build/libnative-q4-fixed-v2.so
exec g++ -O3 -std=c++17 -mavx2 -mfma -mf16c -fopenmp -ffp-contract=off -fPIC -shared r4/native/src/native_fixed_v2.cpp -o r4/native/build/libnative-q4-fixed-v2.so
