#pragma once
// Same Q4_K values and FP32 reduction as the retained phase6 panel. The only
// new mechanism is compile-time group selection; no execution-image expansion.
template<int P, int G> __attribute__((always_inline)) static inline void r4_group(
    const uint8_t *p, const float *const *x, int offset, float d, float dm,
    __m256 (&acc)[P]) {
    int sc, mi;
    sm(p+4,G,sc,mi);
    const __m256 scale=_mm256_set1_ps(d*sc), minimum=_mm256_set1_ps(dm*mi);
    for(int k=0;k<32;k+=8) {
        __m128i q=_mm_loadl_epi64((const __m128i *)(p+16+(G/2)*32+k));
        if constexpr(G&1) q=_mm_srli_epi16(q,4);
        q=_mm_and_si128(q,_mm_set1_epi8(15));
        const __m256 v=_mm256_sub_ps(_mm256_mul_ps(scale,
            _mm256_cvtepi32_ps(_mm256_cvtepu8_epi32(q))),minimum);
        for(int t=0;t<P;++t)
            acc[t]=_mm256_fmadd_ps(v,_mm256_loadu_ps(x[t]+offset+G*32+k),acc[t]);
    }
}
template<int P> __attribute__((noinline)) static void r4_q4(
    const uint8_t *p,const float *const *x,int n,float *out) {
    __m256 acc[P];for(int t=0;t<P;++t)acc[t]=_mm256_setzero_ps();
    for(int b=0;b<n/256;++b,p+=144) {
        const float d=half(p),dm=half(p+2);
        r4_group<P,0>(p,x,b*256,d,dm,acc);
        r4_group<P,1>(p,x,b*256,d,dm,acc);
        r4_group<P,2>(p,x,b*256,d,dm,acc);
        r4_group<P,3>(p,x,b*256,d,dm,acc);
        r4_group<P,4>(p,x,b*256,d,dm,acc);
        r4_group<P,5>(p,x,b*256,d,dm,acc);
        r4_group<P,6>(p,x,b*256,d,dm,acc);
        r4_group<P,7>(p,x,b*256,d,dm,acc);
    }
    for(int t=0;t<P;++t)out[t]=hsum(acc[t]);
}
static float r4_dot(const uint8_t *p,const float *x,int type,int n) {
    if(type!=12)return dot(p,x,type,n);
    const float *inputs[]={x};float out;
    r4_q4<1>(p,inputs,n,&out);return out;
}
template<int P> static void r4_dot_panel(const uint8_t *p,const float *const *x,
                                       int type,int n,float *out) {
    if(type==12)r4_q4<P>(p,x,n,out);
    else dot_panel<P>(p,x,type,n,out);
}
static void r4_panel(const uint8_t *p,const float *const *x,int type,int n,
                     int count,float *out) {
    if(type!=12){panel(p,x,type,n,count,out);return;}
    switch(count){
        case 1:r4_q4<1>(p,x,n,out);break;
        case 2:r4_q4<2>(p,x,n,out);break;
        case 3:r4_q4<3>(p,x,n,out);break;
        case 4:r4_q4<4>(p,x,n,out);break;
        default:die("R4 retained serial panel bound");
    }
}
