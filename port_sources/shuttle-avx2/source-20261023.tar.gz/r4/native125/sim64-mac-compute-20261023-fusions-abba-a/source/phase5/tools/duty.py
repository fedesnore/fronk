#!/usr/bin/env python3
"""Pace a compiler process tree with POSIX stop/continue, in the guard's group.

No new process group/session is created, so the outer guard retains authority to
terminate every descendant. Only compilation uses this; never timed inference.
"""
import os,pathlib,signal,subprocess,sys,time
args=sys.argv[1:]
if args and args[0]=='--':args=args[1:]
assert args and pathlib.Path(args[0]).name in ['g++','gcc'], 'compiler commands only'
p=subprocess.Popen(args);stopped=set()
def tree(pid):
 children=[]
 try:ids=[int(x) for x in pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except OSError:ids=[]
 for child in ids:children.extend(tree(child))
 return children+[pid]
def resume():
 for pid in list(stopped):
  try:os.kill(pid,signal.SIGCONT)
  except ProcessLookupError:pass
 stopped.clear()
def terminate(signum,frame):
 for pid in tree(p.pid):
  try:os.kill(pid,signal.SIGTERM)
  except ProcessLookupError:pass
 resume();raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
try:
 while p.poll() is None:
  time.sleep(.010)
  for pid in tree(p.pid):
   try:os.kill(pid,signal.SIGSTOP);stopped.add(pid)
   except ProcessLookupError:pass
  time.sleep(.090);resume()
finally:resume()
raise SystemExit(p.wait())
