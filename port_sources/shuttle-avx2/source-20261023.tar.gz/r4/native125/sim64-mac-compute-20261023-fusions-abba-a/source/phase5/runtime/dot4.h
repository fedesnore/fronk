// Four output rows share activation loads and broadcasts. Weights stay packed.
static inline __m256 dot4_acc(const Q4&w,__m256i x0,__m256i x1,__m256i correction,float xd,__m256 acc){
 const __m256i mask=_mm256_set1_epi8(15),ones=_mm256_set1_epi16(1);
 __m256i q=_mm256_loadu_si256((const __m256i*)w.q);
 __m256i p=_mm256_maddubs_epi16(_mm256_and_si256(q,mask),x0);
 __m256i r=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,4),mask),x1);
 __m256i v=_mm256_sub_epi32(_mm256_madd_epi16(_mm256_add_epi16(p,r),ones),correction);
 return _mm256_fmadd_ps(_mm256_cvtepi32_ps(v),_mm256_set1_ps(w.d*xd),acc);
}
static inline void dot4(const Q4*w,const X8*x,int groups,float*out){
 __m256 a=_mm256_setzero_ps(),b=a,c=a,d=a;
 for(int g=0;g<groups;g++){
  __m256i x0=_mm256_loadu_si256((const __m256i*)x[g].q),x1=_mm256_loadu_si256((const __m256i*)(x[g].q+32)),s=_mm256_set1_epi32(x[g].sum);
  a=dot4_acc(w[g],x0,x1,s,x[g].d,a);b=dot4_acc(w[groups+g],x0,x1,s,x[g].d,b);
  c=dot4_acc(w[2*groups+g],x0,x1,s,x[g].d,c);d=dot4_acc(w[3*groups+g],x0,x1,s,x[g].d,d);
 }
 out[0]=sum8(a);out[1]=sum8(b);out[2]=sum8(c);out[3]=sum8(d);
}
