#!/usr/bin/env python3
"""Bounded user-process runner; reads telemetry and never writes hardware controls."""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import shutil
import socket
import subprocess
import sys
import time


class Telemetry:
    def __init__(self, root=Path("/")):
        self.root = root
        self.temps = []
        self.limits = {}
        for hw in (root / "sys/class/hwmon").glob("hwmon*"):
            if (hw / "name").read_text().strip() != "coretemp":
                continue
            for path in hw.glob("temp*_input"):
                self.temps.append(path)
                crit = int(path.with_name(path.name.replace("input", "crit")).read_text()) / 1000
                self.limits[str(path)] = min(80.0, crit - 20.0)
        self.storage_temps = []
        for hw in (root / "sys/class/hwmon").glob("hwmon*"):
            if (hw / "name").read_text().strip() != "nvme":
                continue
            for path in hw.glob("temp*_input"):
                self.storage_temps.append(path)
                maximum = path.with_name(path.name.replace("input", "max"))
                limit = int(maximum.read_text()) / 1000 - 10 if maximum.exists() else 65.0
                self.limits[str(path)] = min(65.0, limit)
        if not self.storage_temps:
            raise RuntimeError("required NVMe temperature telemetry absent")
        cpu = root / "sys/devices/system/cpu"
        self.throttle = sorted(cpu.glob("cpu[0-9]*/thermal_throttle/*throttle_count"))
        self.freq = sorted(cpu.glob("cpu[0-9]*/cpufreq/scaling_cur_freq"))
        self.gpu = sorted((root / "sys/class/drm").glob("card[0-9]/gt_act_freq_mhz"))
        if not self.temps or not self.throttle or not self.freq:
            raise RuntimeError("required coretemp, thermal-throttle counters or frequency indicators absent")

    def sample(self):
        def values(paths, divisor=1):
            return {str(p): int(p.read_text()) / divisor for p in paths}
        mem = dict((line.split(':')[0], int(line.split()[1])) for line in
                   (self.root / "proc/meminfo").read_text().splitlines()
                   if line.startswith(("MemAvailable:", "SwapFree:")))
        return {"monotonic": time.monotonic(), "temp_c": values(self.temps, 1000), "storage_temp_c": values(self.storage_temps, 1000),
                "cpu_scaling_mhz_indicator": values(self.freq, 1000),
                "gpu_act_mhz": values(self.gpu), "throttle_counts": values(self.throttle),
                "mem_kib": mem}

    def violation(self, sample, initial, starting=False):
        for path, temp in sample["temp_c"].items():
            limit = min(65.0, self.limits[path]) if starting else self.limits[path]
            if not math.isfinite(temp) or temp < 0 or temp >= limit:
                return f"temperature {temp} C reaches guard {limit} C: {path}"
        for path, temp in sample["storage_temp_c"].items():
            limit = min(55.0, self.limits[path]) if starting else self.limits[path]
            if not math.isfinite(temp) or temp < 0 or temp >= limit:
                return f"NVMe temperature {temp} C reaches guard {limit} C: {path}"
        for path, count in sample["throttle_counts"].items():
            if count != initial["throttle_counts"][path]:
                return f"thermal-throttle counter changed: {path}"
        if sample["mem_kib"]["MemAvailable"] < 2 * 1024 * 1024:
            return "less than 2 GiB available memory"
        if sample["mem_kib"]["SwapFree"] < initial["mem_kib"]["SwapFree"]:
            return "swap use increased"
        return None


def stop(proc):
    # The group contains only our child and its descendants.
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=2)
    except ProcessLookupError:
        pass
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=10)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    argv = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not argv or not math.isfinite(args.timeout) or not 0 < args.timeout <= 600:
        parser.error("command required; timeout must be in (0, 600] seconds")
    if socket.gethostname().split('.')[0] != "netlab-shuttle09":
        parser.error("load execution is restricted to netlab-shuttle09")
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = {"schema": 1, "argv": argv, "timeout_s": args.timeout,
                "hostname": socket.gethostname(), "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "guard_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "frequency_note": "scaling_cur_freq is an indicator, not independently measured APERF/MPERF"}
    manifest["source_sha256"] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                  for folder in ("phase5/bench", "phase5/tools", "phase5/runtime", "phase5/tests") for p in Path(folder).glob("*")
                                  if p.is_file() and not p.name.startswith('.')}
    manifest["binary_sha256"] = {arg: hashlib.sha256(Path(arg).read_bytes()).hexdigest()
                                  for i, arg in enumerate(argv)
                                  if Path(arg).is_file() and arg.startswith(("build/", "phase5/build/"))
                                  and (i == 0 or argv[i-1] != "-o")}
    for p in Path('phase5/build').glob('*.so'):
        manifest['binary_sha256'][str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    for source in manifest['source_sha256']:
        dest = args.out / 'source' / source
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
    manifest["environment"] = {k: os.environ.get(k) for k in ("SHUTTLE_DISABLE_CHANNELS", "OMP_NUM_THREADS", "OMP_PROC_BIND", "OMP_PLACES", "OMP_WAIT_POLICY", "OPENBLAS_NUM_THREADS", "PYTHONPATH", "GPU_WG_SIZE", "SHUTTLE_REFORM_CAPTURE_DIR", "SHUTTLE_PROFILE", "SHUTTLE_FTZ", "SHUTTLE_COUNTERS", "SHUTTLE_IMC", "SHUTTLE_Q3_INTRINSICS", "SHUTTLE_SCALAR_QUANT", "SHUTTLE_ATTENTION_ORIGINAL", "SHUTTLE_STREAM", "SHUTTLE_ARENA_MIB", "SHUTTLE_PREFETCH", "SHUTTLE_HUGEPAGES", "SHUTTLE_IO_SLOTS", "SHUTTLE_IO_GROUP_LAYERS", "SHUTTLE_IO_CPU", "SHUTTLE_FOREGROUND_TELEMETRY", "SHUTTLE_Q4_PAIR", "SHUTTLE_Q4_QUAD", "SHUTTLE_FFN_PRODUCERS", "SHUTTLE_CACHE_COUNTER", "SHUTTLE_FFN_MODE", "SHUTTLE_FFN_IMAGE", "SHUTTLE_FFN_TILE", "SHUTTLE_FFN_BATCH")}
    child = None
    def interrupted(signum, frame):
        raise RuntimeError(f"received signal {signum}")
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, interrupted)
    try:
        telemetry = Telemetry()
        manifest["temperature_limits_c"] = telemetry.limits
        initial = telemetry.sample()
        issue = telemetry.violation(initial, initial, starting=True)
        if issue:
            raise RuntimeError("start refused: " + issue)
        with (args.out / "telemetry.jsonl").open("w") as log, \
             (args.out / "stdout.txt").open("w") as stdout, \
             (args.out / "stderr.txt").open("w") as stderr:
            log.write(json.dumps(initial) + "\n")
            log.flush()
            t0 = time.monotonic()
            child = subprocess.Popen(argv, stdout=stdout, stderr=stderr, start_new_session=True)
            while True:
                sample = telemetry.sample()
                try:
                    sample['child_memory_kib'] = {line.split(':')[0]:int(line.split()[1]) for line in Path(f'/proc/{child.pid}/status').read_text().splitlines() if line.startswith(('VmRSS:', 'VmHWM:', 'RssAnon:', 'RssFile:'))}
                except FileNotFoundError: pass
                log.write(json.dumps(sample) + "\n")
                log.flush()
                issue = telemetry.violation(sample, initial)
                if issue:
                    raise RuntimeError(issue)
                rc = child.poll()
                if rc is not None:
                    manifest.update(status="completed" if rc == 0 else "child_failed", returncode=rc)
                    break
                if time.monotonic() - t0 >= args.timeout:
                    raise RuntimeError("wall-clock timeout")
                time.sleep(0.25)
            manifest["wall_s"] = time.monotonic() - t0
    except Exception as exc:
        manifest.update(status="aborted_or_refused", reason=str(exc))
    finally:
        if child is not None:
            stop(child)
        (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))
    return 0 if manifest.get("status") == "completed" else 1


if __name__ == "__main__":
    sys.exit(main())
