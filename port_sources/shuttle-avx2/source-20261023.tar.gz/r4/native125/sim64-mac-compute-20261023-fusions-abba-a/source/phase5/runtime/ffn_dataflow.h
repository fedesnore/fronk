#pragma once
#include <atomic>
struct FfnHeader {char magic[8];uint32_t version,layers,dim,ffn,neurons,lanes,bits,tilebytes;uint8_t pad[24];};
static_assert(sizeof(FfnHeader)==64);

// Continue the original per-output group FMA order. Only the weight stride changes.
__attribute__((noinline)) static __m256 ffn_down8(const uint8_t*w,const X8*q,int count,__m256 total){
 for(int g=0;g<count;g++){
  __m256i acc=_mm256_setzero_si256();
  for(int j=0;j<8;j++){
   auto lo=_mm256_set1_epi32(*(const int32_t*)(q[g].q+j*8));
   auto hi=_mm256_set1_epi32(*(const int32_t*)(q[g].q+j*8+4));
   acc=_mm256_add_epi32(acc,lane_dot8(_mm256_loadu_si256((const __m256i*)(w+size_t(g)*165888+32+j*32)),lo,hi));
  }
  auto dot=_mm256_sub_epi32(acc,_mm256_set1_epi32(q[g].sum*8));
  auto scale=_mm256_mul_ps(_mm256_loadu_ps((const float*)(w+size_t(g)*165888)),_mm256_set1_ps(q[g].d));
  total=_mm256_fmadd_ps(_mm256_cvtepi32_ps(dot),scale,total);
 }
 return total;
}

struct FfnImage {
 bool quad=std::getenv("SHUTTLE_Q4_QUAD")!=nullptr;int fd=-1;void*map=MAP_FAILED;size_t size=0;int mode=0,chunk=8,maxbatch=1,threads,producers=4;struct alignas(64) Flag{std::atomic<int> value{0};};Flag produced[140],consumed[8];std::vector<float>partial;std::vector<X8>ready;
 FfnImage(const char*path,int nt):threads(nt){
  mode=std::atoi(std::getenv("SHUTTLE_FFN_MODE")?std::getenv("SHUTTLE_FFN_MODE"):"1");
  chunk=std::atoi(std::getenv("SHUTTLE_FFN_TILE")?std::getenv("SHUTTLE_FFN_TILE"):"8");
  maxbatch=std::atoi(std::getenv("SHUTTLE_FFN_BATCH")?std::getenv("SHUTTLE_FFN_BATCH"):"1");
  producers=std::atoi(std::getenv("SHUTTLE_FFN_PRODUCERS")?std::getenv("SHUTTLE_FFN_PRODUCERS"):"4");
  if(mode<1||mode>3||(mode==3&&(producers<1||producers>=threads))||chunk<1||chunk>140||maxbatch<1||maxbatch>8)throw std::runtime_error("FFN plan bounds");
  fd=open(path,O_RDONLY);if(fd<0)throw std::runtime_error("FFN execution image open failed");struct stat st;
  if(fstat(fd,&st)||st.st_size!=64+size_t(28)*140*165888){close(fd);throw std::runtime_error("FFN execution image size");}size=st.st_size;
  map=mmap(nullptr,size,PROT_READ,MAP_PRIVATE,fd,0);if(map==MAP_FAILED){close(fd);throw std::runtime_error("FFN mmap failed");}
  auto*h=(const FfnHeader*)map;
  if(memcmp(h->magic,"SHUTFFN4",8)||h->version!=4||h->layers!=28||h->dim!=1536||h->ffn!=8960||h->neurons!=64||h->lanes!=8||h->bits!=4||h->tilebytes!=165888){munmap(map,size);close(fd);throw std::runtime_error("FFN execution image header");}
  partial.resize(size_t(threads)*8*1536);ready.resize(8*140);
 }
 ~FfnImage(){if(map!=MAP_FAILED)munmap(map,size);if(fd>=0)close(fd);}
 const uint8_t* tile(int layer,int g)const{return (const uint8_t*)map+64+(size_t(layer)*140+g)*165888;}
 void produce(int layer,int g,const X8*input,int qstride,int batch,X8*out,int outstride,float*trace_gu,float*trace_ff){
  alignas(64) float gate[8*64],up[8*64],act[64];const uint8_t*w=tile(layer,g);
  for(int r=0;r<64;r+=8)for(int t=0;t<batch;t++){
   if(quad&&t+3<batch){q4_panel4<288,false>(w+size_t(r/8)*6912,input+size_t(t)*qstride,qstride,24,gate+t*64+r,64);q4_panel4<288,false>(w+55296+size_t(r/8)*6912,input+size_t(t)*qstride,qstride,24,up+t*64+r,64);t+=3;}
   else if(t+1<batch){q4_pair(w+size_t(r/8)*6912,input+size_t(t)*qstride,input+size_t(t+1)*qstride,24,gate+t*64+r,gate+(t+1)*64+r);q4_pair(w+55296+size_t(r/8)*6912,input+size_t(t)*qstride,input+size_t(t+1)*qstride,24,up+t*64+r,up+(t+1)*64+r);++t;}
   else{lane_dot<8,4>(w+size_t(r/8)*6912,input+size_t(t)*qstride,24,gate+t*64+r);lane_dot<8,4>(w+55296+size_t(r/8)*6912,input+size_t(t)*qstride,24,up+t*64+r);}
  }
  for(int t=0;t<batch;t++){
   for(int r=0;r<64;r++)act[r]=(gate[t*64+r]/(1+std::exp(-gate[t*64+r])))*up[t*64+r];
   quantize(act,out+size_t(t)*outstride,64);
   if(trace_gu&&batch==1){memcpy(trace_gu+g*64,gate,256);memcpy(trace_gu+8960+g*64,up,256);memcpy(trace_ff+g*64,act,256);}
  }
 }
 void consume(const uint8_t*w,const X8*q,int groups,int batch,float*out){
  for(int t=0;t<batch;t++){
   if(quad&&t+3<batch){q4_panel4<165888,true>(w,q+t*140,140,groups,out+t*1536,1536);t+=3;}
   else _mm256_storeu_ps(out+t*1536,ffn_down8(w,q+t*140,groups,_mm256_loadu_ps(out+t*1536)));
  }
 }
 // All workers enter this method from the existing persistent parallel region.
 void execute(int layer,const X8*input,int qstride,int batch,float*residual,float*trace_gu=nullptr,float*trace_ff=nullptr,float*diagnostic=nullptr){
  const int tid=omp_get_thread_num(),D=1536;
  if(mode==1){
   #pragma omp for schedule(static)
   for(int i=0;i<batch*D;i++)partial[i]=0;
   for(int first=0;first<140;first+=chunk){int last=std::min(140,first+chunk);
    #pragma omp for schedule(static)
    for(int g=first;g<last;g++)produce(layer,g,input,qstride,batch,ready.data()+g,140,trace_gu,trace_ff);
    #pragma omp for schedule(static)
    for(int r=0;r<D;r+=8)consume(tile(layer,first)+110592+(r/8)*288,ready.data()+first,last-first,batch,partial.data()+r);
   }
   #pragma omp for schedule(static)
   for(int i=0;i<batch*D;i++){if(diagnostic)diagnostic[i]=partial[i];residual[i]+=partial[i];}
  }else if(mode==3){
   // Fixed producer/consumer roles, bounded lookahead, exact down-group order.
   #pragma omp for schedule(static)
   for(int i=0;i<batch*D;i++)partial[i]=0;
   #pragma omp for schedule(static)
   for(int i=0;i<140;i++){produced[i].value.store(0,std::memory_order_relaxed);if(i<8)consumed[i].value.store(0,std::memory_order_relaxed);}
   const int consumers=threads-producers;
   if(tid<producers){
    for(int g=tid;g<140;g+=producers){
     if(g>=chunk){bool available=false;while(!available){available=true;for(int c=0;c<consumers;c++)if(consumed[c].value.load(std::memory_order_acquire)<=g-chunk)available=false;if(!available)_mm_pause();}}
     produce(layer,g,input,qstride,batch,ready.data()+g,140,trace_gu,trace_ff);
     produced[g].value.store(1,std::memory_order_release);
    }
   }else{
    int c=tid-producers,begin=(192*c/consumers)*8,end=(192*(c+1)/consumers)*8;
    for(int g=0;g<140;g++){
     while(!produced[g].value.load(std::memory_order_acquire))_mm_pause();
     for(int r=begin;r<end;r+=8)consume(tile(layer,g)+110592+(r/8)*288,ready.data()+g,1,batch,partial.data()+r);
     consumed[c].value.store(g+1,std::memory_order_release);
    }
   }
   #pragma omp barrier
   #pragma omp for schedule(static)
   for(int i=0;i<batch*D;i++){if(diagnostic)diagnostic[i]=partial[i];residual[i]+=partial[i];}
  }else{
   // Neuron ownership removes per-chunk team barriers, but changes FP reduction.
   float*own=partial.data()+size_t(tid)*8*D;std::fill(own,own+batch*D,0);
   alignas(64) X8 local[8*140];int begin=140*tid/threads,end=140*(tid+1)/threads;
   for(int first=begin;first<end;first+=chunk){int count=std::min(chunk,end-first);
    for(int g=0;g<count;g++)produce(layer,first+g,input,qstride,batch,local+g,140,trace_gu,trace_ff);
    for(int r=0;r<D;r+=8)consume(tile(layer,first)+110592+(r/8)*288,local,count,batch,own+r);
   }
   #pragma omp barrier
   #pragma omp for schedule(static)
   for(int r=0;r<D;r+=8)for(int t=0;t<batch;t++){
    __m256 sum=_mm256_loadu_ps(partial.data()+t*D+r);
    for(int worker=1;worker<threads;worker++)sum=_mm256_add_ps(sum,_mm256_loadu_ps(partial.data()+size_t(worker)*8*D+t*D+r));
    if(diagnostic)_mm256_storeu_ps(diagnostic+t*D+r,sum);
    _mm256_storeu_ps(residual+t*D+r,_mm256_add_ps(_mm256_loadu_ps(residual+t*D+r),sum));
   }
  }
 }
};
