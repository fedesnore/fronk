import sys,os,json
import numpy as np
sys.path.insert(0,'phase5/runtime');from infer import Engine
e=Engine('phase2/models/q3ffn-lane8.bin','models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=128,kernel=4)
ids=e.tokenizer.encode('Explain why a controlled experiment needs an independent correctness check.',add_special_tokens=False).ids;expected=[]
try:
 for i,t in enumerate(ids):expected.append(e.forward(t,i).copy())
finally:e.close()
os.environ['SHUTTLE_DISABLE_CHANNELS']='1'
e=Engine('phase5/models/q3-cardinal64-q4.bin','models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=128,kernel=4)
try:
 for i,t in enumerate(ids):assert np.array_equal(expected[i],e.forward(t,i))
finally:e.close()
print(json.dumps({'tokens':len(ids),'all_vocabulary_logits_bit_exact_to_q3_parent':True}))
