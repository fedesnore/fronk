"""Predeclared asymmetric ablation: retain full Q4 down; correct the Q3 gate/up path."""
import pathlib,json,struct,hashlib
from channel_probe import Image,pace
def hashed(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);pace(.05)
 return h.hexdigest()
def align(f):f.write(bytes((-f.tell())%64))
base=Image('phase5/models/q3-cardinal64-q4.bin');q4=Image('phase2/models/q4-lane8.bin')
for im in (base,q4):assert hashed(im.f.name)==im.meta['sha256']
path=pathlib.Path('phase5/models/q3-cardinal64-protected-down.bin');f=path.open('xb');f.write(base.mm[:64]);records=[];matrix_bytes=correction_bytes=0
for old in base.meta['tensors']:
 name=old['name'];protect=name.endswith('.down');source=q4 if protect else base;t=dict(source.records[name]);matrix=bool(t['row_block']);align(f);t['header_offset']=f.tell()
 if matrix:f.write(source.mm[source.records[name]['header_offset']:source.records[name]['header_offset']+32]);align(f)
 offset=source.records[name]['offset'];t['offset']=f.tell()
 for a in range(0,t['bytes'],1024*1024):f.write(source.mm[offset+a:offset+min(a+1024*1024,t['bytes'])]);pace(.005)
 if matrix:
  matrix_bytes+=t['bytes'];align(f);t['cardinal_header_offset']=f.tell();cr=t.get('cardinal');f.write(struct.pack('<IIQQQ',cr['columns'] if cr else 0,1 if cr else 0,cr['bytes'] if cr else 0,0,0))
  if cr:
   cr=dict(cr);align(f);cr['indices_offset']=f.tell();f.write(struct.pack('<'+'I'*cr['columns'],*cr['indices']));align(f);offset=cr['offset'];cr['offset']=f.tell();f.write(base.mm[offset:offset+cr['bytes']]);t['cardinal']=cr;correction_bytes+=cr['bytes']+4*cr['columns'];pace()
 records.append(t)
f.close();m=dict(base.meta);m.update(tensors=records,parent_sha256=base.meta['sha256'],protected_down_parent_sha256=q4.meta['sha256'],sha256=hashed(path),file_bytes=path.stat().st_size,matrix_payload_bytes=matrix_bytes,correction_bytes_including_indices=correction_bytes,total_active_matrix_bytes=matrix_bytes+correction_bytes,total_matrix_effective_bpw=8*(matrix_bytes+correction_bytes)/m['matrix_parameters']);m['transformation']=dict(m['transformation'],protected='all down projections Q4, no correction; GU unchanged from cardinal64',assembly_compiler_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest());path.with_suffix('.json').write_text(json.dumps(m,indent=2));print(json.dumps({'artifact':str(path),'bytes':m['file_bytes'],'bpw':m['total_matrix_effective_bpw'],'sha256':m['sha256']}),flush=True)
