"""Checkpoint-matched local continuation scoring, inspired by DwarfStar's QA discipline.
Q4 teacher tokens are frozen once, never used to fit any transform.
"""
import sys,pathlib,json
import numpy as np
sys.path.insert(0,'phase5/runtime');from infer import Engine
name,model=sys.argv[1:];cases=json.loads(pathlib.Path('phase5/tests/quality_cases.json').read_text());fixture=pathlib.Path('phase5/results/q4-continuations.json');e=Engine(model,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=2048,kernel=4,prefill='batch')
def nll(logits,token):
 s=logits.astype(np.float64);m=s.max();return float(np.log(np.exp(s-m).sum())+m-s[token])
try:
 if name=='q4':
  refs=[]
  for i,c in enumerate(cases):
   text='<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n'+c['prompt']+'<|im_end|>\n<|im_start|>assistant\n';prompt=e.tokenizer.encode(text,add_special_tokens=False).ids;logits=e.prefill(prompt);tokens=[];scores=[]
   for j in range(64):
    t=int(np.argmax(logits));tokens.append(t);scores.append(nll(logits,t))
    if t in (151643,151645):break
    logits=e.forward(t,len(prompt)+j)
   rec={'case':i,'prompt_ids':prompt,'continuation_ids':tokens,'target_nll':scores,'decoded':e.tokenizer.decode(tokens,skip_special_tokens=True)};refs.append(rec);print(json.dumps({'case':i,'tokens':len(tokens),'nll':float(np.mean(scores))}),flush=True)
  with fixture.open('x') as f:json.dump({'model':model,'model_sha256':json.loads(pathlib.Path(model).with_suffix('.json').read_text())['sha256'],'cap':64,'cases':refs},f,indent=2)
 else:
  refs=json.loads(fixture.read_text())['cases'];total=[];delta=[];agreement=[]
  for c in refs:
   scores=[];same=[];p=c['prompt_ids'];logits=e.prefill(p)
   for j,t in enumerate(c['continuation_ids']):
    scores.append(nll(logits,t));same.append(int(np.argmax(logits))==t)
    if j+1<len(c['continuation_ids']):logits=e.forward(t,len(p)+j)
   change=np.array(scores)-c['target_nll'];total.extend(scores);delta.extend(change);agreement.extend(same);print(json.dumps({'case':c['case'],'tokens':len(scores),'nll':float(np.mean(scores)),'mean_delta_from_q4':float(change.mean()),'top1_agreement':float(np.mean(same))}),flush=True)
  print(json.dumps({'model':name,'targets':len(total),'mean_nll':float(np.mean(total)),'mean_delta_from_q4':float(np.mean(delta)),'top1_agreement':float(np.mean(agreement))}),flush=True)
finally:e.close()
