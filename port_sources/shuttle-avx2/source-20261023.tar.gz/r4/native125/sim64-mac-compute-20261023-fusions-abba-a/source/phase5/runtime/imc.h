#pragma once
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <cerrno>
#include <fstream>
#include <chrono>
struct IMCCounters {
 int fd[2]={-1,-1},error=0;double bytes[2]={},seconds=0,ratio=1,scale[2]={};std::chrono::steady_clock::time_point begin;
 void close_all(){for(int&i:fd)if(i>=0){close(i);i=-1;}}
 void start(){
  close_all();error=0;bytes[0]=bytes[1]=0;ratio=1;seconds=0;
  unsigned type=0,cpu=0;std::ifstream f("/sys/bus/event_source/devices/uncore_imc/type"),c("/sys/bus/event_source/devices/uncore_imc/cpumask");if(!(f>>type)||!(c>>cpu)){error=ENOENT;return;}
  const char*names[]={"data_reads","data_writes"};
  for(int i=0;i<2;i++){
   std::string base=std::string("/sys/bus/event_source/devices/uncore_imc/events/")+names[i],event,unit;std::ifstream e(base),u(base+".unit"),s(base+".scale");
   if(!(e>>event)||!(u>>unit)||!(s>>scale[i])||unit!="MiB"||event.rfind("event=",0)!=0){error=EINVAL;return;}scale[i]*=1048576;
   perf_event_attr a{};a.size=sizeof(a);a.type=type;a.config=std::stoul(event.substr(6),nullptr,0);a.disabled=1;a.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
   fd[i]=syscall(SYS_perf_event_open,&a,-1,cpu,-1,0);if(fd[i]<0){error=errno;return;}
   if(ioctl(fd[i],PERF_EVENT_IOC_RESET,0)){error=errno;return;}
  }
  begin=std::chrono::steady_clock::now();
  for(int i=0;i<2;i++)if(ioctl(fd[i],PERF_EVENT_IOC_ENABLE,0)){error=errno;return;}
 }
 void stop(){
  if(error)return;
  for(int i=0;i<2;i++)if(fd[i]<0){error=EINVAL;return;}
  for(int i=0;i<2;i++)if(ioctl(fd[i],PERF_EVENT_IOC_DISABLE,0)){error=errno;return;}
  seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();
  for(int i=0;i<2;i++){
   uint64_t data[3];if(read(fd[i],data,sizeof(data))!=sizeof(data)||!data[2]){error=errno?errno:EIO;return;}
   bytes[i]=data[0]*scale[i]*double(data[1])/data[2];ratio=std::min(ratio,double(data[2])/data[1]);
  }
 }
 ~IMCCounters(){close_all();}
};
