import pathlib,re,json
root=pathlib.Path('phase5');path=root/'results/runtime.asm';out={}
for b in re.split(r'\n(?=[0-9a-f]+ <)',path.read_text()):
 name=b.splitlines()[0] if b.splitlines() else ''
 if not any(k in name for k in ['lane_dot<8, 4>','q3_asm_dot<8>','channel_quant','channel_add']):continue
 out[name]={'ymm_names':sorted(set(re.findall(r'ymm\d+',b))), 'vector_stack_sites':[l for l in b.splitlines() if re.search(r'ymm|YMMWORD',l) and re.search(r'\[(rsp|rbp)',l)],'note':'Static vector stack references, not a dynamic spill count. Explicit activation/output buffers are not register spills.'}
(root/'docs/assembly-audit.json').write_text(json.dumps(out,indent=2))
for name,d in out.items():print(name,len(d['ymm_names']),len(d['vector_stack_sites']))
