from run import run
import os
os.environ['SHUTTLE_Q4_QUAD']='1'
models={'q4':'phase2/models/q4-lane8.bin','cardinal':'phase5/models/q3-cardinal64-q4.bin','protected':'phase5/models/q3-cardinal64-protected-down.bin'}
for rep,order in [(2,['protected','cardinal','q4']),(3,['q4','cardinal','protected'])]:
 for name in order:
  run(f'{name}-sustained-repeat{rep}',120,['python3','phase5/runtime/infer.py','--model',models[name],'--kernel','4','--prefill','batch','--max-tokens','1024','--ignore-eos'])
