#pragma once
#include <linux/perf_event.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <cerrno>
// CPUID 06_8E uses Intel SKL event table v59. FP_ASSIST.ANY:
// Event CA, UMask 1E, CMask 1. Counts assist cycles, not retired operations.
struct ModelCounters {
 int fd[4]={-1,-1,-1,-1},error=0;double value[4]={},ratio=1;bool enabled;
 explicit ModelCounters(bool enable):enabled(enable){
  if(!enabled)return;
  const uint64_t configs[]={PERF_COUNT_HW_CPU_CYCLES,PERF_COUNT_HW_INSTRUCTIONS,PERF_COUNT_HW_CACHE_MISSES,0x1001eca};
  for(int i=0;i<4;i++){
   perf_event_attr a{};a.size=sizeof(a);a.type=i==3?PERF_TYPE_RAW:PERF_TYPE_HARDWARE;a.config=configs[i];if(i==3&&std::getenv("SHUTTLE_CACHE_COUNTER")){a.type=PERF_TYPE_HW_CACHE;a.config=PERF_COUNT_HW_CACHE_L1D|(PERF_COUNT_HW_CACHE_OP_READ<<8)|(PERF_COUNT_HW_CACHE_RESULT_MISS<<16);}if(i==3&&std::getenv("SHUTTLE_CACHE_COUNTER")){const char*which=std::getenv("SHUTTLE_CACHE_COUNTER");if(!strcmp(which,"L2_HIT")){a.type=PERF_TYPE_RAW;a.config=0xc124;}else if(!strcmp(which,"L2_MISS")){a.type=PERF_TYPE_RAW;a.config=0x2124;}}a.disabled=1;a.exclude_kernel=1;a.exclude_hv=1;a.read_format=PERF_FORMAT_TOTAL_TIME_ENABLED|PERF_FORMAT_TOTAL_TIME_RUNNING;
   fd[i]=syscall(SYS_perf_event_open,&a,0,-1,i?fd[0]:-1,0);if(fd[i]<0){error=errno;return;}
  }
  if(ioctl(fd[0],PERF_EVENT_IOC_RESET,PERF_IOC_FLAG_GROUP)||ioctl(fd[0],PERF_EVENT_IOC_ENABLE,PERF_IOC_FLAG_GROUP))error=errno;
 }
 void stop(){
  if(!enabled||error)return;
  if(ioctl(fd[0],PERF_EVENT_IOC_DISABLE,PERF_IOC_FLAG_GROUP)){error=errno;return;}
  for(int i=0;i<4;i++){
   uint64_t data[3];if(read(fd[i],data,sizeof(data))!=sizeof(data)||!data[2]){error=errno?errno:EIO;return;}
   value[i]=double(data[0])*data[1]/data[2];ratio=std::min(ratio,double(data[2])/data[1]);
  }
 }
 ~ModelCounters(){for(int f:fd)if(f>=0)close(f);}
};
struct FloatMode {
 unsigned prior=0;bool enabled;
 explicit FloatMode(bool enable):enabled(enable){if(enabled){prior=_mm_getcsr();_mm_setcsr(prior|0x8040);}}
 ~FloatMode(){if(enabled)_mm_setcsr(prior);}
};
