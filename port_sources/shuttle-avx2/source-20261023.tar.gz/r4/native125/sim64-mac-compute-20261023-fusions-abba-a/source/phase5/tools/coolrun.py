#!/usr/bin/env python3
import pathlib,sys,time
from guard import Telemetry,main
telemetry=Telemetry();deadline=time.monotonic()+60
while max(telemetry.sample()['temp_c'].values())>=55 or max(telemetry.sample()['storage_temp_c'].values())>=50:
 if time.monotonic()>deadline:raise SystemExit('cooldown exceeded; no workload started')
 time.sleep(1)
sys.exit(main())
