"""Sliding Jacobi window with request-local cached conditional responses.
Only verified greedy prefix tokens are emitted. Rejected future states remain proposals.
Related to Lookahead Decoding; this is a native CPU experiment, not a novelty claim.
"""
import argparse,ctypes,json,time
import numpy as np
from infer import Engine
class FixedPointEngine(Engine):
 def __init__(self,*a,lookahead=4,min_match=6,**kw):
  super().__init__(*a,**kw);self.lookahead=lookahead;self.min_match=min_match
  self.lib.shuttle_verify.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_void_p];self.lib.shuttle_verify.restype=ctypes.c_int
  self.verification=np.empty((16,151936),np.float32)
 def generate(self,prompt,max_tokens=128,temperature=0,seed=1,ignore_eos=False):
  if temperature!=0:raise ValueError('exact lookup verification currently supports greedy decoding only')
  if not 1<=max_tokens<=1024 or not 1<=self.lookahead<=15 or not 2<=self.min_match<=10:raise ValueError('bounds')
  text='<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n'+prompt+'<|im_end|>\n<|im_start|>assistant\n';start=time.perf_counter();ids=self.tokenizer.encode(text,add_special_tokens=False).ids
  if len(ids)+max_tokens>self.context:raise ValueError('context bounds')
  self.prefill(ids);prefill=time.perf_counter()-start;history=[];index={};responses={};carry=[]
  def remember(token):
   history.append(token)
   for order in [1,2,3,4]:
    if len(history)>order:responses[tuple(history[-order-1:-1])]=token
   for n in range(self.min_match,11):
    if len(history)>=n:
     key=tuple(history[-n:]);at=len(history)-n;old=index.get(key,[]);index[key]=(old+[at])[-2:]
  for token in ids:remember(token)
  def propose(cap):
   # Prefer a committed exact-history continuation, then a Jacobi trajectory.
   for n in range(min(10,len(history)),self.min_match-1,-1):
    for at in reversed(index.get(tuple(history[-n:]),[])):
     begin=at+n
     if begin<len(history):return history[begin:min(begin+cap,len(history))]
   draft=[]
   for j in range(cap):
    context=history+draft;next_token=None
    for order in [4,3,2,1]:
     if len(context)>=order and tuple(context[-order:]) in responses:
      next_token=responses[tuple(context[-order:])];break
    if next_token is None:next_token=carry[j] if j<len(carry) else context[-1]
    draft.append(next_token)
   return draft
  generated=[];previous='';emitted=[];prefill=time.perf_counter()-start;decode_start=time.perf_counter();pending=int(np.argmax(self.logits));pos=len(ids);calls=inputs=proposed=accepted=0;forward_s=0.;batches=0;fallback=0;finished=False
  while len(generated)<max_tokens and not finished:
   # pending is always an exact target-model prediction, never a proposal.
   if not generated:outputs=[pending]
   else:
    draft=propose(min(self.lookahead,max_tokens-len(generated)-1));proposed+=len(draft);t=time.perf_counter()
    if draft:
     if not self.monitor.is_alive():raise RuntimeError('safety monitor stopped')
     tokens=np.asarray([pending]+draft,dtype=np.int32);n=len(tokens)
     if self.lib.shuttle_verify(self.model,tokens.ctypes.data,n,pos,self.verification.ctypes.data):raise RuntimeError(self.lib.shuttle_error().decode())
     if not np.isfinite(self.verification[:n]).all():raise RuntimeError('non-finite verification logits')
     predictions=self.verification[:n].argmax(axis=1).tolist();matched=0
     for j,prediction in enumerate(predictions):
      context=history+draft[:j]
      for order in [1,2,3,4]:
       if len(context)>=order:responses[tuple(context[-order:])]=prediction
     if len(responses)>16384:responses.clear()
     while matched<len(draft) and predictions[matched]==draft[matched]:matched+=1
     outputs=draft[:matched]+[predictions[matched]];carry=predictions[matched+1:];accepted+=matched;batches+=1;inputs+=n;pos+=matched+1
    else:
     outputs=[int(np.argmax(self.forward(pending,pos)))];pos+=1;inputs+=1;fallback+=1
    forward_s+=time.perf_counter()-t;calls+=1
   for token in outputs:
    if token in (151643,151645) and not ignore_eos:finished=True;break
    if len(generated)>=max_tokens:break
    generated.append(token);remember(token);pending=token;decoded=self.tokenizer.decode(generated,skip_special_tokens=True);safe=decoded.rstrip('\ufffd');piece=safe[len(previous):] if safe.startswith(previous) else '';previous=safe
    elapsed=time.perf_counter()-decode_start;emitted.append(elapsed)
    yield {'event':'token','token_id':token,'text':piece,'index':len(generated)-1,'elapsed_s':time.perf_counter()-start}
  wall=time.perf_counter()-decode_start;gaps=np.diff(emitted)*1000
  yield {'event':'metrics','implementation':'jacobi-response-cache-exact-greedy','lookahead':self.lookahead,'min_match':self.min_match,'prompt_tokens':len(ids),'generated_tokens':len(generated),'decode_steps':max(0,len(generated)-1),'decode_wall_s':wall,'decode_wall_tok_s':max(0,len(generated)-1)/wall,'decode_forward_s':forward_s,'prefill_s':prefill,'target_graph_passes':calls,'target_input_positions':inputs,'verification_batches':batches,'fallback_steps':fallback,'proposed_tokens':proposed,'matched_draft_tokens':accepted,'proposal_match_fraction':accepted/proposed if proposed else None,'intertoken_p95_ms':float(np.percentile(gaps,95)) if len(gaps) else None,'intertoken_max_ms':float(gaps.max()) if len(gaps) else None,'response':self.tokenizer.decode(generated,skip_special_tokens=True)}
def main():
 p=argparse.ArgumentParser();p.add_argument('--model',default='phase2/models/q4-lane8.bin');p.add_argument('--prompt',default='Write a Python function that returns unique items while preserving their original order. Explain its time complexity.');p.add_argument('--max-tokens',type=int,default=128);p.add_argument('--lookahead',type=int,default=4);p.add_argument('--min-match',type=int,default=6);p.add_argument('--stdio',action='store_true');a=p.parse_args();e=FixedPointEngine(a.model,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=2048,kernel=4,prefill='batch',lookahead=a.lookahead,min_match=a.min_match)
 try:
  if a.stdio:
   import socket,sys
   print(json.dumps({'event':'ready','hostname':socket.gethostname(),'threads':8,'context':2048}),flush=True)
   for line in sys.stdin:
    try:
     request=json.loads(line)
     for result in e.generate(request['prompt'],request.get('max_tokens',128),request.get('temperature',0)):print(json.dumps(result,ensure_ascii=False),flush=True)
    except Exception as ex:print(json.dumps({'event':'error','error':str(ex)}),flush=True)
  else:
   for result in e.generate(a.prompt,a.max_tokens):print(json.dumps(result,ensure_ascii=False),flush=True)
 finally:e.close()
if __name__=='__main__':main()
