from run import run
import os
os.environ['SHUTTLE_Q4_QUAD']='1'
run('build-cardinal',300,['python3','phase5/tools/duty.py','--','g++','-O3','-std=c++17','-mavx2','-mfma','-mf16c','-fopenmp','-pthread','-fPIC','-shared','phase5/runtime/native.cpp','-o','phase5/build/libshuttle.so'])
m='phase5/models/q3-cardinal64-q4.bin'
run('cardinal-independent',180,['python3','phase5/tests/check_channels.py'])
run('cardinal-verify',180,['python3','phase5/tests/check_verify.py',m])
run('cardinal-likelihood',120,['python3','phase5/tests/check_likelihood.py','score','--model',m])
run('cardinal-heldout',180,['python3','phase5/tests/heldout.py',m])
run('cardinal-quality',180,['python3','phase5/tests/run_quality.py',m])
for name,model in [('reference','phase2/models/q4-lane8.bin'),('cardinal',m),('q3-base','phase2/models/q3ffn-lane8.bin')]:
 run(name+'-sustained-1024',120,['python3','phase5/runtime/infer.py','--model',model,'--kernel','4','--prefill','batch','--max-tokens','1024','--ignore-eos'])
