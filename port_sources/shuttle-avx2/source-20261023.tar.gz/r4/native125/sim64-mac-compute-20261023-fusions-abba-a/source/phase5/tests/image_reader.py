"""Independent scalar-index decoder for SHUTLLM2, used only for correctness checks."""
import json,mmap,pathlib
import numpy as np
class Image:
 def __init__(self,path):
  path=pathlib.Path(path);self.meta=json.loads(path.with_suffix('.json').read_text());self.records={t['name']:t for t in self.meta['tensors']};self.f=path.open('rb');self.mm=mmap.mmap(self.f.fileno(),0,access=mmap.ACCESS_READ)
 def factors(self,name):
  t=self.records[name];r=t.get('residual')
  if not r:return None
  if not hasattr(self,'rf'):
   self.rf=pathlib.Path(self.f.name+'.residual').open('rb');self.rm=mmap.mmap(self.rf.fileno(),0,access=mmap.ACCESS_READ)
  rank=r['rank'];rows,cols=t['shape'];v=np.frombuffer(self.rm,dtype='<f2',count=rank*cols,offset=r['offset']).reshape(rank,cols).astype(np.float32)
  u=np.frombuffer(self.rm,dtype='<f2',count=rows*rank,offset=r['offset']+r['v_bytes']).reshape(rows//8,rank,8).transpose(0,2,1).reshape(rows,rank).astype(np.float32)
  return u,v
 def array(self,name):
  t=self.records[name];return np.frombuffer(self.mm,dtype='<f4',count=np.prod(t['shape']),offset=t['offset']).reshape(t['shape'])
 def rows(self,name,rows):
  t=self.records[name];R=t['row_block'];bits=t['bits'];C=t['shape'][1];G=C//64;rows=np.asarray(rows);size=32+64*bits
  # Address each group/row/column explicitly instead of reversing compiler reshapes.
  groups=np.arange(G)[None,:];offset=t['offset']+((rows[:,None]//R)*G*(R//8)+groups*(R//8)+(rows[:,None]%R)//8)*size
  raw=np.frombuffer(self.mm,dtype=np.uint8);k=np.arange(64)[None,None,:];lanes=(rows%8)[:,None,None]
  if bits==4:at=offset[:,:,None]+32+(k//8)*32+lanes*4+k%4;shift=(k%8//4)*4
  elif bits==2:at=offset[:,:,None]+32+(k//16)*32+lanes*4+k%4;shift=(k%16//4)*2
  else:
   bit=(k%32//4)*3;at=offset[:,:,None]+32+(k//32)*96+(bit//8)*32+lanes*4+k%4;shift=bit%8
  q=raw[at].astype(np.uint32)>>shift
  if bits==3:
   # Only fields straddling a byte boundary read the next plane.
   crossing=np.flatnonzero((shift.reshape(-1)>5));q[:,:,crossing]|=raw[at[:,:,crossing]+32].astype(np.uint32)<<(8-shift[:,:,crossing])
  q=(q&((1<<bits)-1)).astype(np.int32)-(1<<(bits-1))
  d=np.frombuffer(self.mm,dtype='<f4')[(offset+(rows[:,None]%8)*4)//4]
  return q,d
 def values(self,name,rows):
  q,d=self.rows(name,rows);return (q.astype(np.float32)*d[:,:,None]).reshape(len(rows),-1)
