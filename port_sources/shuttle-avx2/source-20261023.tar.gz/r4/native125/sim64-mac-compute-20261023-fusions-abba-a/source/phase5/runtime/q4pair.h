#pragma once
// Two input positions share one loaded/unpacked 8-output-row Q4 tile.
// Integer group partials and FP32 group accumulation preserve lane_dot order.
// 2 FP totals + 2 integer partials; the packed tile never leaves registers.
__attribute__((noinline)) static void q4_pair(const uint8_t*w,const X8*x,const X8*y,int groups,float*outx,float*outy){
 __m256 tx=_mm256_setzero_ps(),ty=tx;
 const __m256i mask=_mm256_set1_epi8(15),ones=_mm256_set1_epi16(1);
 for(int g=0;g<groups;g++){
  __m256i ax=_mm256_setzero_si256(),ay=ax;
  #pragma GCC unroll 1
  for(int j=0;j<8;j++){
   auto packed=_mm256_loadu_si256((const __m256i*)(w+g*288+32+j*32));
   auto lo=_mm256_and_si256(packed,mask),hi=_mm256_and_si256(_mm256_srli_epi16(packed,4),mask);
   auto x0=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*8)),x1=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*8+4));
   auto y0=_mm256_set1_epi32(*(const int32_t*)(y[g].q+j*8)),y1=_mm256_set1_epi32(*(const int32_t*)(y[g].q+j*8+4));
   ax=_mm256_add_epi32(ax,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,x0),_mm256_maddubs_epi16(hi,x1)),ones));
   ay=_mm256_add_epi32(ay,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,y0),_mm256_maddubs_epi16(hi,y1)),ones));
  }
  auto scale=_mm256_loadu_ps((const float*)(w+g*288));
  tx=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(ax,_mm256_set1_epi32(x[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(x[g].d)),tx);
  ty=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(ay,_mm256_set1_epi32(y[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(y[g].d)),ty);
 }
 _mm256_storeu_ps(outx,tx);_mm256_storeu_ps(outy,ty);
}
