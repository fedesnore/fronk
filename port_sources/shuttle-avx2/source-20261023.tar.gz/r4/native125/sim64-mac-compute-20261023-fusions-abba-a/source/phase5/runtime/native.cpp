#include <immintrin.h>
#include <omp.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>
struct Header {char magic[8];uint32_t version,layers,dim,ff,heads,kvheads,vocab,group,head_dim,format;float eps,theta;uint8_t pad[8];};
struct Q4 {float d;uint8_t q[32];};struct X8 {float d;int32_t sum;int8_t q[64];};
static_assert(sizeof(Header)==64&&sizeof(Q4)==36&&sizeof(X8)==72);
static float sum8(__m256 a){__m128 b=_mm_add_ps(_mm256_castps256_ps128(a),_mm256_extractf128_ps(a,1));b=_mm_hadd_ps(b,b);b=_mm_hadd_ps(b,b);return _mm_cvtss_f32(b);}
#include "residual_store.h"
#include "dot4.h"
#include "lanes.h"
#include "q4pair.h"
#include "q4panel.h"
#include "q3dense.h"
#include "q3asm.h"
#include "model_counters.h"
#include "imc.h"
static float dot8(const Q4*w,const X8*x,int groups){
 __m256 a=_mm256_setzero_ps();const __m256i mask=_mm256_set1_epi8(15),ones=_mm256_set1_epi16(1);
 for(int g=0;g<groups;g++){
  __m256i q=_mm256_loadu_si256((const __m256i*)w[g].q),lo=_mm256_and_si256(q,mask),hi=_mm256_and_si256(_mm256_srli_epi16(q,4),mask);
  __m256i p=_mm256_maddubs_epi16(lo,_mm256_loadu_si256((const __m256i*)x[g].q));
  __m256i r=_mm256_maddubs_epi16(hi,_mm256_loadu_si256((const __m256i*)(x[g].q+32)));
  __m256i v=_mm256_sub_epi32(_mm256_madd_epi16(_mm256_add_epi16(p,r),ones),_mm256_set1_epi32(x[g].sum));
  a=_mm256_fmadd_ps(_mm256_cvtepi32_ps(v),_mm256_set1_ps(w[g].d*x[g].d),a);
 }return sum8(a);
}
static float dot_float(const Q4*w,const float*x,int groups){
 __m256 acc=_mm256_setzero_ps();
 for(int g=0;g<groups;g++){
  __m256 a=_mm256_setzero_ps();
  for(int k=0;k<32;k+=8){__m256i q=_mm256_cvtepu8_epi32(_mm_loadl_epi64((const __m128i*)(w[g].q+k)));
   __m256 lo=_mm256_cvtepi32_ps(_mm256_sub_epi32(_mm256_and_si256(q,_mm256_set1_epi32(15)),_mm256_set1_epi32(8)));
   __m256 hi=_mm256_cvtepi32_ps(_mm256_sub_epi32(_mm256_srli_epi32(q,4),_mm256_set1_epi32(8)));
   a=_mm256_fmadd_ps(lo,_mm256_loadu_ps(x+g*64+k),a);a=_mm256_fmadd_ps(hi,_mm256_loadu_ps(x+g*64+k+32),a);
  }acc=_mm256_fmadd_ps(a,_mm256_set1_ps(w[g].d),acc);
 }return sum8(acc);
}
static void quantize_scalar(const float*x,X8*q,int n){
 for(int g=0;g<n/64;g++){
  float maxv=0;for(int j=0;j<64;j++)maxv=std::max(maxv,std::abs(x[g*64+j]));q[g].d=maxv/127;float inv=maxv?127/maxv:0;q[g].sum=0;
  for(int j=0;j<64;j++){int v=std::max(-127,std::min(127,int(std::nearbyint(x[g*64+j]*inv))));q[g].q[j]=v;q[g].sum+=v;}
 }
}
#include "register_ops.h"
static void quantize(const float*x,X8*q,int n){
 static const bool scalar=std::getenv("SHUTTLE_SCALAR_QUANT")!=nullptr;
 if(scalar)quantize_scalar(x,q,n);else quantize_vector(x,q,n);
}
static void normq(const float*x,const float*w,float*out,X8*q,int n,float eps){
 __m256 s=_mm256_setzero_ps();for(int j=0;j<n;j+=8){__m256 a=_mm256_loadu_ps(x+j);s=_mm256_fmadd_ps(a,a,s);}float d=1/std::sqrt(sum8(s)/n+eps);
 for(int j=0;j<n;j++) { out[j]=x[j]*d*w[j]; }
 quantize(out,q,n);
}
#include "ffn_dataflow.h"
struct MatrixHeader {uint32_t bits,rows,cols,rowblock,group,reserved;uint64_t bytes;};
static_assert(sizeof(MatrixHeader)==32);
struct Matrix {
 const uint8_t* data=nullptr;int bits=4,rows=0,cols=0,R=0,kind=-1;ResidualHeader correction{};int channels=0;const uint32_t* channel_index=nullptr;const uint8_t* channel_data=nullptr;
 size_t tilebytes()const{return size_t(cols/64)*(R/8)*(32+64*bits);}
 const Q4* old()const{return (const Q4*)data;}
 float weight(int row,int col)const{
  if(!R){auto&v=old()[size_t(row)*(cols/64)+col/64];return (((v.q[col%32]>>(col%64>=32?4:0))&15)-8)*v.d;}
  int g=col/64,k=col%64,lane=row%8,s=(row%R)/8;
  const uint8_t*p=data+(row/R)*tilebytes()+(g*(R/8)+s)*(32+64*bits);
  int code;
  if(bits==4)code=(p[32+(k/8)*32+lane*4+k%4]>>(k%8/4*4))&15;
  else if(bits==2)code=(p[32+(k/16)*32+lane*4+k%4]>>(k%16/4*2))&3;
  else{int bit=(k%32/4)*3,at=32+(k/32)*96+(bit/8)*32+lane*4+k%4;code=p[at]>>(bit%8);if(bit%8>5)code|=int(p[at+32])<<(8-bit%8);code&=7;}

  return (code-(1<<(bits-1)))*((const float*)p)[lane];
 }
 void tile(int row,const X8*q,float*out)const{
  const uint8_t*p=data+(row/R)*tilebytes();
  if(bits==4){if(R==8)lane_dot<8,4>(p,q,cols/64,out);else lane_dot<16,4>(p,q,cols/64,out);}
  else if(bits==3){
   static const bool use_asm=std::getenv("SHUTTLE_Q3_INTRINSICS")==nullptr;
   if(use_asm){if(R==8)q3_asm_dot<8>(p,q,cols/64,out);else q3_asm_dot<16>(p,q,cols/64,out);}
   else{if(R==8)q3_dense_dot<8>(p,q,cols/64,out);else q3_dense_dot<16>(p,q,cols/64,out);}
  }
  else{if(R==8)lane_dot<8,2>(p,q,cols/64,out);else lane_dot<16,2>(p,q,cols/64,out);}
 }
 void channel_quant(const X8*q,X8*out)const{
  for(int g=0;g<channels/64;g++){alignas(32) float a[64];for(int j=0;j<64;j++){unsigned ix=channel_index[g*64+j];a[j]=q[ix/64].d*q[ix/64].q[ix%64];}quantize_vector(a,out+g,64);}
 }
 void channel_add(int row,const X8*q,float*out)const{
  alignas(32) float v[8];lane_dot<8,4>(channel_data+size_t(row/8)*(channels/64)*288,q,channels/64,v);
  _mm256_storeu_ps(out,_mm256_add_ps(_mm256_loadu_ps(out),_mm256_load_ps(v)));
 }
 float floating(int row,const float*x)const{
  if(!R)return dot_float(old()+size_t(row)*(cols/64),x,cols/64);
  float sum=0;for(int col=0;col<cols;col++)sum+=weight(row,col)*x[col];return sum;
 }
};
#include "predictor.h"
struct Layer {const float *an,*fn,*bias;Matrix qkv,o,gu,down;uint32_t active=3,ff=8960;};
struct Model {
 int fd=-1;void* map=MAP_FAILED;size_t size=0,off=64;Header c;int threads,ctx,kernel,kdim,qrows;
 std::unique_ptr<FfnImage> ffn_image;Matrix embedding;std::unique_ptr<ResidualStore> residual_store;std::vector<float> residual_z=std::vector<float>(64*64);IMCCounters imc;bool ftz=false,measure_counters=false;double counters[4]={},pmu_ratio=1;int pmu_errno=0;bool register_attention=true;bool disable_channels=std::getenv("SHUTTLE_DISABLE_CHANNELS")!=nullptr;bool profiling=false;double profile[8]={};const float*finalnorm;std::vector<Layer>layers;
 int head_state_count=-1;int keep_neurons=8960;uint64_t protect_neurons=0;uint64_t skip_att=0,skip_ffn=0;std::string reform_dir;
 std::string trace_dir,calibration_dir;std::vector<float>diagnostic;std::vector<uint16_t>keys16,values16;
 std::vector<float>bx,bf,bq,ba,bg,bo,bs;std::vector<X8>b8;
 std::vector<float>x,xf,qkv,attout,gu,ff,keys,values,att,cosines,sines,logits;std::vector<X8>x8;
 template<typename T>const T*take(size_t n){off=(off+63)&~size_t(63);if(off>size||n>(size-off)/sizeof(T))throw std::runtime_error("truncated native model");const T*p=(const T*)((const char*)map+off);off+=n*sizeof(T);return p;}
 Matrix take_matrix(int rows,int cols){
  Matrix m;m.rows=rows;m.cols=cols;
  if(c.version==1){m.data=(const uint8_t*)take<Q4>(size_t(rows)*cols/64);return m;}
  auto*h=take<MatrixHeader>(1);
  if((h->bits!=2&&h->bits!=3&&h->bits!=4)||h->rows!=unsigned(rows)||h->cols!=unsigned(cols)||(h->rowblock!=8&&h->rowblock!=16)||h->group!=64||h->reserved||rows%h->rowblock||h->bytes!=size_t(rows/8)*(cols/64)*(32+64*h->bits))throw std::runtime_error("invalid matrix descriptor");
  m.bits=h->bits;m.R=h->rowblock;m.data=take<uint8_t>(h->bytes);if(c.version==3){m.correction=*take<ResidualHeader>(1);auto&r=m.correction;if(r.rank&&(r.rank>64||r.rank%8||r.format!=1||r.reserved||r.bytes!=size_t(r.rank)*(rows+cols)*2))throw std::runtime_error("invalid residual descriptor");}
  if(c.version==6){auto*p=take<uint64_t>(4);m.channels=uint32_t(p[0]);uint32_t format=p[0]>>32;if(p[2]||p[3]||(m.channels!=0&&m.channels!=64&&m.channels!=128)||(m.channels?(format!=1||p[1]!=size_t(rows/8)*(m.channels/64)*288||m.R!=8):(format||p[1])))throw std::runtime_error("invalid cardinal descriptor");if(m.channels){m.channel_index=take<uint32_t>(m.channels);for(int j=0;j<m.channels;j++)if(m.channel_index[j]>=unsigned(cols)||(j&&m.channel_index[j]<=m.channel_index[j-1]))throw std::runtime_error("invalid cardinal index");m.channel_data=take<uint8_t>(p[1]);}}return m;
 }
 Model(const char*path,int nt,int context,int arithmetic):threads(nt),ctx(context),kernel(arithmetic){
  if(nt<1||nt>8||context<1||context>8192||(kernel<0||kernel>4))throw std::runtime_error("runtime bounds");
  fd=open(path,O_RDONLY);if(fd<0)throw std::runtime_error("cannot open model");struct stat st;if(fstat(fd,&st)||st.st_size<64){close(fd);throw std::runtime_error("invalid file");}size=st.st_size;
  map=mmap(nullptr,size,PROT_READ,MAP_PRIVATE,fd,0);if(map==MAP_FAILED){close(fd);throw std::runtime_error("mmap failed");}
  try{
   memcpy(&c,map,64);
   if(!((!memcmp(c.magic,"SHUTLLM1",8)&&c.version==1&&c.format==0)||(!memcmp(c.magic,"SHUTLLM2",8)&&c.version==2&&c.format==2)||(!memcmp(c.magic,"SHUTLLM3",8)&&c.version==3&&c.format==3)||(!memcmp(c.magic,"SHUTLLM6",8)&&c.version==6&&c.format==6)||(!memcmp(c.magic,"SHUTLLM5",8)&&c.version==5&&c.format==5))||c.group!=64||c.layers!=28||c.dim!=1536||c.ff!=8960||c.heads!=12||c.kvheads!=2||c.head_dim!=128||c.vocab!=151936)throw std::runtime_error("unsupported model header");
   if(c.version==6&&kernel!=4)throw std::runtime_error("cardinal execution requires native kernel 4");
   kdim=c.kvheads*c.head_dim;qrows=c.dim+2*kdim;
   embedding=take_matrix(c.vocab,c.dim);embedding.kind=4;finalnorm=take<float>(c.dim);
   for(unsigned l=0;l<c.layers;l++){
    Layer a;
    if(c.version==5){auto*p=take<uint32_t>(16);a.active=p[1];a.ff=p[2];if(p[0]!=l||a.active>3||((a.active&2)?(!a.ff||a.ff>c.ff||a.ff%64):a.ff!=0))throw std::runtime_error("invalid active program");for(int j=3;j<16;j++)if(p[j])throw std::runtime_error("reserved program field");}
    a.an=take<float>(c.dim);a.fn=take<float>(c.dim);a.bias=take<float>(qrows);
    if(a.active&1){a.qkv=take_matrix(qrows,c.dim);a.o=take_matrix(c.dim,c.dim);a.qkv.kind=0;a.o.kind=1;}
    if(a.active&2){a.gu=take_matrix(2*a.ff,c.dim);a.down=take_matrix(c.dim,a.ff);a.gu.kind=2;a.down.kind=3;}
    layers.push_back(a);
   }
   if(c.version==3){std::vector<ResidualStore::Block>blocks;int rank=0;for(auto&a:layers){auto&g=a.gu.correction;auto&d=a.down.correction;if(!g.rank||g.rank!=d.rank||g.offset%4096)throw std::runtime_error("invalid correction layer plan");rank=std::max(rank,int(g.rank));blocks.push_back({g.offset,((d.offset+d.bytes+4095)&~uint64_t(4095))-g.offset});}residual_store=std::make_unique<ResidualStore>(std::string(path)+".residual",blocks,rank);}
   ftz=std::getenv("SHUTTLE_FTZ")!=nullptr;measure_counters=std::getenv("SHUTTLE_COUNTERS")!=nullptr;profiling=std::getenv("SHUTTLE_PROFILE")!=nullptr;register_attention=std::getenv("SHUTTLE_ATTENTION_ORIGINAL")==nullptr;
   if(off!=size)throw std::runtime_error("model trailing bytes");
   if(const char*p=std::getenv("SHUTTLE_FFN_IMAGE")){
    if(c.version!=2||kernel!=4)throw std::runtime_error("superblocks require native Q4 kernel 4");
    for(auto&a:layers)if(a.gu.bits!=4||a.down.bits!=4||a.gu.R!=8||a.down.R!=8)throw std::runtime_error("superblocks require Q4 lane8 parent");
    ffn_image=std::make_unique<FfnImage>(p,threads);
   }
   if(const char*t=std::getenv("SHUTTLE_TRACE_DIR")){trace_dir=t;diagnostic.resize(c.vocab);}
   if(const char*t=std::getenv("SHUTTLE_CALIBRATION_DIR"))calibration_dir=t;
   if(const char*t=std::getenv("SHUTTLE_REFORM_CAPTURE_DIR"))reform_dir=t;
   x.resize(c.dim);xf.resize(c.ff);qkv.resize(qrows);attout.resize(c.dim);gu.resize(2*c.ff);ff.resize(c.ff);x8.resize(c.ff/64);if(kernel>=2){keys16.resize(size_t(c.layers)*ctx*kdim);values16.resize(keys16.size());}else{keys.resize(size_t(c.layers)*ctx*kdim);values.resize(keys.size());}att.resize(size_t(c.heads)*ctx);logits.resize(c.vocab);
   cosines.resize(size_t(ctx)*c.head_dim/2);sines.resize(cosines.size());
   for(int p=0;p<ctx;p++)for(unsigned j=0;j<c.head_dim/2;j++){double angle=p/std::pow(double(c.theta),2.0*j/c.head_dim);cosines[p*c.head_dim/2+j]=std::cos(angle);sines[p*c.head_dim/2+j]=std::sin(angle);}
  }catch(...){munmap(map,size);close(fd);throw;}
 }
 ~Model(){if(map!=MAP_FAILED)munmap(map,size);if(fd>=0)close(fd);}
 void prune(float*f,int n,int l){
  if(keep_neurons>=8960||(protect_neurons&(uint64_t(1)<<l)))return;
  int keep=std::max(1,n*keep_neurons/8960);std::vector<float>v(n);for(int j=0;j<n;j++)v[j]=std::abs(f[j]);std::nth_element(v.begin(),v.begin()+n-keep,v.end());float cut=v[n-keep];for(int j=0;j<n;j++)if(std::abs(f[j])<cut)f[j]=0;
 }
 void capture(int pos,int l,const char*stage,const float*p,int n){
  if(reform_dir.empty()||pos<8||pos%4)return;
  std::ofstream f(reform_dir+"/"+std::to_string(l)+"."+stage+".f32",std::ios::binary|std::ios::app);f.write((const char*)p,n*sizeof(float));if(!f)throw std::runtime_error("reform capture failed");
 }
 void trace(int pos,int l,const char*stage,const char*part,const float*p,int n){
  if(!calibration_dir.empty()&&pos>=8&&pos%4==0&&!strcmp(part,"in")&&(!strcmp(stage,"gate_up")||!strcmp(stage,"down"))){
   std::ofstream f(calibration_dir+"/"+std::to_string(l)+"."+stage+".f32",std::ios::binary|std::ios::app);f.write((const char*)p,n*sizeof(float));if(!f)throw std::runtime_error("calibration write failed");
  }
  if(trace_dir.empty())return;
  std::string path=trace_dir+"/p"+std::to_string(pos)+"-l"+std::to_string(l)+"-"+stage+"-"+part+".f32";
  std::ofstream f(path,std::ios::binary);f.write((const char*)p,n*sizeof(float));
 }
 float dot(const Q4*w,const float*xfp,int groups){return kernel%2==0?dot8(w,x8.data(),groups):dot_float(w,xfp,groups);}
 void matvec(const Matrix&w,const float*input,float*out,int rows,int cols,bool residual=false,const float*bias=nullptr){
  double begin=profiling&&omp_get_thread_num()==0?omp_get_wtime():0;
  const uint16_t*rv=w.correction.rank?residual_store->get(w.correction.offset,w.correction.bytes):nullptr;
  if(rv){
   #pragma omp for schedule(static)
   for(unsigned k=0;k<w.correction.rank;k++)residual_z[k]=residual_project(rv+size_t(k)*cols,input,cols);
  }
  X8 cq[2];if(w.channels&&!disable_channels)w.channel_quant(x8.data(),cq);
  int groups=cols/64,step=w.R&&kernel%2==0?w.R:(kernel==4?4:1);if(w.R&&kernel%2)step=1;
  #pragma omp for schedule(static)
  for(int r=0;r<rows;r+=step){
   float v[16];
   if(w.R){if(kernel%2==0)w.tile(r,x8.data(),v);else v[0]=w.floating(r,input);}
   else if(kernel==4)dot4(w.old()+size_t(r)*groups,x8.data(),groups,v);else v[0]=dot(w.old()+size_t(r)*groups,input,groups);
   if(rv)residual_add(rv+size_t(w.correction.rank)*cols,residual_z.data(),w.correction.rank,r,step,v);
   if(w.channels&&!disable_channels){if(step!=8)throw std::runtime_error("cardinal requires lane8 integer kernel");w.channel_add(r,cq,v);}
   for(int j=0;j<step;j++){float value=v[j]+(bias?bias[r+j]:0);if(residual)out[r+j]+=value;else out[r+j]=value;if(residual&&!trace_dir.empty())diagnostic[r+j]=value;}
  }
  if(begin&&w.kind>=0)profile[w.kind]+=omp_get_wtime()-begin;
 }
 void batched_mm(const Matrix&w,const X8*q,const float*in,float*out,int rows,int cols,int batch,int stride){
  static const bool quad=std::getenv("SHUTTLE_Q4_QUAD")!=nullptr;
  static const bool paired=std::getenv("SHUTTLE_Q4_PAIR")!=nullptr;
  const uint16_t*rv=w.correction.rank?residual_store->get(w.correction.offset,w.correction.bytes):nullptr;
  if(rv){
   #pragma omp for schedule(static)
   for(int task=0;task<batch*int(w.correction.rank);task++){int t=task/w.correction.rank,k=task%w.correction.rank;residual_z[t*64+k]=residual_project(rv+size_t(k)*cols,in+size_t(t)*stride,cols);}
  }
  X8 cq[128];if(w.channels&&!disable_channels)for(int t=0;t<batch;t++)w.channel_quant(q+size_t(t)*(stride/64),cq+t*2);
  int groups=cols/64,tile=cols>4096?16:64,step=w.R&&kernel%2==0?w.R:1;
  for(int bt=0;bt<batch;bt+=tile){
   #pragma omp for schedule(static)
   for(int r=0;r<rows;r+=step)for(int t=bt;t<std::min(batch,bt+tile);t++){
    if(quad&&w.bits==4&&w.R==8&&kernel%2==0&&!rv&&!w.channels&&t+3<std::min(batch,bt+tile)){
     q4_panel4<288,false>(w.data+(r/8)*w.tilebytes(),q+size_t(t)*(stride/64),stride/64,groups,out+size_t(t)*rows+r,rows);t+=3;continue;
    }
    if(paired&&w.bits==4&&w.R==8&&kernel%2==0&&!rv&&!w.channels&&t+1<std::min(batch,bt+tile)){
     q4_pair(w.data+(r/8)*w.tilebytes(),q+size_t(t)*(stride/64),q+size_t(t+1)*(stride/64),groups,out+size_t(t)*rows+r,out+size_t(t+1)*rows+r);++t;continue;
    }
    if(w.R){if(kernel%2==0)w.tile(r,q+size_t(t)*(stride/64),out+size_t(t)*rows+r);else out[size_t(t)*rows+r]=w.floating(r,in+size_t(t)*stride);}
    else out[size_t(t)*rows+r]=kernel%2==0?dot8(w.old()+size_t(r)*groups,q+size_t(t)*(stride/64),groups):dot_float(w.old()+size_t(r)*groups,in+size_t(t)*stride,groups);
    if(rv)residual_add(rv+size_t(w.correction.rank)*cols,residual_z.data()+t*64,w.correction.rank,r,step,out+size_t(t)*rows+r);
    if(w.channels&&!disable_channels)w.channel_add(r,cq+t*2,out+size_t(t)*rows+r);
   }
  }
 }
 void prefill(const int*tokens,int count,int basepos=0,float*all_logits=nullptr){
  if(count<1||basepos<0||count>ctx||basepos>ctx-count)throw std::runtime_error("prefill context bounds");
  for(int t=0;t<count;t++)if(tokens[t]<0||unsigned(tokens[t])>=c.vocab)throw std::runtime_error("prefill token bounds");
  const int dim=c.dim,ffn=c.ff,hd=c.head_dim,heads=c.heads,dg=dim/64,fg=ffn/64,capacity=64;
  if(bx.empty()){bx.resize(size_t(capacity)*dim);bf.resize(size_t(capacity)*ffn);bq.resize(size_t(capacity)*qrows);ba.resize(size_t(capacity)*dim);bg.resize(size_t(capacity)*2*ffn);bo.resize(size_t(capacity)*dim);bs.resize(size_t(threads)*ctx);b8.resize(size_t(capacity)*fg);}
  #pragma omp parallel num_threads(threads)
  {
   FloatMode float_mode(ftz);ModelCounters counter(measure_counters);
   for(int chunk=0;chunk<count;chunk+=capacity){
    int start=basepos+chunk,batch=std::min(capacity,count-chunk);
    #pragma omp for schedule(static)
    for(int t=0;t<batch;t++)for(int g=0;g<dg;g++){
     float*p=bx.data()+size_t(t)*dim+g*64;
     for(int j=0;j<64;j++)p[j]=embedding.weight(tokens[chunk+t],g*64+j);
    }
    for(unsigned l=0;l<c.layers;l++){
     const Layer&a=layers[l];const int af=a.ff;
     if((a.active&1)&&!(skip_att&(uint64_t(1)<<l))){
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++)normq(bx.data()+size_t(t)*dim,a.an,bf.data()+size_t(t)*ffn,b8.data()+size_t(t)*fg,dim,c.eps);
     batched_mm(a.qkv,b8.data(),bf.data(),bq.data(),qrows,dim,batch,ffn);
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++){
      float*q=bq.data()+size_t(t)*qrows;int pos=start+t;
      for(int j=0;j<qrows;j++)q[j]+=a.bias[j];
      for(int h=0;h<heads+int(c.kvheads);h++)for(int j=0;j<hd/2;j++){
       float*v=q+h*hd;float av=v[j],bv=v[j+hd/2],co=cosines[pos*hd/2+j],si=sines[pos*hd/2+j];v[j]=av*co-bv*si;v[j+hd/2]=bv*co+av*si;
      }
      for(int j=0;j<kdim;j++){
       size_t at=(size_t(l)*ctx+pos)*kdim+j;
       if(kernel>=2){keys16[at]=_cvtss_sh(q[dim+j],0);values16[at]=_cvtss_sh(q[dim+kdim+j],0);}else{keys[at]=q[dim+j];values[at]=q[dim+kdim+j];}
      }
     }
     #pragma omp for schedule(static)
     for(int task=0;task<batch*heads;task++){
      int t=task/heads,h=task%heads,kv=h/(heads/c.kvheads),pos=start+t;float*pr=bs.data()+size_t(omp_get_thread_num())*ctx;float*av=ba.data()+size_t(t)*dim+h*hd;const float*q=bq.data()+size_t(t)*qrows+h*hd;float maxv=-INFINITY;
      for(int s=0;s<=pos;s++){
       size_t at=(size_t(l)*ctx+s)*kdim+kv*hd;__m256 v=_mm256_setzero_ps();
       if(kernel>=2){const uint16_t*k=keys16.data()+at;for(int j=0;j<hd;j+=8)v=_mm256_fmadd_ps(_mm256_loadu_ps(q+j),_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(k+j))),v);}
       else{const float*k=keys.data()+at;for(int j=0;j<hd;j+=8)v=_mm256_fmadd_ps(_mm256_loadu_ps(q+j),_mm256_loadu_ps(k+j),v);}
       float value=sum8(v)/std::sqrt(float(hd));pr[s]=value;maxv=std::max(maxv,value);
      }
      float sum=0;for(int s=0;s<=pos;s++){pr[s]=std::exp(pr[s]-maxv);sum+=pr[s];}std::fill(av,av+hd,0);
      if(kernel>=2&&register_attention)values_register(values16.data()+size_t(l)*ctx*kdim+kv*hd,pr,av,pos,kdim,hd,sum);
      else for(int s=0;s<=pos;s++){
       size_t at=(size_t(l)*ctx+s)*kdim+kv*hd;__m256 p=_mm256_set1_ps(pr[s]/sum);
       if(kernel>=2){const uint16_t*v=values16.data()+at;for(int j=0;j<hd;j+=8)_mm256_storeu_ps(av+j,_mm256_fmadd_ps(p,_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+j))),_mm256_loadu_ps(av+j)));}
       else{const float*v=values.data()+at;for(int j=0;j<hd;j+=8)_mm256_storeu_ps(av+j,_mm256_fmadd_ps(p,_mm256_loadu_ps(v+j),_mm256_loadu_ps(av+j)));}
      }
     }
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++){
      std::copy(ba.data()+size_t(t)*dim,ba.data()+size_t(t+1)*dim,bf.data()+size_t(t)*ffn);
      quantize(bf.data()+size_t(t)*ffn,b8.data()+size_t(t)*fg,dim);
     }
     batched_mm(a.o,b8.data(),bf.data(),bo.data(),dim,dim,batch,ffn);
     }
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++){
      if((a.active&1)&&!(skip_att&(uint64_t(1)<<l)))for(int j=0;j<dim;j++)bx[size_t(t)*dim+j]+=bo[size_t(t)*dim+j];
      if((a.active&2)&&!(skip_ffn&(uint64_t(1)<<l)))normq(bx.data()+size_t(t)*dim,a.fn,bf.data()+size_t(t)*ffn,b8.data()+size_t(t)*fg,dim,c.eps);
     }
     if((a.active&2)&&!(skip_ffn&(uint64_t(1)<<l))){
     if(residual_store){
      #pragma omp single
      residual_store->acquire(l);
     }
     if(ffn_image&&batch<=ffn_image->maxbatch){ffn_image->execute(l,b8.data(),fg,batch,bx.data());}
     else {
     batched_mm(a.gu,b8.data(),bf.data(),bg.data(),2*af,dim,batch,ffn);
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++){
      const float*g=bg.data()+size_t(t)*2*af;float*f=bf.data()+size_t(t)*ffn;
      for(int j=0;j<af;j++)f[j]=(g[j]/(1+std::exp(-g[j])))*g[af+j];
      prune(f,af,l);quantize(f,b8.data()+size_t(t)*fg,af);
     }
     batched_mm(a.down,b8.data(),bf.data(),bo.data(),dim,af,batch,ffn);
     #pragma omp for schedule(static)
     for(int j=0;j<batch*dim;j++)bx[j]+=bo[j];
     }
     if(residual_store){
      #pragma omp single
      residual_store->release(l);
     }
     }
    }
    if(all_logits){
     #pragma omp for schedule(static)
     for(int t=0;t<batch;t++)normq(bx.data()+size_t(t)*dim,finalnorm,bf.data()+size_t(t)*ffn,b8.data()+size_t(t)*fg,dim,c.eps);
     batched_mm(embedding,b8.data(),bf.data(),all_logits+size_t(chunk)*c.vocab,c.vocab,dim,batch,ffn);
     #pragma omp single
     std::copy(all_logits+size_t(chunk+batch-1)*c.vocab,all_logits+size_t(chunk+batch)*c.vocab,logits.data());
    }else if(chunk+batch==count){
     #pragma omp single
     normq(bx.data()+size_t(batch-1)*dim,finalnorm,xf.data(),x8.data(),dim,c.eps);
     matvec(embedding,xf.data(),logits.data(),c.vocab,dim);
    }
   }
   if(measure_counters){
    counter.stop();
    #pragma omp critical
    {for(int k=0;k<4;k++)counters[k]+=counter.value[k];pmu_errno=std::max(pmu_errno,counter.error);pmu_ratio=std::min(pmu_ratio,counter.ratio);}
   }
  }
  head_state_count=all_logits?count:0;
 }
 void forward(int token,int pos,bool output){
  if(token<0||unsigned(token)>=c.vocab||pos<0||pos>=ctx)throw std::runtime_error("token/context bounds");
  double begin=profiling?omp_get_wtime():0;
  const int dim=c.dim,ffn=c.ff,hd=c.head_dim,dg=dim/64,heads=c.heads;
  #pragma omp parallel num_threads(threads)
  {
   FloatMode float_mode(ftz);ModelCounters counter(measure_counters);
   #pragma omp for schedule(static)
   for(int g=0;g<dg;g++)for(int j=0;j<64;j++)x[g*64+j]=embedding.weight(token,g*64+j);
   for(unsigned l=0;l<c.layers;l++){
    const Layer&a=layers[l];const int af=a.ff;
    if(!reform_dir.empty()){
     #pragma omp single
     capture(pos,l,"pre",x.data(),dim);
    }
    if((a.active&1)&&!(skip_att&(uint64_t(1)<<l))){
    #pragma omp single
    {normq(x.data(),a.an,xf.data(),x8.data(),dim,c.eps);trace(pos,l,"qkv","in",xf.data(),dim);}
    matvec(a.qkv,xf.data(),qkv.data(),qrows,dim,false,a.bias);
    if(!trace_dir.empty()){
     #pragma omp single
     trace(pos,l,"qkv","out",qkv.data(),qrows);
    }
    #pragma omp for schedule(static)
    for(int h=0;h<heads+int(c.kvheads);h++){
     float*v=qkv.data()+h*hd;for(int j=0;j<hd/2;j++){float a=v[j],b=v[j+hd/2],co=cosines[pos*hd/2+j],si=sines[pos*hd/2+j];v[j]=a*co-b*si;v[j+hd/2]=b*co+a*si;}
    }
    #pragma omp for schedule(static)
    for(int j=0;j<kdim;j++){
     size_t at=(size_t(l)*ctx+pos)*kdim+j;
     if(kernel>=2){keys16[at]=_cvtss_sh(qkv[dim+j],0);values16[at]=_cvtss_sh(qkv[dim+kdim+j],0);}
     else{keys[at]=qkv[dim+j];values[at]=qkv[dim+kdim+j];}
    }
    double attention_begin=profiling&&omp_get_thread_num()==0?omp_get_wtime():0;
    #pragma omp for schedule(static)
    for(int h=0;h<heads;h++){
     int kv=h/(heads/c.kvheads);float*pr=att.data()+h*ctx;float*av=attout.data()+h*hd;const float*q=qkv.data()+h*hd;float maxv=-INFINITY;
     for(int t=0;t<=pos;t++){
      size_t at=(size_t(l)*ctx+t)*kdim+kv*hd;__m256 v=_mm256_setzero_ps();
      if(kernel>=2){const uint16_t*k=keys16.data()+at;for(int j=0;j<hd;j+=8)v=_mm256_fmadd_ps(_mm256_loadu_ps(q+j),_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(k+j))),v);}
      else{const float*k=keys.data()+at;for(int j=0;j<hd;j+=8)v=_mm256_fmadd_ps(_mm256_loadu_ps(q+j),_mm256_loadu_ps(k+j),v);}
      float s=sum8(v)/std::sqrt(float(hd));pr[t]=s;maxv=std::max(maxv,s);
     }
     float sum=0;for(int t=0;t<=pos;t++){pr[t]=std::exp(pr[t]-maxv);sum+=pr[t];}std::fill(av,av+hd,0);
     if(kernel>=2&&register_attention)values_register(values16.data()+size_t(l)*ctx*kdim+kv*hd,pr,av,pos,kdim,hd,sum);
     else for(int t=0;t<=pos;t++){
      size_t at=(size_t(l)*ctx+t)*kdim+kv*hd;__m256 p=_mm256_set1_ps(pr[t]/sum);
      if(kernel>=2){const uint16_t*v=values16.data()+at;for(int j=0;j<hd;j+=8)_mm256_storeu_ps(av+j,_mm256_fmadd_ps(p,_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+j))),_mm256_loadu_ps(av+j)));}
      else{const float*v=values.data()+at;for(int j=0;j<hd;j+=8)_mm256_storeu_ps(av+j,_mm256_fmadd_ps(p,_mm256_loadu_ps(v+j),_mm256_loadu_ps(av+j)));}
     }
    }
    if(attention_begin)profile[5]+=omp_get_wtime()-attention_begin;
    #pragma omp single
    {quantize(attout.data(),x8.data(),dim);trace(pos,l,"o","in",attout.data(),dim);}
    matvec(a.o,attout.data(),x.data(),dim,dim,true);
    if(!trace_dir.empty()){
     #pragma omp single
     trace(pos,l,"o","out",diagnostic.data(),dim);
    }
    }
    if(!reform_dir.empty()){
     #pragma omp single
     capture(pos,l,"mid",x.data(),dim);
    }
    if((a.active&2)&&!(skip_ffn&(uint64_t(1)<<l))){
    #pragma omp single
    {if(residual_store)residual_store->acquire(l);normq(x.data(),a.fn,xf.data(),x8.data(),dim,c.eps);trace(pos,l,"gate_up","in",xf.data(),dim);}
    if(ffn_image){
     double fb=profiling&&omp_get_thread_num()==0?omp_get_wtime():0;
     ffn_image->execute(l,x8.data(),dg,1,x.data(),trace_dir.empty()?nullptr:gu.data(),trace_dir.empty()?nullptr:ff.data(),trace_dir.empty()?nullptr:diagnostic.data());
     if(fb)profile[2]+=omp_get_wtime()-fb;
     if(!trace_dir.empty()){
      #pragma omp single
      {trace(pos,l,"gate_up","out",gu.data(),2*af);trace(pos,l,"down","in",ff.data(),ffn);trace(pos,l,"down","out",diagnostic.data(),dim);}
     }
    }else {
    matvec(a.gu,xf.data(),gu.data(),2*af,dim);
    if(!trace_dir.empty()){
     #pragma omp single
     trace(pos,l,"gate_up","out",gu.data(),2*af);
    }
    #pragma omp for schedule(static)
    for(int j=0;j<af;j++)ff[j]=(gu[j]/(1+std::exp(-gu[j])))*gu[af+j];
    #pragma omp single
    {prune(ff.data(),af,l);quantize(ff.data(),x8.data(),af);trace(pos,l,"down","in",ff.data(),af);}
    matvec(a.down,ff.data(),x.data(),dim,af,true);
    if(!trace_dir.empty()){
     #pragma omp single
     trace(pos,l,"down","out",diagnostic.data(),dim);
    }
    }
    if(residual_store){
     #pragma omp single
     residual_store->release(l);
    }
    }
    if(!reform_dir.empty()){
     #pragma omp single
     capture(pos,l,"post",x.data(),dim);
    }
   }
   if(output){
    #pragma omp single
    {normq(x.data(),finalnorm,xf.data(),x8.data(),dim,c.eps);trace(pos,-1,"embedding","in",xf.data(),dim);capture(pos,-1,"head",xf.data(),dim);}
    matvec(embedding,xf.data(),logits.data(),c.vocab,dim);
    if(!trace_dir.empty()){
     #pragma omp single
     trace(pos,-1,"embedding","out",logits.data(),c.vocab);
    }
   }
   if(measure_counters){
    counter.stop();
    #pragma omp critical
    {for(int k=0;k<4;k++)counters[k]+=counter.value[k];pmu_errno=std::max(pmu_errno,counter.error);pmu_ratio=std::min(pmu_ratio,counter.ratio);}
   }
  }
  if(output)head_state_count=0;
  if(begin){profile[6]+=omp_get_wtime()-begin;profile[7]++;}
 }
};
static thread_local std::string error;
extern "C" {
void shuttle_quantize(const float*x,int8_t*out,float*scales,int n){
 std::vector<X8>q(n/64);quantize(x,q.data(),n);for(int g=0;g<n/64;g++){memcpy(out+g*64,q[g].q,64);scales[g]=q[g].d;}
}
int shuttle_hidden(void*p,int row,float*out){try{if(!p||!out)throw std::runtime_error("null hidden request");auto*m=(Model*)p;if(row==-1&&m->head_state_count==0)memcpy(out,m->xf.data(),m->c.dim*sizeof(float));else if(row>=0&&row<m->head_state_count)memcpy(out,m->bf.data()+size_t(row)*m->c.ff,m->c.dim*sizeof(float));else throw std::runtime_error("hidden state slot unavailable");return 0;}catch(const std::exception&e){error=e.what();return -1;}}
int shuttle_embedding(void*p,int token,float*out){try{if(!p||!out)throw std::runtime_error("null embedding request");auto*m=(Model*)p;if(token<0||unsigned(token)>=m->c.vocab)throw std::runtime_error("embedding token bounds");for(unsigned j=0;j<m->c.dim;j++)out[j]=m->embedding.weight(token,j);return 0;}catch(const std::exception&e){error=e.what();return -1;}}
void* shuttle_predictor_load(const char*path){try{return new Predictor(path);}catch(const std::exception&e){error=e.what();return nullptr;}}
void shuttle_predictor_free(void*p){delete (Predictor*)p;}
int shuttle_predictor_run(void*model,void*predictor,int row,int token,int count,int*out,float*margins){try{if(!model||!predictor||!out||!margins)throw std::runtime_error("null predictor request");auto*m=(Model*)model;auto*p=(Predictor*)predictor;if(token<0||unsigned(token)>=m->c.vocab)throw std::runtime_error("predictor token");const float*state;if(row==-1&&m->head_state_count==0)state=m->xf.data();else if(row>=0&&row<m->head_state_count)state=m->bf.data()+size_t(row)*m->c.ff;else throw std::runtime_error("predictor state unavailable");memcpy(p->features.data(),state,1536*sizeof(float));for(int j=0;j<1536;j++)p->features[1536+j]=m->embedding.weight(token,j);p->run(count,out,margins);return 0;}catch(const std::exception&e){error=e.what();return -1;}}
int shuttle_predictor_values(void*predictor,const float*features,float*out){try{if(!predictor||!features||!out)throw std::runtime_error("null predictor check");auto*p=(Predictor*)predictor;memcpy(p->features.data(),features,3072*sizeof(float));int ids[3];float margins[3];p->run(3,ids,margins);memcpy(out,p->logits.data(),size_t(p->c.classes)*3*sizeof(float));return 0;}catch(const std::exception&e){error=e.what();return -1;}}
void shuttle_prune(void*p,int keep,uint64_t protect){auto*m=(Model*)p;m->keep_neurons=std::max(1,std::min(8960,keep));m->protect_neurons=protect;}
void shuttle_skip(void*p,uint64_t att,uint64_t ffn){auto*m=(Model*)p;m->skip_att=att;m->skip_ffn=ffn;}
const char* shuttle_error(){return error.c_str();}
void* shuttle_load(const char*path,int threads,int context,int kernel){try{omp_set_dynamic(0);return new Model(path,threads,context,kernel);}catch(const std::exception&e){error=e.what();return nullptr;}}
void shuttle_imc(void*p,double*out,int start){auto*m=(Model*)p;if(start)m->imc.start();else{m->imc.stop();if(out){out[0]=m->imc.bytes[0];out[1]=m->imc.bytes[1];out[2]=m->imc.seconds;out[3]=m->imc.ratio;out[4]=m->imc.error;}}}
void shuttle_counters(void*p,double*out,int reset){auto*m=(Model*)p;if(out){memcpy(out,m->counters,sizeof(m->counters));out[4]=m->pmu_ratio;out[5]=m->pmu_errno;}if(reset){memset(m->counters,0,sizeof(m->counters));m->pmu_ratio=1;m->pmu_errno=0;}}
void shuttle_profile(void*p,double*out,int reset){auto*m=(Model*)p;if(out)memcpy(out,m->profile,sizeof(m->profile));if(reset)memset(m->profile,0,sizeof(m->profile));}
void shuttle_storage(void*p,double*out,int reset){auto*m=(Model*)p;if(m->residual_store)m->residual_store->stats(out,reset);else if(out)memset(out,0,8*sizeof(double));}
void shuttle_free(void*p){delete (Model*)p;}
int shuttle_prefill(void*p,const int*tokens,int count,float*logits){try{if(!p||!logits)throw std::runtime_error("null argument");auto*m=(Model*)p;m->prefill(tokens,count);memcpy(logits,m->logits.data(),m->c.vocab*sizeof(float));return 0;}catch(const std::exception&e){error=e.what();return -1;}}
int shuttle_verify(void*p,const int*tokens,int count,int pos,float*all_logits){try{if(!p||!all_logits||count>16)throw std::runtime_error("verify bounds");((Model*)p)->prefill(tokens,count,pos,all_logits);return 0;}catch(const std::exception&e){error=e.what();return -1;}}
int shuttle_forward(void*p,int token,int pos,float*logits){try{if(!p)throw std::runtime_error("null model");auto*m=(Model*)p;m->forward(token,pos,logits!=nullptr);if(logits)memcpy(logits,m->logits.data(),m->c.vocab*sizeof(float));return 0;}catch(const std::exception&e){error=e.what();return -1;}}
}

extern "C" int shuttle_channel_probe(const char*path,int layer,int down,const float*input,float*out){
 try{Model m(path,1,1,4);if(layer<0||layer>=28)throw std::runtime_error("layer");const Matrix&w=down?m.layers[layer].down:m.layers[layer].gu;if(!w.channels)throw std::runtime_error("no correction");std::vector<X8>q(w.cols/64);quantize(input,q.data(),w.cols);X8 cq[2];w.channel_quant(q.data(),cq);for(int r=0;r<w.rows;r+=8){std::fill(out+r,out+r+8,0);w.channel_add(r,cq,out+r);}return 0;}catch(...){return -1;}
}
