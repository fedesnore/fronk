from run import run
import os
os.environ['SHUTTLE_Q4_QUAD']='1'
for name,model in [('q4','phase2/models/q4-lane8.bin'),('cardinal','phase5/models/q3-cardinal64-q4.bin'),('protected','phase5/models/q3-cardinal64-protected-down.bin')]:
 run(name+'-continuations',180,['python3','phase5/tests/check_continuations.py',name,model])
