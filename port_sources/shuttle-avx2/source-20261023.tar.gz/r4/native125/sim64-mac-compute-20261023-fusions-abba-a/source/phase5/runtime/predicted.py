"""Compiled small response model proposes; complete Q4 verifies every emitted token."""
from lookup import LookupEngine
import argparse,ctypes,json,pathlib,time,os
import numpy as np
class PredictedEngine(LookupEngine):
 def __init__(self,*args,predictor,draft_count=1,margin=0,policy=None,**kwargs):
  super().__init__(*args,**kwargs);self.draft_count=draft_count;self.margin=margin;self.predictor_path=predictor;self.predictor_seconds=0.;self.prediction_calls=0;self.hidden_slot=-1;self.native_predictor=None
  self.bigram=None;self.policy=json.loads(pathlib.Path(policy).read_text()) if policy else None;self.decision_counts={0:0,1:0,2:0,3:0}
  if self.policy:
   import hashlib
   if draft_count!=3 or self.policy['predictor_sha256']!=hashlib.sha256(pathlib.Path(predictor).read_bytes()).hexdigest():raise ValueError('policy predictor mismatch')
  if str(predictor).endswith('.json'):
   self.bigram={int(k):v for k,v in json.loads(pathlib.Path(predictor).read_text())['bigram'].items()}
  elif str(predictor).endswith('.bin'):
   self.lib.shuttle_predictor_load.argtypes=[ctypes.c_char_p];self.lib.shuttle_predictor_load.restype=ctypes.c_void_p
   self.lib.shuttle_predictor_free.argtypes=[ctypes.c_void_p]
   self.lib.shuttle_predictor_run.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p];self.lib.shuttle_predictor_run.restype=ctypes.c_int
   self.native_predictor=self.lib.shuttle_predictor_load(os.fsencode(predictor))
   if not self.native_predictor:raise RuntimeError(self.lib.shuttle_error().decode())
   self.native_ids=np.zeros(3,np.int32);self.native_margins=np.zeros(3,np.float32)
  else:
   with np.load(predictor) as archive:self.parameters={k:archive[k] for k in archive.files}
   self.output_weight=np.ascontiguousarray(self.parameters['w2'][:,:draft_count*len(self.parameters['vocab'])]);self.output_bias=self.parameters['b2'][:draft_count*len(self.parameters['vocab'])]
 def predict(self,pending):
  start=time.perf_counter();ids=[]
  if self.bigram is not None:
   for _ in range(self.draft_count):
    if pending not in self.bigram:break
    pending=int(self.bigram[pending]);ids.append(pending)
  elif self.native_predictor:
   rc=self.lib.shuttle_predictor_run(self.model,self.native_predictor,self.hidden_slot,pending,self.draft_count,self.native_ids.ctypes.data,self.native_margins.ctypes.data)
   if rc:raise RuntimeError(self.lib.shuttle_error().decode())
   for token,gap in zip(self.native_ids[:self.draft_count],self.native_margins[:self.draft_count]):
    if gap<self.margin:break
    ids.append(int(token))
   if self.policy:
    for bucket in self.policy['bins']:
     if bucket['upper'] is None or self.native_margins[0]<bucket['upper']:
      ids=ids[:bucket['draft_count']];break
  else:
   p=self.parameters;x=np.concatenate([self.hidden(self.hidden_slot),self.embedding(pending)]);x=np.clip((x-p['mean'])/p['std'],-8,8);h=np.tanh(x@p['w1']+p['b1']);scores=(h@self.output_weight+self.output_bias).reshape(self.draft_count,-1);vocab=p['vocab']
   for row in scores:
    at=int(np.argmax(row));best=float(row[at]);row[at]=-np.inf;gap=best-float(np.max(row))
    if gap<self.margin:break
    ids.append(int(vocab[at]))
  self.decision_counts[len(ids)]+=1;self.predictor_seconds+=time.perf_counter()-start;self.prediction_calls+=1;return ids
 def close(self):
  if getattr(self,'native_predictor',None):self.lib.shuttle_predictor_free(self.native_predictor);self.native_predictor=None
  super().close()
 def generate(self,prompt,max_tokens=128,temperature=0,seed=1,ignore_eos=False):
  if temperature!=0:raise ValueError('greedy exact verification only')
  if not 1<=self.draft_count<=3 or not 1<=max_tokens<=1024:raise ValueError('bounds')
  text='<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n'+prompt+'<|im_end|>\n<|im_start|>assistant\n';start=time.perf_counter();ids=self.tokenizer.encode(text,add_special_tokens=False).ids
  if len(ids)+max_tokens>self.context:raise ValueError('context bounds')
  self.prefill(ids);self.hidden_slot=-1;self.predictor_seconds=0.;self.prediction_calls=0;self.decision_counts={0:0,1:0,2:0,3:0};history=[];index={}
  def remember(token):
   history.append(token)
   for n in range(self.min_match,11):
    if len(history)>=n:
     key=tuple(history[-n:]);at=len(history)-n;index[key]=(index.get(key,[])+[at])[-2:]
  for token in ids:remember(token)
  def propose(cap):
   for n in range(min(10,len(history)),self.min_match-1,-1):
    for at in reversed(index.get(tuple(history[-n:]),[])):
     begin=at+n
     if begin<len(history):return history[begin:min(begin+min(cap,self.lookahead),len(history))],'history'
   if cap:return self.predict(history[-1])[:cap],'predictor'
   return [],'none'
  generated=[];previous='';emitted=[];prefill=time.perf_counter()-start;decode_start=time.perf_counter();pending=int(self.logits.argmax());pos=len(ids);calls=inputs=proposed=accepted=0;forward_s=0.;finished=False;by_source={k:dict(calls=0,proposed=0,matched=0) for k in ['history','predictor','none']}
  while len(generated)<max_tokens and not finished:
   if not generated:outputs=[pending]
   else:
    draft,source=propose(min(max(self.lookahead,self.draft_count),max_tokens-len(generated)-1));proposed+=len(draft);stats=by_source[source];stats['calls']+=1;stats['proposed']+=len(draft);t=time.perf_counter()
    if draft:
     if not self.monitor.is_alive():raise RuntimeError('safety monitor stopped')
     tokens=np.array([pending]+draft,np.int32);n=len(tokens)
     if self.lib.shuttle_verify(self.model,tokens.ctypes.data,n,pos,self.verification.ctypes.data):raise RuntimeError(self.lib.shuttle_error().decode())
     if not np.isfinite(self.verification[:n]).all():raise RuntimeError('non-finite logits')
     predictions=self.verification[:n].argmax(axis=1).tolist();matched=0
     while matched<len(draft) and predictions[matched]==draft[matched]:matched+=1
     self.hidden_slot=matched;outputs=draft[:matched]+[predictions[matched]];accepted+=matched;stats['matched']+=matched;inputs+=n;pos+=matched+1
    else:
     outputs=[int(self.forward(pending,pos).argmax())];self.hidden_slot=-1;pos+=1;inputs+=1
    forward_s+=time.perf_counter()-t;calls+=1
   for token in outputs:
    if token in [151643,151645] and not ignore_eos:finished=True;break
    if len(generated)>=max_tokens:break
    generated.append(token);remember(token);pending=token;decoded=self.tokenizer.decode(generated,skip_special_tokens=True);safe=decoded.rstrip('\ufffd');piece=safe[len(previous):] if safe.startswith(previous) else '';previous=safe;emitted.append(time.perf_counter()-decode_start)
    yield {'event':'token','token_id':token,'text':piece,'index':len(generated)-1,'elapsed_s':time.perf_counter()-start}
  wall=time.perf_counter()-decode_start;gaps=np.diff(emitted)*1000
  yield {'event':'metrics','implementation':'compiled-response-head-exact-greedy','predictor':str(self.predictor_path),'draft_count':self.draft_count,'margin':self.margin,'lookahead':self.lookahead,'min_match':self.min_match,'prompt_tokens':len(ids),'generated_tokens':len(generated),'decode_steps':max(0,len(generated)-1),'decode_wall_s':wall,'decode_wall_tok_s':max(0,len(generated)-1)/wall,'decode_forward_s':forward_s,'prefill_s':prefill,'target_graph_passes':calls,'target_input_positions':inputs,'proposed_tokens':proposed,'matched_draft_tokens':accepted,'predictor_seconds':self.predictor_seconds,'prediction_calls':self.prediction_calls,'decision_counts':self.decision_counts,'adaptive_policy':self.policy is not None,'sources':by_source,'intertoken_p95_ms':float(np.percentile(gaps,95)) if len(gaps) else None,'intertoken_max_ms':float(gaps.max()) if len(gaps) else None,'response':self.tokenizer.decode(generated,skip_special_tokens=True)}

def main():
 import socket,sys
 p=argparse.ArgumentParser();p.add_argument('--model',default='phase2/models/q4-lane8.bin');p.add_argument('--predictor',default='phase4b/models/predictor/response-e11-f32.bin');p.add_argument('--draft-count',type=int,choices=[1,3],default=1);p.add_argument('--policy');p.add_argument('--stdio',action='store_true');p.add_argument('--prompt',default='Explain why TCP is called a reliable transport protocol.');p.add_argument('--max-tokens',type=int,default=128);a=p.parse_args()
 e=PredictedEngine(a.model,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=2048,kernel=4,prefill='batch',lookahead=4,min_match=4,predictor=a.predictor,draft_count=a.draft_count,policy=a.policy)
 try:
  if a.stdio:
   print(json.dumps({'event':'ready','hostname':socket.gethostname(),'threads':8,'context':2048,'experimental':True,'output_authority':'unchanged Q4 greedy model'}),flush=True)
   for line in sys.stdin:
    try:
     request=json.loads(line)
     for result in e.generate(request['prompt'],request.get('max_tokens',128),request.get('temperature',0)):print(json.dumps(result,ensure_ascii=False),flush=True)
    except Exception as ex:print(json.dumps({'event':'error','error':str(ex)}),flush=True)
  else:
   for result in e.generate(a.prompt,a.max_tokens):print(json.dumps(result,ensure_ascii=False),flush=True)
 finally:e.close()

if __name__=='__main__':main()
