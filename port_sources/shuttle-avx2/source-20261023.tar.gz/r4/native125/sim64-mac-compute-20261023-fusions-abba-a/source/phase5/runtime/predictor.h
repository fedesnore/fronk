// Persistent response image. Small FP32 matrices use output-lane SIMD;
// the full Q4 transformer remains the authority for every emitted token.
struct Predictor {
 struct Header {char magic[8];uint32_t version,input,hidden,classes,actual,heads,layout,reserved[3];uint8_t pad[16];};
 static_assert(sizeof(Header)==64);
 int fd=-1;void*map=MAP_FAILED;size_t bytes=0,off=64;Header c{};
 const float *mean,*sd,*b1,*b2,*w1,*w2;const int32_t*vocab;
 std::vector<float>features,h,logits;
 template<class T>const T*take(size_t n){off=(off+63)&~size_t(63);if(off>bytes||n>(bytes-off)/sizeof(T))throw std::runtime_error("truncated predictor");const T*p=(const T*)((const char*)map+off);off+=n*sizeof(T);return p;}
 Predictor(const char*path){
  fd=open(path,O_RDONLY);if(fd<0)throw std::runtime_error("cannot open predictor");struct stat s;if(fstat(fd,&s)||s.st_size<64){close(fd);throw std::runtime_error("invalid predictor file");}bytes=s.st_size;map=mmap(nullptr,bytes,PROT_READ,MAP_PRIVATE,fd,0);if(map==MAP_FAILED){close(fd);throw std::runtime_error("predictor mmap");}
  try{
   memcpy(&c,map,64);if(memcmp(c.magic,"SHUTPRD1",8)||c.version!=1||c.input!=3072||c.hidden!=256||!c.classes||c.classes>2048||c.classes%8||!c.actual||c.actual>c.classes||c.heads!=3||c.layout!=1||c.reserved[0]||c.reserved[1]||c.reserved[2])throw std::runtime_error("predictor header");
   mean=take<float>(c.input);sd=take<float>(c.input);vocab=take<int32_t>(c.classes);b1=take<float>(c.hidden);b2=take<float>(c.heads*c.classes);w1=take<float>(size_t(c.hidden)*c.input);w2=take<float>(size_t(c.heads)*c.classes*c.hidden);if(off!=bytes)throw std::runtime_error("predictor trailing bytes");
   for(unsigned i=0;i<c.input;i++)if(!std::isfinite(mean[i])||!std::isfinite(sd[i])||sd[i]<=0)throw std::runtime_error("predictor normalization");
   for(unsigned i=0;i<c.actual;i++)if(vocab[i]<0||vocab[i]>=151936)throw std::runtime_error("predictor vocabulary");
   features.resize(c.input);h.resize(c.hidden);logits.resize(c.heads*c.classes);
  }catch(...){munmap(map,bytes);close(fd);throw;}
 }
 ~Predictor(){if(map!=MAP_FAILED)munmap(map,bytes);if(fd>=0)close(fd);}
 __attribute__((noinline)) static void dense(const float*w,const float*b,const float*x,float*y,int rows,int cols){
  int r=0;
  for(;r+32<=rows;r+=32){
   __m256 a0=_mm256_setzero_ps(),a1=a0,a2=a0,a3=a0;const float*p=w+size_t(r)*cols;
   for(int j=0;j<cols;j++){
    __m256 v=_mm256_set1_ps(x[j]);a0=_mm256_fmadd_ps(_mm256_loadu_ps(p+8*j),v,a0);a1=_mm256_fmadd_ps(_mm256_loadu_ps(p+8*cols+8*j),v,a1);a2=_mm256_fmadd_ps(_mm256_loadu_ps(p+16*cols+8*j),v,a2);a3=_mm256_fmadd_ps(_mm256_loadu_ps(p+24*cols+8*j),v,a3);
   }
   _mm256_storeu_ps(y+r,_mm256_add_ps(a0,_mm256_loadu_ps(b+r)));_mm256_storeu_ps(y+r+8,_mm256_add_ps(a1,_mm256_loadu_ps(b+r+8)));_mm256_storeu_ps(y+r+16,_mm256_add_ps(a2,_mm256_loadu_ps(b+r+16)));_mm256_storeu_ps(y+r+24,_mm256_add_ps(a3,_mm256_loadu_ps(b+r+24)));
  }
  for(;r<rows;r+=8){__m256 a=_mm256_setzero_ps();const float*p=w+size_t(r)*cols;for(int j=0;j<cols;j++)a=_mm256_fmadd_ps(_mm256_loadu_ps(p+8*j),_mm256_set1_ps(x[j]),a);_mm256_storeu_ps(y+r,_mm256_add_ps(a,_mm256_loadu_ps(b+r)));}
 }
 void run(int count,int*out,float*margins){
  if(count<1||count>3)throw std::runtime_error("predictor horizon");
  for(unsigned j=0;j<c.input;j++)features[j]=std::max(-8.f,std::min(8.f,(features[j]-mean[j])/sd[j]));
  dense(w1,b1,features.data(),h.data(),c.hidden,c.input);for(float&v:h)v=std::tanh(v);
  for(int head=0;head<count;head++){
   float*y=logits.data()+head*c.classes;dense(w2+size_t(head)*c.classes*c.hidden,b2+head*c.classes,h.data(),y,c.classes,c.hidden);float best=-INFINITY,second=-INFINITY;int at=-1;
   for(unsigned j=0;j<c.actual;j++){if(!std::isfinite(y[j]))throw std::runtime_error("non-finite predictor score");if(y[j]>best){second=best;best=y[j];at=j;}else second=std::max(second,y[j]);}
   out[head]=vocab[at];margins[head]=best-second;
  }
 }
};
