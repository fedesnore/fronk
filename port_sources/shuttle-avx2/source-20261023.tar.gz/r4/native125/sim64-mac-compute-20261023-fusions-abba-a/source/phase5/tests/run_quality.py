#!/usr/bin/env python3
import sys,pathlib,json,re,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'runtime'))
from infer import Engine
from guard import Telemetry
cases=json.loads(pathlib.Path('phase5/tests/quality_cases.json').read_text());engine=Engine(sys.argv[1],'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=2048,kernel=4,prefill="batch")
try:
 for case in cases:
  for result in engine.generate(case['prompt'],max_tokens=192):pass
  response=result['response'];passed=None
  if case['check']=='json':
   text=re.sub(r'^```(?:json)?\s*|\s*```$','',response.strip())
   try:passed=json.loads(text)==case['expected']
   except ValueError:passed=False
  print(json.dumps({'case':case,'automatic_pass':passed,'result':result},ensure_ascii=False),flush=True)
finally:engine.close()
