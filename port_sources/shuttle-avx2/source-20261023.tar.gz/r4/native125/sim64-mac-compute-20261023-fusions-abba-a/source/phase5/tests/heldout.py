#!/usr/bin/env python3
"""24 predeclared exact-answer diagnostics; unweighted quantization never uses them."""
import sys,pathlib,json,re
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'runtime'))
from infer import Engine
cases=json.loads(pathlib.Path('phase5/tests/heldout_cases.json').read_text())
def check(text,want):
 cleaned=re.sub(r'^```(?:json)?\s*|\s*```$','',text.strip())
 try:return json.loads(text)==want,json.loads(text)==want
 except ValueError:
  try:return False,json.loads(cleaned)==want
  except ValueError:return False,False
if sys.argv[1]=='prepare':
 from tokenizers import Tokenizer
 tok=Tokenizer.from_file('models/qwen2.5-1.5b-source/tokenizer.json');out=pathlib.Path('phase5/results/heldout-prompts.txt')
 with out.open('x') as f:
  for c in cases:
   text='<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n'+c['prompt']+'<|im_end|>\n<|im_start|>assistant\n'
   ids=tok.encode(text,add_special_tokens=False).ids;assert len(ids)<=128;f.write(' '.join(map(str,ids))+'\n')
 print(json.dumps({'cases':len(cases),'file':str(out)}));raise SystemExit()
if sys.argv[1]=='reference':
 from tokenizers import Tokenizer
 cap=int(sys.argv[3]) if len(sys.argv)>3 else 192
 assert 1<=cap<=192
 tok=Tokenizer.from_file('models/qwen2.5-1.5b-source/tokenizer.json');lines=pathlib.Path(sys.argv[2]).read_text().splitlines();responses=[tok.decode(json.loads(line)[:cap],skip_special_tokens=True) for line in lines if line.startswith('[')];assert len(responses)==len(cases)
else:
 cap=64
 e=Engine(sys.argv[1],'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=512,kernel=4,prefill='batch');responses=[]
 try:
  for c in cases:
   for event in e.generate(c['prompt'],max_tokens=64):pass
   responses.append(event['response'])
 finally:e.close()
strict=content=0
for c,response in zip(cases,responses):
 s,p=check(response,c['expected']);strict+=s;content+=p;print(json.dumps({'id':c['id'],'expected':c['expected'],'response':response,'strict_pass':s,'content_pass':p},ensure_ascii=False),flush=True)
print(json.dumps({'cases':len(cases),'strict_pass':strict,'content_pass':content,'generation_cap':cap}),flush=True)
