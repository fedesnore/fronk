#pragma once
// Explicit scratch-register dataflow, with one live int16 accumulator.
static inline __m256i q3_dot32_asm(const uint8_t*w,const int8_t*x,__m256i acc){
 const auto m7=_mm256_set1_epi8(7),m3=_mm256_set1_epi8(3),m1=_mm256_set1_epi8(1);
 #define ASM_DOT(offset) "vpbroadcastd " #offset "(%[x]), %%ymm10\n\tvpmaddubsw %%ymm10, %%ymm9, %%ymm9\n\tvpaddw %%ymm9, %[acc], %[acc]\n\t"
 asm volatile(
  "vmovdqu 0(%[w]), %%ymm6\n\tvmovdqu 32(%[w]), %%ymm7\n\tvmovdqu 64(%[w]), %%ymm8\n\t"
  "vpand %[m7], %%ymm6, %%ymm9\n\t" ASM_DOT(0)
  "vpsrlw $3, %%ymm6, %%ymm9\n\tvpand %[m7], %%ymm9, %%ymm9\n\t" ASM_DOT(4)
  "vpsrlw $6, %%ymm6, %%ymm9\n\tvpand %[m3], %%ymm9, %%ymm9\n\tvpand %[m1], %%ymm7, %%ymm10\n\tvpsllw $2, %%ymm10, %%ymm10\n\tvpor %%ymm10, %%ymm9, %%ymm9\n\t" ASM_DOT(8)
  "vpsrlw $1, %%ymm7, %%ymm9\n\tvpand %[m7], %%ymm9, %%ymm9\n\t" ASM_DOT(12)
  "vpsrlw $4, %%ymm7, %%ymm9\n\tvpand %[m7], %%ymm9, %%ymm9\n\t" ASM_DOT(16)
  "vpsrlw $7, %%ymm7, %%ymm9\n\tvpand %[m1], %%ymm9, %%ymm9\n\tvpand %[m3], %%ymm8, %%ymm10\n\tvpsllw $1, %%ymm10, %%ymm10\n\tvpor %%ymm10, %%ymm9, %%ymm9\n\t" ASM_DOT(20)
  "vpsrlw $2, %%ymm8, %%ymm9\n\tvpand %[m7], %%ymm9, %%ymm9\n\t" ASM_DOT(24)
  "vpsrlw $5, %%ymm8, %%ymm9\n\tvpand %[m7], %%ymm9, %%ymm9\n\t" ASM_DOT(28)
  :[acc]"+&x"(acc):[w]"r"(w),[x]"r"(x),[m7]"x"(m7),[m3]"x"(m3),[m1]"x"(m1):"ymm6","ymm7","ymm8","ymm9","ymm10","memory");
 #undef ASM_DOT
 return acc;
}
template<int R> __attribute__((noinline)) static void q3_asm_dot(const uint8_t*w,const X8*x,int groups,float*out){
 constexpr int S=R/8;__m256 total[S];for(int s=0;s<S;s++)total[s]=_mm256_setzero_ps();
 for(int g=0;g<groups;g++)for(int s=0;s<S;s++){
  const auto*p=w+(g*S+s)*224;auto acc=_mm256_setzero_si256();
  acc=q3_dot32_asm(p+32,x[g].q,acc);acc=q3_dot32_asm(p+128,x[g].q+32,acc);
  auto dot=_mm256_sub_epi32(_mm256_madd_epi16(acc,_mm256_set1_epi16(1)),_mm256_set1_epi32(x[g].sum*4));
  auto scale=_mm256_mul_ps(_mm256_loadu_ps((const float*)p),_mm256_set1_ps(x[g].d));total[s]=_mm256_fmadd_ps(_mm256_cvtepi32_ps(dot),scale,total[s]);
 }
 for(int s=0;s<S;s++)_mm256_storeu_ps(out+s*8,total[s]);
}
