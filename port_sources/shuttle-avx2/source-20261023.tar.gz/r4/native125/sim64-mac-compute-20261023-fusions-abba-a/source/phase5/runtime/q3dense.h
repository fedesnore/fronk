#pragma once
// Eight groups of four weights occupy three bytes per lane-byte position.
// All 64 columns accumulate in int16 pairs: 32*7*127 = 28448 < 32767.
template<int R> __attribute__((noinline)) static void q3_dense_dot(const uint8_t*w,const X8*x,int groups,float*out){
 constexpr int S=R/8,bytes=224;__m256 total[S];for(int s=0;s<S;s++)total[s]=_mm256_setzero_ps();
 const auto m7=_mm256_set1_epi8(7),m3=_mm256_set1_epi8(3),m4=_mm256_set1_epi8(4),m1=_mm256_set1_epi8(1),m6=_mm256_set1_epi8(6),ones=_mm256_set1_epi16(1);
 for(int g=0;g<groups;g++){
  __m256i acc[S];for(int s=0;s<S;s++)acc[s]=_mm256_setzero_si256();
  #pragma GCC unroll 1
  for(int j=0;j<2;j++)for(int s=0;s<S;s++){
   const auto*p=w+(g*S+s)*bytes+32+j*96;
   auto a=_mm256_loadu_si256((const __m256i*)p),b=_mm256_loadu_si256((const __m256i*)(p+32)),c=_mm256_loadu_si256((const __m256i*)(p+64));
   #define DOT(k,weight_codes) acc[s]=_mm256_add_epi16(acc[s],_mm256_maddubs_epi16(weight_codes,_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*32+k*4))))
   DOT(0,_mm256_and_si256(a,m7));DOT(1,_mm256_and_si256(_mm256_srli_epi16(a,3),m7));
   DOT(2,_mm256_or_si256(_mm256_and_si256(_mm256_srli_epi16(a,6),m3),_mm256_and_si256(_mm256_slli_epi16(b,2),m4)));
   DOT(3,_mm256_and_si256(_mm256_srli_epi16(b,1),m7));DOT(4,_mm256_and_si256(_mm256_srli_epi16(b,4),m7));
   DOT(5,_mm256_or_si256(_mm256_and_si256(_mm256_srli_epi16(b,7),m1),_mm256_and_si256(_mm256_slli_epi16(c,1),m6)));
   DOT(6,_mm256_and_si256(_mm256_srli_epi16(c,2),m7));DOT(7,_mm256_and_si256(_mm256_srli_epi16(c,5),m7));
   #undef DOT
  }
  auto correction=_mm256_set1_epi32(x[g].sum*4);auto xd=_mm256_set1_ps(x[g].d);
  for(int s=0;s<S;s++){
   auto v=_mm256_sub_epi32(_mm256_madd_epi16(acc[s],ones),correction);
   total[s]=_mm256_fmadd_ps(_mm256_cvtepi32_ps(v),_mm256_mul_ps(_mm256_loadu_ps((const float*)(w+(g*S+s)*bytes)),xd),total[s]);
  }
 }
 for(int s=0;s<S;s++)_mm256_storeu_ps(out+s*8,total[s]);
}
