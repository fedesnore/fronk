"""Verify every vocabulary logit and KV rollback against ordinary greedy forward."""
import sys,pathlib,ctypes,json
import numpy as np
sys.path.insert(0,'phase5/runtime');from infer import Engine
model=sys.argv[1];e=Engine(model,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=256,kernel=4)
e.lib.shuttle_verify.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_void_p];e.lib.shuttle_verify.restype=ctypes.c_int
ids=e.tokenizer.encode('The university develops research software. A careful experiment can reject a hypothesis. '*20,add_special_tokens=False).ids
try:
 for n in [1,2,4,8,16]:
  prefix=ids[:17];e.prefill(prefix);expected=[]
  for j,t in enumerate(ids[17:17+n]):expected.append(e.forward(t,17+j).copy())
  e.prefill(prefix);tokens=np.array(ids[17:17+n],np.int32);actual=np.empty((n,151936),np.float32);rc=e.lib.shuttle_verify(e.model,tokens.ctypes.data,n,17,actual.ctypes.data);assert rc==0,e.lib.shuttle_error().decode();assert np.array_equal(np.stack(expected),actual)
  # Discard the speculative tail and resume at an accepted prefix boundary.
  accept=n//2;probe=int(ids[40]);after=e.forward(probe,17+accept).copy();e.prefill(prefix)
  for j,t in enumerate(ids[17:17+accept]):e.forward(t,17+j)
  reference=e.forward(probe,17+accept).copy();assert np.array_equal(after,reference)
  print(json.dumps({'verification_inputs':n,'vocabulary_logits_checked':int(actual.size),'bit_exact':True,'rollback_bit_exact':True}),flush=True)
finally:e.close()
