#pragma once
// Eight output rows map to eight int32 / float32 lanes. A group has 64 columns.
// Each 8-row sub-tile: 8 FP32 scales, then 64*bits packed bytes.
static inline __m256i lane_dot8_rolled(__m256i q,__m256i x0,__m256i x1){
 const auto mask=_mm256_set1_epi8(15),ones=_mm256_set1_epi16(1);
 auto lo=_mm256_and_si256(q,mask),hi=_mm256_and_si256(_mm256_srli_epi16(q,4),mask);
 return _mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,x0),_mm256_maddubs_epi16(hi,x1)),ones);
}
template<int R,int B> __attribute__((noinline)) static void lane_dot_rolled(const uint8_t*w,const X8*x,int groups,float*out){
 constexpr int S=R/8,bytes=32+64*B;
 __m256 total[S];for(int s=0;s<S;s++)total[s]=_mm256_setzero_ps();
 const __m256i ones=_mm256_set1_epi16(1),mask2=_mm256_set1_epi8(3);
 for(int g=0;g<groups;g++){
  __m256i acc[S];for(int s=0;s<S;s++)acc[s]=_mm256_setzero_si256();
  if constexpr(B==4){
   #pragma GCC unroll 1
   for(int j=0;j<8;j++){
    auto x0=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*8));auto x1=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*8+4));
    for(int s=0;s<S;s++){auto q=_mm256_loadu_si256((const __m256i*)(w+(g*S+s)*bytes+32+j*32));acc[s]=_mm256_add_epi32(acc[s],lane_dot8_rolled(q,x0,x1));}
   }
  }else if constexpr(B==2){
   #pragma GCC unroll 1
   for(int j=0;j<4;j++){
    auto x0=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16)),x1=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+4));
    auto x2=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+8)),x3=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+12));
    for(int s=0;s<S;s++){
     auto q=_mm256_loadu_si256((const __m256i*)(w+(g*S+s)*bytes+32+j*32));
     auto p0=_mm256_maddubs_epi16(_mm256_and_si256(q,mask2),x0),p1=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,2),mask2),x1);
     auto p2=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,4),mask2),x2),p3=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,6),mask2),x3);
     // Four pairs <= 3048, still safely within int16.
     acc[s]=_mm256_add_epi32(acc[s],_mm256_madd_epi16(_mm256_add_epi16(_mm256_add_epi16(p0,p1),_mm256_add_epi16(p2,p3)),ones));
    }
   }
  }else if constexpr(B==3){
   const auto shifts=_mm256_setr_epi32(0,4,8,12,16,20,24,28);
   #pragma GCC unroll 1
   for(int j=0;j<16;j++){
    auto xx=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*4));
    for(int s=0;s<S;s++){
     const auto*p=w+(g*S+s)*bytes+32;
     auto low=_mm256_and_si256(_mm256_srl_epi16(_mm256_loadu_si256((const __m256i*)(p+(j/4)*32)),_mm_cvtsi32_si128((j%4)*2)),mask2);
     auto h=_mm256_and_si256(_mm256_srlv_epi32(_mm256_set1_epi32(*(const int32_t*)(p+128+j*4)),shifts),_mm256_set1_epi32(15));
     h=_mm256_slli_epi32(_mm256_and_si256(_mm256_mullo_epi32(h,_mm256_set1_epi32(0x00204081)),_mm256_set1_epi32(0x01010101)),2);
     auto v=_mm256_madd_epi16(_mm256_maddubs_epi16(_mm256_or_si256(low,h),xx),ones);acc[s]=_mm256_add_epi32(acc[s],v);
    }
   }
  }
  auto correction=_mm256_set1_epi32(x[g].sum*(1<<(B-1)));auto xd=_mm256_set1_ps(x[g].d);
  for(int s=0;s<S;s++){
   auto scale=_mm256_mul_ps(_mm256_loadu_ps((const float*)(w+(g*S+s)*bytes)),xd);
   total[s]=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(acc[s],correction)),scale,total[s]);
  }
 }
 for(int s=0;s<S;s++)_mm256_storeu_ps(out+s*8,total[s]);
}
