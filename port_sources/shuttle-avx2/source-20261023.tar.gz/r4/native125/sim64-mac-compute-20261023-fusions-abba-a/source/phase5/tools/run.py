import os,pathlib,subprocess,sys,json
os.environ.update(PYTHONPATH='vendor/python',OPENBLAS_NUM_THREADS='1',OMP_PROC_BIND='true',OMP_PLACES='{0},{1},{2},{3},{4},{5},{6},{7}',OMP_WAIT_POLICY='ACTIVE')
def run(name,timeout,cmd):
 print('START',name,flush=True)
 r=subprocess.run([sys.executable,'phase5/tools/coolrun.py','--out','phase5/results/'+name,'--timeout',str(timeout),'--',*cmd],stdout=subprocess.PIPE,text=True)
 if r.returncode:
  try:d=json.loads(r.stdout);print('FAILED',name,d.get('reason',d.get('returncode')),flush=True)
  except ValueError:print(r.stdout[-2000:],flush=True)
  raise SystemExit(r.returncode)
 lines=pathlib.Path('phase5/results/'+name+'/stdout.txt').read_text().splitlines();print('FINISH',name,lines[-1][:2000] if lines else '',flush=True)
if __name__=='__main__':
 raise SystemExit('Import run() from a named phase-four experiment driver; no default workload.')
