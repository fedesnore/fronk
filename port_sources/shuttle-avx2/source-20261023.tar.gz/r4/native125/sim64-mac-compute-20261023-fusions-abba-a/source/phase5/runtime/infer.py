#!/usr/bin/env python3
"""All model execution, tokenization, cache, and sampling take place on the Shuttle."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_PROC_BIND','true')
os.environ.setdefault('OMP_PLACES','{0},{1},{2},{3},{4},{5},{6},{7}')
os.environ.setdefault('OMP_WAIT_POLICY','ACTIVE')
import argparse,ctypes,json,pathlib,socket,sys,time,threading
import numpy as np
from tokenizers import Tokenizer
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from guard import Telemetry

class Engine:
 def __init__(self,model,tokenizer,threads=8,context=2048,kernel=0,prefill="serial"):
  if socket.gethostname().split('.')[0]!='netlab-shuttle09':raise RuntimeError('inference is restricted to the reference node')
  self.telemetry=Telemetry();deadline=time.monotonic()+60
  # Imports can briefly warm a core. Wait passively; retain the same start guard.
  self.initial=self.telemetry.sample()
  if max(self.initial['temp_c'].values())>=55:
   print('Waiting for the Shuttle to cool below 55 C before inference.',file=sys.stderr,flush=True)
  while max(self.initial['temp_c'].values())>=55:
   issue=self.telemetry.violation(self.initial,self.initial)
   if issue:raise RuntimeError(issue)
   if time.monotonic()>=deadline:raise RuntimeError('cooldown exceeded; no inference started')
   time.sleep(0.5);self.initial=self.telemetry.sample()
  self.last_check=time.monotonic()
  issue=self.telemetry.violation(self.initial,self.initial,starting=True)
  if issue:raise RuntimeError(issue)
  self.lib=ctypes.CDLL(str(pathlib.Path(__file__).resolve().parents[1]/'build/libshuttle.so'))
  self.lib.shuttle_load.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.c_int,ctypes.c_int];self.lib.shuttle_load.restype=ctypes.c_void_p
  self.lib.shuttle_hidden.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];self.lib.shuttle_hidden.restype=ctypes.c_int
  self.lib.shuttle_embedding.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];self.lib.shuttle_embedding.restype=ctypes.c_int
  self.lib.shuttle_error.restype=ctypes.c_char_p
  self.lib.shuttle_forward.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_void_p];self.lib.shuttle_forward.restype=ctypes.c_int
  self.lib.shuttle_prefill.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];self.lib.shuttle_prefill.restype=ctypes.c_int
  self.lib.shuttle_imc.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int]
  self.lib.shuttle_counters.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int]
  self.lib.shuttle_profile.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int]
  self.lib.shuttle_storage.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int]
  self.lib.shuttle_free.argtypes=[ctypes.c_void_p]
  self.lib.omp_pause_resource_all.argtypes=[ctypes.c_int];self.lib.omp_pause_resource_all.restype=ctypes.c_int
  self.model=self.lib.shuttle_load(os.fsencode(model),threads,context,kernel)
  if not self.model:raise RuntimeError(self.lib.shuttle_error().decode())
  self.prefill_mode=prefill;self.stop_monitor=threading.Event()
  self.monitor=threading.Thread(target=self.watch_safety,daemon=True);self.monitor.start()
  self.context=context;self.tokenizer=Tokenizer.from_file(str(tokenizer));self.logits=np.zeros(151936,dtype=np.float32)
 def hidden(self,row=-1):
  out=np.empty(1536,np.float32)
  if self.lib.shuttle_hidden(self.model,row,out.ctypes.data):raise RuntimeError(self.lib.shuttle_error().decode())
  return out
 def embedding(self,token):
  out=np.empty(1536,np.float32)
  if self.lib.shuttle_embedding(self.model,int(token),out.ctypes.data):raise RuntimeError(self.lib.shuttle_error().decode())
  return out
 def watch_safety(self):
  # ctypes releases the GIL, so telemetry continues during a whole batched prompt.
  while not self.stop_monitor.wait(0.25):
   try:issue=self.telemetry.violation(self.telemetry.sample(),self.initial)
   except Exception as e:issue='telemetry unavailable: '+str(e)
   if issue:
    print(json.dumps({'event':'error','error':'safety stop: '+issue}),file=sys.stderr,flush=True)
    os._exit(70)
 def prefill(self,ids):
  tokens=np.asarray(ids,dtype=np.int32)
  if self.lib.shuttle_prefill(self.model,tokens.ctypes.data,len(tokens),self.logits.ctypes.data):raise RuntimeError(self.lib.shuttle_error().decode())
  if not np.isfinite(self.logits).all():raise RuntimeError('non-finite prefill logits')
  return self.logits
 def forward(self,token,pos,output=True):
  if time.monotonic()-self.last_check>=0.25:
   # The persistent safety monitor covers inference and batched prefill.
   # NVMe hwmon reads can block for ~25 ms: never put them on the token path.
   if not self.monitor.is_alive():raise RuntimeError('safety monitor stopped')
   if os.getenv('SHUTTLE_FOREGROUND_TELEMETRY'):
    sample=self.telemetry.sample();issue=self.telemetry.violation(sample,self.initial)
    if issue:raise RuntimeError(issue)
   self.last_check=time.monotonic()
  if self.lib.shuttle_forward(self.model,token,pos,self.logits.ctypes.data if output else None):raise RuntimeError(self.lib.shuttle_error().decode())
  if output and not np.isfinite(self.logits).all():raise RuntimeError('non-finite logits')
  return self.logits
 def generate(self,prompt,max_tokens=128,temperature=0,seed=1,ignore_eos=False):
  if not isinstance(prompt,str) or not 1<=max_tokens<=1024 or not 0<=temperature<=2:raise ValueError('invalid request')
  # Explicit Qwen ChatML; the tokenizer and template run only on the node.
  text='<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n'+prompt+'<|im_end|>\n<|im_start|>assistant\n'
  start=time.perf_counter();ids=self.tokenizer.encode(text,add_special_tokens=False).ids
  if len(ids)+max_tokens>self.context:raise ValueError('prompt + output exceeds configured context')
  if self.prefill_mode=="batch":self.prefill(ids)
  else:
   for pos,token in enumerate(ids):self.forward(token,pos,output=pos==len(ids)-1)
  self.lib.shuttle_storage(self.model,None,1);self.lib.shuttle_profile(self.model,None,1);self.lib.shuttle_counters(self.model,None,1)
  if os.getenv('SHUTTLE_IMC'):self.lib.shuttle_imc(self.model,None,1)
  prefill=time.perf_counter()-start;rng=np.random.default_rng(seed);generated=[];previous='';latencies=[];decode_start=time.perf_counter();stall_ms=[];storage_previous=0.0
  for i in range(max_tokens):
   if temperature==0:token=int(np.argmax(self.logits))
   else:
    top=np.argpartition(self.logits,-40)[-40:];scores=self.logits[top].astype(np.float64)/temperature;scores-=scores.max();prob=np.exp(scores);prob/=prob.sum();token=int(rng.choice(top,p=prob))
   if token in (151643,151645) and not ignore_eos:break
   generated.append(token);decoded=self.tokenizer.decode(generated,skip_special_tokens=True)
   # Hold an incomplete UTF-8 suffix until enough tokens have arrived.
   safe=decoded.rstrip('\ufffd');piece=safe[len(previous):] if safe.startswith(previous) else ''
   if piece:previous=safe
   yield {'event':'token','token_id':token,'text':piece,'index':i,'elapsed_s':time.perf_counter()-start}
   if i+1<max_tokens:
    t=time.perf_counter();self.forward(token,len(ids)+i);latencies.append(time.perf_counter()-t)
    storage=np.zeros(8,dtype=np.float64);self.lib.shuttle_storage(self.model,storage.ctypes.data,0);stall_ms.append((storage[0]-storage_previous)*1000);storage_previous=storage[0]
  wall=time.perf_counter()-decode_start
  imc=np.zeros(5,dtype=np.float64)
  if os.getenv('SHUTTLE_IMC'):self.lib.shuttle_imc(self.model,imc.ctypes.data,0)
  counters=np.zeros(6,dtype=np.float64);self.lib.shuttle_counters(self.model,counters.ctypes.data,0)
  profile=np.zeros(8,dtype=np.float64);self.lib.shuttle_profile(self.model,profile.ctypes.data,0)
  storage=np.zeros(8,dtype=np.float64);self.lib.shuttle_storage(self.model,storage.ctypes.data,0)
  yield {'event':'metrics','storage':dict(zip(['exposed_wait_s','wait_count','consumed_bytes','read_bytes','read_seconds','arena_bytes','all_slots_mlocked','mode'],storage.tolist())), 'ssd_stall_ms_mean':float(np.mean(stall_ms)) if stall_ms else None,'ssd_stall_ms_p95':float(np.percentile(stall_ms,95)) if stall_ms else None,'ssd_stall_ms_p99':float(np.percentile(stall_ms,99)) if stall_ms else None,'imc':dict(zip(['read_bytes','write_bytes','seconds','running_ratio','errno'],imc.tolist())) if os.getenv('SHUTTLE_IMC') else None,'counters':dict(zip(['thread_cycles','instructions','cache_misses',(({'L2_HIT':'L2_demand_read_hits','L2_MISS':'L2_demand_read_misses'}.get(os.getenv('SHUTTLE_CACHE_COUNTER'),'L1D_read_misses')) if os.getenv('SHUTTLE_CACHE_COUNTER') else 'fp_assist_cycles'),'running_ratio','errno'],counters.tolist())) if os.getenv('SHUTTLE_COUNTERS') else None,'profile':dict(zip(['qkv_s','o_s',('ffn_superblock_s' if os.getenv('SHUTTLE_FFN_IMAGE') else 'gate_up_s'),'down_s','head_s','attention_s','forward_s','steps'],profile.tolist())) if os.getenv('SHUTTLE_PROFILE') else None,'prefill_mode':self.prefill_mode,'prompt_tokens':len(ids),'generated_tokens':len(generated),'decode_steps':len(latencies),'prefill_s':prefill,'decode_wall_s':wall,'decode_forward_s':sum(latencies),'decode_forward_tok_s':len(latencies)/sum(latencies) if latencies else None,'decode_wall_tok_s':len(latencies)/wall if latencies else None,'median_step_ms':float(np.median(latencies)*1000) if latencies else None,'p95_step_ms':float(np.percentile(latencies,95)*1000) if latencies else None,'response':self.tokenizer.decode(generated,skip_special_tokens=True)}
 def close(self):
  self.stop_monitor.set();self.monitor.join(timeout=1)
  if self.model:self.lib.shuttle_free(self.model);self.model=None
  # Called only after this single-engine runtime leaves every parallel region.
  # OpenMP 5 omp_pause_hard=2 releases workers that ACTIVE would retain spinning.
  if self.lib.omp_pause_resource_all(2):raise RuntimeError('OpenMP worker release failed')

def main():
 p=argparse.ArgumentParser();p.add_argument('--model',default='models/qwen2.5-1.5b-native.bin');p.add_argument('--tokenizer',default='models/qwen2.5-1.5b-source/tokenizer.json');p.add_argument('--threads',type=int,default=8);p.add_argument('--context',type=int,default=2048);p.add_argument('--kernel',type=int,choices=[0,1,2,3,4],default=0);p.add_argument('--prefill',choices=['serial','batch'],default='serial');p.add_argument('--prompt');p.add_argument('--max-tokens',type=int,default=128);p.add_argument('--stdio',action='store_true');p.add_argument('--ignore-eos',action='store_true');a=p.parse_args()
 engine=Engine(a.model,a.tokenizer,a.threads,a.context,a.kernel,a.prefill)
 try:
  if a.stdio:
   print(json.dumps({'event':'ready','hostname':socket.gethostname(),'threads':a.threads,'context':a.context}),flush=True)
   for line in sys.stdin:
    try:
     request=json.loads(line)
     for result in engine.generate(request['prompt'],request.get('max_tokens',128),request.get('temperature',0),request.get('seed',1)):print(json.dumps(result,ensure_ascii=False),flush=True)
    except Exception as e:print(json.dumps({'event':'error','error':str(e)}),flush=True)
  else:
   for result in engine.generate(a.prompt or 'Explain why TCP is called a reliable transport protocol.',a.max_tokens,ignore_eos=a.ignore_eos):print(json.dumps(result,ensure_ascii=False),flush=True)
 finally:engine.close()
if __name__=='__main__':main()
