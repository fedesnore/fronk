from run import run
import os
os.environ.update(SHUTTLE_Q4_QUAD='1',SHUTTLE_COUNTERS='1',SHUTTLE_IMC='1',SHUTTLE_PROFILE='1')
for name,model in [('q4','phase2/models/q4-lane8.bin'),('cardinal','phase5/models/q3-cardinal64-q4.bin'),('protected','phase5/models/q3-cardinal64-protected-down.bin')]:
 run(name+'-counters-priv-256',120,['python3','phase5/runtime/infer.py','--model',model,'--kernel','4','--prefill','batch','--max-tokens','256','--ignore-eos'])
