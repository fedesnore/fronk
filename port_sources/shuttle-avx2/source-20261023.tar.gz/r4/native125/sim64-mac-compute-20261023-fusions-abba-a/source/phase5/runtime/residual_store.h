// Explicit execution-ready correction tier. No file-cache reads in direct modes.
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>
#include <cerrno>
#include <sched.h>
#include <pthread.h>
struct ResidualHeader {uint32_t rank,format;uint64_t offset,bytes,reserved;};
static_assert(sizeof(ResidualHeader)==32);
struct ResidualStore {
 struct Block{uint64_t offset,bytes;};struct Slot{uint8_t*p=nullptr;int state=0;uint64_t ticket=0;};
 int fd=-1,mode=0,group_layers=1,nslots=0;size_t size=0,slot_bytes=0;void*map=MAP_FAILED;bool locked=false;
 std::vector<Block>blocks;std::vector<Slot>slots;std::thread worker;std::mutex mutex;std::condition_variable cv;bool stopping=false;std::string failure;
 uint64_t consume_ticket=0,active_offset=0,active_bytes=0,consumed_bytes=0,waits=0;uint8_t*active=nullptr;double wait_seconds=0;
 std::atomic<uint64_t>read_bytes{0};std::atomic<uint64_t>read_nanoseconds{0};
 static double now(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}
 ResidualStore(const std::string&path,const std::vector<Block>&layers,int rank){
  std::string requested=std::getenv("SHUTTLE_STREAM")?std::getenv("SHUTTLE_STREAM"):"resident";
  if(requested=="resident")mode=0;else if(requested=="sync")mode=1;else if(requested=="async")mode=2;else throw std::runtime_error("invalid SHUTTLE_STREAM");
  fd=open(path.c_str(),O_RDONLY|O_CLOEXEC|(mode?O_DIRECT:0));if(fd<0)throw std::runtime_error("residual open");
  struct stat st;if(fstat(fd,&st)||st.st_size<4096){close(fd);throw std::runtime_error("residual size");}size=st.st_size;
  void*header=nullptr;if(posix_memalign(&header,4096,4096))throw std::runtime_error("residual header allocation");ssize_t got=pread(fd,header,4096,0);bool valid=got==4096&&!memcmp(header,"SHUTRES1",8)&&((uint32_t*)header)[2]==1&&((uint32_t*)header)[3]==28&&((uint32_t*)header)[4]==unsigned(rank);free(header);if(!valid)throw std::runtime_error("residual header");
  group_layers=rank<=16?4:2;if(const char*s=std::getenv("SHUTTLE_IO_GROUP_LAYERS"))group_layers=std::stoi(s);
  if(group_layers<1||group_layers>28||28%group_layers)throw std::runtime_error("invalid group layers");
  for(size_t i=0;i<layers.size();i+=group_layers){uint64_t begin=layers[i].offset,end=layers[i+group_layers-1].offset+layers[i+group_layers-1].bytes;if(begin%4096||end%4096||end>size)throw std::runtime_error("unaligned correction block");blocks.push_back({begin,end-begin});slot_bytes=std::max(slot_bytes,size_t(end-begin));}
  if(mode==0){map=mmap(nullptr,size,PROT_READ,MAP_PRIVATE,fd,0);if(map==MAP_FAILED)throw std::runtime_error("residual mmap");return;}
  nslots=mode==1?1:2;if(mode==2)if(const char*s=std::getenv("SHUTTLE_IO_SLOTS"))nslots=std::stoi(s);
  if(nslots<1||nslots>8||slot_bytes*nslots>64*1024*1024)throw std::runtime_error("correction arena bounds");
  slots.resize(nslots);locked=true;
  for(auto&s:slots){if(posix_memalign((void**)&s.p,4096,slot_bytes))throw std::runtime_error("arena allocation");memset(s.p,0,slot_bytes);if(mlock(s.p,slot_bytes))locked=false;}
  if(!locked)for(auto&s:slots)munlock(s.p,slot_bytes);
  if(mode==2)worker=std::thread([this]{produce();});
 }
 ~ResidualStore(){if(worker.joinable()){{std::lock_guard<std::mutex>l(mutex);stopping=true;}cv.notify_all();worker.join();}for(auto&s:slots){if(s.p){munlock(s.p,slot_bytes);free(s.p);}}if(map!=MAP_FAILED)munmap(map,size);if(fd>=0)close(fd);}
 bool read(Block b,uint8_t*p){double t=now();ssize_t n;do{n=pread(fd,p,b.bytes,b.offset);}while(n<0&&errno==EINTR);if(n!=ssize_t(b.bytes))return false;read_bytes.fetch_add(n);read_nanoseconds.fetch_add(uint64_t((now()-t)*1e9));return true;}
 void produce(){
  if(const char*p=std::getenv("SHUTTLE_IO_CPU")){int cpu=std::atoi(p);cpu_set_t set;CPU_ZERO(&set);if(cpu>=0&&cpu<8)CPU_SET(cpu,&set);if(cpu<0||cpu>=8||pthread_setaffinity_np(pthread_self(),sizeof(set),&set)){std::lock_guard<std::mutex>l(mutex);failure="I/O affinity failed";stopping=true;cv.notify_all();return;}}
  // One persistent I/O owner keeps large sequential transfers in flight.
  for(uint64_t ticket=0;;ticket++){
   auto&s=slots[ticket%nslots];{std::unique_lock<std::mutex>l(mutex);cv.wait(l,[&]{return stopping||s.state==0;});if(stopping)return;s.state=1;}
   bool ok=read(blocks[ticket%blocks.size()],s.p);
   {std::lock_guard<std::mutex>l(mutex);if(!ok){failure="direct correction read failed";stopping=true;}else{s.state=2;s.ticket=ticket;}}cv.notify_all();if(!ok)return;
  }
 }
 void acquire(int layer){
  if(layer%group_layers)return;auto b=blocks[layer/group_layers];active_offset=b.offset;active_bytes=b.bytes;
  if(mode==0){active=(uint8_t*)map+b.offset;return;}
  if(consume_ticket%blocks.size()!=size_t(layer/group_layers))throw std::runtime_error("correction schedule mismatch");
  auto&s=slots[consume_ticket%nslots];double t=now();
  if(mode==1){if(!read(b,s.p))throw std::runtime_error("direct correction read failed");waits++;wait_seconds+=now()-t;}
  else{std::unique_lock<std::mutex>l(mutex);if(s.state!=2){waits++;cv.wait(l,[&]{return stopping||(s.state==2&&s.ticket==consume_ticket);});wait_seconds+=now()-t;}if(stopping)throw std::runtime_error(failure);if(s.ticket!=consume_ticket)throw std::runtime_error("correction ticket mismatch");s.state=3;}
  active=s.p;consumed_bytes+=b.bytes;
 }
 void release(int layer){
  if((layer+1)%group_layers||mode==0)return;
  if(mode==2){{std::lock_guard<std::mutex>l(mutex);slots[consume_ticket%nslots].state=0;}cv.notify_all();}consume_ticket++;active=nullptr;
 }
 const uint16_t*get(uint64_t offset,uint64_t bytes)const{
  if(mode==0){if(offset+bytes>size)throw std::runtime_error("correction extent");return (const uint16_t*)((const uint8_t*)map+offset);}
  if(!active||offset<active_offset||offset+bytes>active_offset+active_bytes)throw std::runtime_error("correction outside active slot");return (const uint16_t*)(active+offset-active_offset);
 }
 void stats(double*out,bool reset){if(out){out[0]=wait_seconds;out[1]=waits;out[2]=consumed_bytes;out[3]=read_bytes.load();out[4]=read_nanoseconds.load()/1e9;out[5]=slot_bytes*nslots;out[6]=locked;out[7]=mode;}
  if(reset){wait_seconds=0;waits=0;consumed_bytes=0;read_bytes.store(0);read_nanoseconds.store(0);}}
};
static float residual_project(const uint16_t*v,const float*x,int n){
 __m256 a=_mm256_setzero_ps(),b=a,c=a,d=a;
 for(int k=0;k<n;k+=32){a=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+k))),_mm256_loadu_ps(x+k),a);b=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+k+8))),_mm256_loadu_ps(x+k+8),b);c=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+k+16))),_mm256_loadu_ps(x+k+16),c);d=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+k+24))),_mm256_loadu_ps(x+k+24),d);}
 return sum8(_mm256_add_ps(_mm256_add_ps(a,b),_mm256_add_ps(c,d)));
}
static void residual_add(const uint16_t*u,const float*z,int rank,int row,int step,float*out){
 for(int j=0;j<step;j+=8){__m256 a=_mm256_setzero_ps();const uint16_t*p=u+size_t((row+j)/8)*rank*8;
  for(int k=0;k<rank;k++)a=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(p+k*8))),_mm256_set1_ps(z[k]),a);
  if(step==1){float v[8];_mm256_storeu_ps(v,a);out[0]+=v[row%8];}else _mm256_storeu_ps(out+j,_mm256_add_ps(_mm256_loadu_ps(out+j),a));
 }
}
