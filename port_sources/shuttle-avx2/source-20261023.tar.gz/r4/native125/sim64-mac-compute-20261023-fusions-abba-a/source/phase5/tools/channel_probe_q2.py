"""CPU-native cardinal correction screen; no evaluation prompts used in fitting."""
import sys,pathlib,json,time,socket
assert socket.gethostname().split('.')[0]=='netlab-shuttle09'
import numpy as np
sys.path.insert(0,'phase5/tests')
from image_reader import Image
from guard import Telemetry
mon=Telemetry();last=0
def pace(delay=.05):
 global last
 time.sleep(delay)
 if time.monotonic()-last<1:return
 end=time.monotonic()+60
 while True:
  s=mon.sample();last=time.monotonic()
  if max(s['temp_c'].values())<60 and max(s['storage_temp_c'].values())<55:return
  if time.monotonic()>end:raise RuntimeError('offline cooldown deadline')
  time.sleep(1)
def q8(x):
 b=x.reshape(len(x),-1,64);m=np.max(np.abs(b),axis=2);d=m/np.float32(127);inv=np.divide(127,m,out=np.zeros_like(m),where=m!=0)
 return (np.clip(np.rint(b*inv[:,:,None]),-127,127)*d[:,:,None]).reshape(x.shape)
def quant4(w):
 b=w.reshape(-1,64);mx=b[np.arange(len(b)),np.argmax(np.abs(b),axis=1)];d=(mx/np.float32(-8)).astype(np.float16).astype(np.float32);inv=np.divide(1,d,out=np.zeros_like(d),where=d!=0)
 return (np.clip(np.rint(b*inv[:,None]),-8,7)*d[:,None]).reshape(w.shape)
def rel(a,b):return float(np.sum((a.astype(np.float64)-b)**2)/np.sum(a.astype(np.float64)**2))
def split():
 meta=json.loads(pathlib.Path('phase4b/models/residual-capture/manifest.json').read_text())
 tr=np.array([s['document']<12 for s in meta['samples']]);return tr,~tr
if __name__=='__main__':
 tr,va=split();q4=Image('phase2/models/q4-lane8.bin');q3=Image('phase2/models/q2ffn-lane8.bin');records=[]
 for l in [0,14,27]:
  for stage in ['gate_up','down']:
   name=f'{l}.{stage}';r,c=q3.records[name]['shape'];x=q8(np.fromfile(f'phase3/models/calibration/{name}.f32',dtype='<f4').reshape(-1,c));ids=np.linspace(0,r-1,256,dtype=int)
   delta=q4.values(name,ids)-q3.values(name,ids);pace()
   importance=np.mean(x[tr].astype(np.float64)**2,axis=0)*np.sum(delta.astype(np.float64)**2,axis=0)
   order=np.argsort(-importance,kind='stable');y=x@delta.T;pace()
   for k in [64,128]:
    sel=np.sort(order[:k]);z=q8(x[:,sel]);f=z[tr].astype(np.float64);v=z[va].astype(np.float64);g=f.T@f;scale=np.sqrt(np.maximum(np.diag(g),1e-20));g/=scale[:,None]*scale[None,:];rhs=(f/scale).T@y[tr];pace()
    for damping in [.01,.1,1.]:
     coef=np.linalg.solve(g+damping*np.eye(k),rhs)/scale[:,None];coef=quant4(coef.T.astype(np.float32)).T;pred=v@coef;pace()
     rec={'layer':l,'stage':stage,'columns':k,'damping':damping,'heldout_residual_fraction':rel(y[va],pred),'raw_column_residual_fraction':rel(y[va],v@delta[:,sel].T),'uncorrected_error_over_q4_response':float(np.sum(y[va].astype(np.float64)**2)/np.sum((x[va]@q4.values(name,ids).T).astype(np.float64)**2)),'sample_output_rows':256,'correction_bpw':4.5*k/c,'training_vectors':int(tr.sum()),'validation_vectors':int(va.sum())};records.append(rec);print(json.dumps(rec),flush=True)
 pathlib.Path('phase5/results/channel-probe-q2.json').write_text(json.dumps(records,indent=2))
