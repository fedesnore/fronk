from run import run
import subprocess,sys
subprocess.run([sys.executable,'phase5/tools/run_repeats.py'],check=True)
run('assembly',60,['python3','phase5/tools/dump_asm.py'])
run('final-artifact-hashes',180,['python3','phase5/tools/inventory.py'])
