#pragma once
struct Q3Tables {alignas(16) uint8_t lo[16][16],hi[16][16];};
static void prepare_q3_tables(const X8*x,Q3Tables*t,int groups){
 for(int g=0;g<groups;g++)for(int j=0;j<16;j++)for(int code=0;code<16;code++){
  int sum=0;for(int k=0;k<4;k++)if(code&(1<<k))sum+=x[g].q[j*4+k];
  t[g].lo[j][code]=uint16_t(sum)&255;t[g].hi[j][code]=uint16_t(sum)>>8;
 }
}
template<int R> __attribute__((noinline)) static void q3_lut_dot(const uint8_t*w,const X8*x,const Q3Tables*t,int groups,float*out){
 constexpr int S=R/8,bytes=224;__m256 total[S];for(int s=0;s<S;s++)total[s]=_mm256_setzero_ps();
 const auto mask=_mm256_set1_epi8(3),ones=_mm256_set1_epi16(1);const auto nibble=_mm_set1_epi8(15);
 for(int g=0;g<groups;g++){
  __m256i low[S];__m128i high[S];for(int s=0;s<S;s++){low[s]=_mm256_setzero_si256();high[s]=_mm_setzero_si128();}
  for(int j=0;j<4;j++){
   auto x0=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16)),x1=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+4));
   auto x2=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+8)),x3=_mm256_set1_epi32(*(const int32_t*)(x[g].q+j*16+12));
   for(int s=0;s<S;s++){
    auto q=_mm256_loadu_si256((const __m256i*)(w+(g*S+s)*bytes+32+j*32));
    auto a=_mm256_maddubs_epi16(_mm256_and_si256(q,mask),x0),b=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,2),mask),x1);
    auto c=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,4),mask),x2),d=_mm256_maddubs_epi16(_mm256_and_si256(_mm256_srli_epi16(q,6),mask),x3);
    low[s]=_mm256_add_epi32(low[s],_mm256_madd_epi16(_mm256_add_epi16(_mm256_add_epi16(a,b),_mm256_add_epi16(c,d)),ones));
   }
  }
  #pragma GCC unroll 1
  for(int j=0;j<16;j++){
   auto tl=_mm_load_si128((const __m128i*)t[g].lo[j]),th=_mm_load_si128((const __m128i*)t[g].hi[j]);
   for(int s=0;s<S;s++){
    auto h=_mm_cvtsi32_si128(*(const int32_t*)(w+(g*S+s)*bytes+160+j*4));
    auto ix=_mm_and_si128(_mm_unpacklo_epi32(h,_mm_srli_epi32(h,4)),nibble);
    auto v=_mm_unpacklo_epi8(_mm_shuffle_epi8(tl,ix),_mm_shuffle_epi8(th,ix));high[s]=_mm_add_epi16(high[s],v);
   }
  }
  auto correction=_mm256_set1_epi32(x[g].sum*4),xd=_mm256_castps_si256(_mm256_set1_ps(x[g].d));
  for(int s=0;s<S;s++){
   auto dot=_mm256_sub_epi32(_mm256_add_epi32(low[s],_mm256_slli_epi32(_mm256_cvtepi16_epi32(high[s]),2)),correction);
   auto scale=_mm256_mul_ps(_mm256_loadu_ps((const float*)(w+(g*S+s)*bytes)),_mm256_castsi256_ps(xd));total[s]=_mm256_fmadd_ps(_mm256_cvtepi32_ps(dot),scale,total[s]);
  }
 }
 for(int s=0;s<S;s++)_mm256_storeu_ps(out+s*8,total[s]);
}
