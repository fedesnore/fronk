import sys,pathlib,json,hashlib
sys.path.insert(0,'phase5/runtime')
from infer import Engine
from sampled_lookup import SampledLookupEngine
cases=json.loads(pathlib.Path('phase5/tests/quality_cases.json').read_text())
temperature=float(sys.argv[1]);seed=int(sys.argv[2]);which=sys.argv[3];out=pathlib.Path(f'phase5/results/sampled-{temperature}-{seed}-{which}.jsonl');cls=Engine if which=='serial' else SampledLookupEngine
kw={} if which=='serial' else {'lookahead':4,'min_match':4}
e=cls('phase2/models/q4-lane8.bin','models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=2048,kernel=4,prefill='batch',**kw)
try:
 with out.open('x') as f:
  for i,c in enumerate(cases):
   ids=[]
   for ev in e.generate(c['prompt'],max_tokens=192,temperature=temperature,seed=seed+i):
    if ev['event']=='token':ids.append(ev['token_id'])
   r={'case':i,'temperature':temperature,'seed':seed+i,'implementation':which,'token_ids':ids,'metrics':ev};f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush();print(json.dumps({'case':i,'tokens':len(ids),'decode_s':ev['decode_wall_s'],'passes':ev.get('target_graph_passes'),'accepted':ev.get('matched_draft_tokens')}),flush=True)
finally:e.close()
