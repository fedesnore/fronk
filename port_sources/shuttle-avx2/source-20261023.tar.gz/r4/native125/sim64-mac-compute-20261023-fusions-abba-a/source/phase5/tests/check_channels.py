"""Independent integer reference for the new correction datapath on all 56 real matrices."""
import sys,pathlib,json,ctypes
import numpy as np
sys.path.insert(0,'phase5/runtime');from infer import Engine
from image_reader import Image
path='phase5/models/q3-cardinal64-q4.bin';im=Image(path);e=Engine(path,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=64,kernel=4)
lib=e.lib;lib.shuttle_channel_probe.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p];lib.shuttle_channel_probe.restype=ctypes.c_int;e.close()
maximum=0
for l in range(28):
 for stage in ['gate_up','down']:
  name=f'{l}.{stage}';t=im.records[name];r,c=t['shape'];cr=t['cardinal'];x=np.fromfile(f'phase3/models/calibration/{name}.f32',dtype='<f4',count=c);actual=np.empty(r,np.float32)
  assert lib.shuttle_channel_probe(path.encode(),l,int(stage=='down'),x.ctypes.data,actual.ctypes.data)==0
  b=x.reshape(-1,64);mx=np.max(np.abs(b),axis=1);d=mx/np.float32(127);inv=np.divide(127,mx,out=np.zeros_like(mx),where=mx!=0);xq=(np.clip(np.rint(b*inv[:,None]),-127,127)*d[:,None]).ravel();z=xq[cr['indices']].reshape(-1,64);mx=np.max(np.abs(z),axis=1);dz=mx/np.float32(127);inv=np.divide(127,mx,out=np.zeros_like(mx),where=mx!=0);qz=np.clip(np.rint(z*inv[:,None]),-127,127).astype(np.int32)
  fake=dict(t,offset=cr['offset'],bits=4,shape=[r,cr['columns']],row_block=8);im.records['correction']=fake;q,sc=im.rows('correction',np.arange(r));iv=(q*qz[None,:,:]).sum(axis=2,dtype=np.int32);expected=np.zeros(r,np.float32)
  for g in range(len(dz)):expected=(iv[:,g].astype(np.float64)*(sc[:,g]*dz[g]).astype(np.float64)+expected.astype(np.float64)).astype(np.float32)
  err=np.max(np.abs(actual-expected)/(1+np.abs(expected)));maximum=max(maximum,float(err));assert err<2e-5,(name,float(err))
  print(json.dumps({'tensor':name,'max_error_over_1_plus_reference':float(err),'outputs':r}),flush=True)
print(json.dumps({'all_matrices':56,'max_error':maximum}),flush=True)
