"""Analyze retained JSON evidence only; no model computation."""
import pathlib,json,statistics
root=pathlib.Path('phase5');result=root/'results'
def records(path):
 return [json.loads(l) for l in path.read_text().splitlines() if l.startswith('{')]
out={'guards':{},'safety':{'max_cpu_c':0,'max_nvme_c':0,'throttle_changes':0,'swap_growth_runs':[]},'runs':{},'sampled':{},'images':{}}
for p in sorted(result.glob('*/manifest.json')):
 m=json.loads(p.read_text());out['guards'][p.parent.name]={'status':m['status'],'reason':m.get('reason'),'wall_s':m.get('wall_s')};tele=p.with_name('telemetry.jsonl')
 if not tele.exists():continue
 rows=records(tele);first=rows[0];s=out['safety'];rss=0
 for r in rows:
  s['max_cpu_c']=max(s['max_cpu_c'],max(r['temp_c'].values()));s['max_nvme_c']=max(s['max_nvme_c'],max(r['storage_temp_c'].values()));s['throttle_changes']+=int(r['throttle_counts']!=first['throttle_counts']);rss=max(rss,r.get('child_memory_kib',{}).get('VmHWM',0))
 if min(r['mem_kib']['SwapFree'] for r in rows)<first['mem_kib']['SwapFree']:s['swap_growth_runs'].append(p.parent.name)
 data=records(p.with_name('stdout.txt'));d={'peak_process_hwm_kib':rss}
 metrics=[r for r in data if r.get('event')=='metrics']
 if metrics:
  d['metrics']={k:v for k,v in metrics[-1].items() if k!='response'}
  if metrics[-1].get('counters') and not metrics[-1]['counters']['errno']:
   n=metrics[-1]['decode_steps'];d['instructions_per_step']=metrics[-1]['counters']['instructions']/n;d['thread_cycles_per_step']=metrics[-1]['counters']['thread_cycles']/n
  if metrics[-1].get('imc') and not metrics[-1]['imc']['errno']:
   n=metrics[-1]['decode_steps'];d['dram_bytes_per_step']=(metrics[-1]['imc']['read_bytes']+metrics[-1]['imc']['write_bytes'])/n
 elif data:d['last_record']=data[-1]
 out['runs'][p.parent.name]=d
for temp,seed in [(.7,7),(1.,19)]:
 paths=[result/f'sampled-{temp}-{seed}-{which}.jsonl' for which in ('serial','lookup')]
 if not all(p.exists() for p in paths):continue
 a,b=map(records,paths);assert len(a)==len(b)==8
 assert all(x['token_ids']==y['token_ids'] for x,y in zip(a,b)),('seeded mismatch',temp)
 r={'cases':8,'all_token_ids_exact':True,'tokens':sum(len(x['token_ids']) for x in a)}
 for which,rr in [('serial',a),('lookup',b)]:
  visible=sum(max(0,len(x['token_ids'])-1) for x in rr);seconds=sum(x['metrics']['decode_wall_s'] for x in rr);t={'visible_postprefill_tokens':visible,'decode_s':seconds,'visible_tok_s':visible/seconds,'prefill_s':sum(x['metrics']['prefill_s'] for x in rr)}
  if which=='lookup':
   for k in ['target_graph_passes','target_input_positions','proposed_tokens','matched_draft_tokens']:t[k]=sum(x['metrics'][k] for x in rr)
   t['visible_outputs_per_target_pass']=visible/t['target_graph_passes'];t['intertoken_p95_case_range_ms']=[min(x['metrics']['intertoken_p95_ms'] for x in rr),max(x['metrics']['intertoken_p95_ms'] for x in rr)]
  r[which]=t
 out['sampled'][str(temp)]=r
for p in (root/'models').glob('*.json'):
 m=json.loads(p.read_text())
 if 'sha256' in m:out['images'][p.stem]={k:m[k] for k in ['sha256','file_bytes','total_matrix_effective_bpw','correction_bytes_including_indices','total_active_matrix_bytes']}
(result/'SUMMARY.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'guards':len(out['guards']),'safety':out['safety'],'sampled':out['sampled'],'images':out['images']},indent=2))
