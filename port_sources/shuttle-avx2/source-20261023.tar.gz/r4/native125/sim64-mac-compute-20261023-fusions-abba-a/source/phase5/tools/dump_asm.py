import pathlib,subprocess
with pathlib.Path('phase5/results/runtime.asm').open('w') as f:subprocess.run(['objdump','-d','-C','-M','intel','phase5/build/libshuttle.so'],stdout=f,check=True)
