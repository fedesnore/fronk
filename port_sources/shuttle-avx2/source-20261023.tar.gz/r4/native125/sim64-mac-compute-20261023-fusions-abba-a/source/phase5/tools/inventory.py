"""Read-only bounded hashing of retained node artifacts; no model computation."""
import pathlib,hashlib,json,socket,time
from guard import Telemetry
assert socket.gethostname().split('.')[0]=='netlab-shuttle09'
root=pathlib.Path('phase5');records={};telemetry=Telemetry();next_check=0.
for folder in ['models','build']:
 for p in sorted((root/folder).rglob('*')):
  if not p.is_file():continue
  h=hashlib.sha256()
  with p.open('rb') as f:
   for block in iter(lambda:f.read(1024*1024),b''):
    h.update(block);time.sleep(.05)
    if time.monotonic()>=next_check:
     while True:
      sample=telemetry.sample()
      if max(sample['temp_c'].values())<60 and max(sample['storage_temp_c'].values())<55:break
      time.sleep(1)
     next_check=time.monotonic()+1
  records[str(p)]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
  print(json.dumps({'file':str(p),'bytes':p.stat().st_size}),flush=True)
out={'hostname':socket.gethostname(),'root':'/home/netlab/shuttle-accelerator','files':records,'total_bytes':sum(r['bytes'] for r in records.values())}
(root/'NODE_ARTIFACTS.json').write_text(json.dumps(out,indent=2));print(json.dumps({'files':len(records),'bytes':out['total_bytes']}),flush=True)
