#!/usr/bin/env python3
"""Small disclosed teacher-forced diagnostic, not a general quality benchmark."""
import argparse,pathlib,sys,json,hashlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'runtime'))
from infer import Engine
from tokenizers import Tokenizer
import numpy as np
p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','score']);p.add_argument('--model',default='models/qwen2.5-1.5b-native.bin');a=p.parse_args()
out=pathlib.Path('results/likelihood-data');out.mkdir(exist_ok=True)
if a.mode=='prepare':
 text=pathlib.Path('tests/calibration.txt').read_text();tok=Tokenizer.from_file('models/qwen2.5-1.5b-source/tokenizer.json');ids=np.asarray(tok.encode(text,add_special_tokens=False).ids,dtype='<i4')
 ids.tofile(out/'tokens.i32');(out/'metadata.json').write_text(json.dumps({'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'tokens':len(ids),'text':text},indent=2));print(len(ids));sys.exit()
ids=np.fromfile(out/'tokens.i32',dtype='<i4');targets=ids[1:];n=len(ids);v=151936
refs={name:np.memmap(out/(name+'.f32'),dtype='<f4',mode='r',shape=(n,v)) for name in ['original-f16','matched-q4']}
def probs(x):
 x=x.astype(np.float64);m=x.max();z=x-m;return z-np.log(np.exp(z).sum())
for name,logits in refs.items():
 nll=[-probs(logits[i])[t] for i,t in enumerate(targets)]
 print(json.dumps({'implementation':name,'targets':len(nll),'mean_nll':float(np.mean(nll)),'perplexity':float(np.exp(np.mean(nll)))}),flush=True)
for kernel in [4]:
 engine=Engine(a.model,'models/qwen2.5-1.5b-source/tokenizer.json',threads=8,context=1024,kernel=kernel)
 nll=[];metrics={name:dict(kl=[],top1=[],rms=[],cos=[]) for name in refs}
 try:
  for i,token in enumerate(ids[:-1]):
   actual=engine.forward(int(token),i).astype(np.float64);lp=probs(actual);nll.append(-lp[targets[i]])
   for name,reference in refs.items():
    ref=reference[i].astype(np.float64);rp=probs(ref);m=metrics[name];m['kl'].append(float(np.sum(np.exp(rp)*(rp-lp))));m['top1'].append(int(actual.argmax()==ref.argmax()));m['rms'].append(float(np.sqrt(np.mean((actual-ref)**2))));m['cos'].append(float(np.dot(actual,ref)/(np.linalg.norm(actual)*np.linalg.norm(ref))))
  print(json.dumps({'implementation':'native','kernel':kernel,'targets':len(nll),'mean_nll':float(np.mean(nll)),'perplexity':float(np.exp(np.mean(nll))),'comparison':{name:{key:float(np.mean(values)) for key,values in m.items()} for name,m in metrics.items()}}),flush=True)
 finally:engine.close()
