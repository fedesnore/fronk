from run import run
import os
os.environ['SHUTTLE_Q4_QUAD']='1'
run('compile-protected-down',300,['python3','phase5/tools/compile_protected_down.py'])
m='phase5/models/q3-cardinal64-protected-down.bin'
run('protected-verify',180,['python3','phase5/tests/check_verify.py',m])
run('protected-likelihood',120,['python3','phase5/tests/check_likelihood.py','score','--model',m])
run('protected-heldout',180,['python3','phase5/tests/heldout.py',m])
run('protected-quality',180,['python3','phase5/tests/run_quality.py',m])
run('protected-sustained-1024',120,['python3','phase5/runtime/infer.py','--model',m,'--kernel','4','--prefill','batch','--max-tokens','1024','--ignore-eos'])
