#pragma once
static void quantize_vector(const float*x,X8*q,int n){
 const auto sign=_mm256_castsi256_ps(_mm256_set1_epi32(0x7fffffff));const auto low=_mm256_set1_epi32(-127),high=_mm256_set1_epi32(127);
 for(int g=0;g<n/64;g++){
  auto vmax=_mm256_setzero_ps();for(int j=0;j<64;j+=8)vmax=_mm256_max_ps(vmax,_mm256_and_ps(_mm256_loadu_ps(x+g*64+j),sign));
  auto m=_mm_max_ps(_mm256_castps256_ps128(vmax),_mm256_extractf128_ps(vmax,1));m=_mm_max_ps(m,_mm_movehl_ps(m,m));m=_mm_max_ss(m,_mm_shuffle_ps(m,m,1));float maxv=_mm_cvtss_f32(m);
  q[g].d=maxv/127;auto inv=_mm256_set1_ps(maxv?127/maxv:0);auto sum=_mm256_setzero_si256();
  for(int j=0;j<64;j+=8){
   auto v=_mm256_min_epi32(high,_mm256_max_epi32(low,_mm256_cvtps_epi32(_mm256_mul_ps(_mm256_loadu_ps(x+g*64+j),inv))));sum=_mm256_add_epi32(sum,v);
   auto s16=_mm_packs_epi32(_mm256_castsi256_si128(v),_mm256_extracti128_si256(v,1));auto s8=_mm_packs_epi16(s16,s16);_mm_storel_epi64((__m128i*)(q[g].q+j),s8);
  }
  auto s=_mm_add_epi32(_mm256_castsi256_si128(sum),_mm256_extracti128_si256(sum,1));s=_mm_hadd_epi32(s,s);s=_mm_hadd_epi32(s,s);q[g].sum=_mm_cvtsi128_si32(s);
 }
}
// Eight YMM accumulators retain 64 output dimensions for the whole context scan.
static void values_register(const uint16_t*v,const float*pr,float*out,int pos,int stride,int hd,float sum){
 for(int j=0;j<hd;j+=64){
  __m256 a[8];for(int z=0;z<8;z++)a[z]=_mm256_setzero_ps();
  for(int t=0;t<=pos;t++){
   auto p=_mm256_set1_ps(pr[t]/sum);
   for(int z=0;z<8;z++)a[z]=_mm256_fmadd_ps(p,_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(v+size_t(t)*stride+j+z*8))),a[z]);
  }
  for(int z=0;z<8;z++)_mm256_storeu_ps(out+j+z*8,a[z]);
 }
}
