"""SHUTLLM6: Q3 dense base + Q4 cardinal response corrections (independent implementation)."""
import sys,pathlib,json,struct,hashlib,time
import numpy as np
from channel_probe import Image,pace,q8,quant4,rel,split
sys.path.insert(0,'phase4b/tools');from pack import pack
def hashed(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  while b:=f.read(1024*1024):h.update(b);pace(.05)
 return h.hexdigest()
def align(f):f.write(bytes((-f.tell())%64))
def encode(w):
 rows,cols=w.shape;b=w.reshape(-1,64);mx=b[np.arange(len(b)),np.argmax(np.abs(b),axis=1)];d=(mx/np.float32(-8)).astype(np.float16).astype(np.float32);inv=np.divide(1,d,out=np.zeros_like(d),where=d!=0);q=np.clip(np.rint(b*inv[:,None]),-8,7).astype(np.int8)
 return pack(d,q.astype(np.int16).__add__(8).astype(np.uint8),rows,cols,4,8),(q*d[:,None]).reshape(w.shape)
q4=Image('phase2/models/q4-lane8.bin');base=Image('phase2/models/q3ffn-lane8.bin');tr,va=split();k=int(sys.argv[1]) if len(sys.argv)>1 else 64
assert k in (64,128)
for im in (q4,base):assert hashed(im.f.name)==im.meta['sha256']
out=pathlib.Path(f'phase5/models/q3-cardinal{k}-q4.bin');f=out.open('xb');h=bytearray(base.mm[:64]);h[:8]=b'SHUTLLM6';struct.pack_into('<I',h,8,6);struct.pack_into('<I',h,44,6);f.write(h);tensors=[];total=0
for old in base.meta['tensors']:
 t=dict(old);name=t['name'];matrix=bool(t['row_block']);corr=None
 if matrix and name.split('.')[-1] in ('gate_up','down'):
  rows,cols=t['shape'];x=q8(np.fromfile(f'phase3/models/calibration/{name}.f32',dtype='<f4').reshape(-1,cols));sample=np.linspace(0,rows-1,256,dtype=int);delta=q4.values(name,sample)-base.values(name,sample);pace()
  imp=np.mean(x[tr].astype(np.float64)**2,axis=0)*np.sum(delta.astype(np.float64)**2,axis=0);sel=np.sort(np.argsort(-imp,kind='stable')[:k]).astype('<u4');z=q8(x[:,sel]);ft=z[tr].astype(np.float64);fv=z[va].astype(np.float64);g=ft.T@ft;scale=np.sqrt(np.maximum(np.diag(g),1e-20));g/=scale[:,None]*scale[None,:];inverse=np.linalg.solve(g+.1*np.eye(k),(ft/scale).T)/scale[:,None];pace()
  chunks=[];before=after=wnorm=werr=0.
  for start in range(0,rows,128):
   ids=np.arange(start,min(rows,start+128));w4=q4.values(name,ids);e=w4-base.values(name,ids);y=x@e.T;coef=(inverse@y[tr]).T.astype(np.float32);raw,recon=encode(coef);chunks.append(raw)
   before+=float(np.sum(y[va].astype(np.float64)**2));after+=float(np.sum((y[va]-fv@recon.T)**2));wnorm+=float(np.sum(coef.astype(np.float64)**2));werr+=float(np.sum((coef.astype(np.float64)-recon)**2));pace(.035)
  corr={'columns':k,'format':'Q4 lane8 group64; selected original-Q8 activations regathered and Q8 quantized','indices':sel.tolist(),'bytes':sum(map(len,chunks)),'fit':{'damping':.1,'train':int(tr.sum()),'validation':int(va.sum()),'heldout_residual_fraction':after/before,'coefficient_quant_relative_mse':werr/wnorm},'raw':chunks};total+=corr['bytes']+4*k
 align(f);t['header_offset']=f.tell()
 if matrix:f.write(base.mm[old['header_offset']:old['header_offset']+32]);align(f)
 t['offset']=f.tell()
 for a in range(0,old['bytes'],1024*1024):f.write(base.mm[old['offset']+a:old['offset']+min(a+1024*1024,old['bytes'])]);pace(.005)
 if matrix:
  align(f);t['cardinal_header_offset']=f.tell();f.write(struct.pack('<IIQQQ',k if corr else 0,1 if corr else 0,corr['bytes'] if corr else 0,0,0))
  if corr:
   align(f);corr['indices_offset']=f.tell();f.write(sel.tobytes());align(f);corr['offset']=f.tell()
   for raw in corr.pop('raw'):f.write(raw)
   t['cardinal']=corr
 tensors.append(t);print(json.dumps({'tensor':name,'correction':corr['fit'] if corr else None}),flush=True)
f.close();meta=dict(base.meta);meta.update(format_version=6,sha256=hashed(out),file_bytes=out.stat().st_size,tensors=tensors,parent_sha256=base.meta['sha256'],quality_reference_sha256=q4.meta['sha256'],correction_bytes_including_indices=total,total_active_matrix_bytes=base.meta['matrix_payload_bytes']+total,total_matrix_effective_bpw=8*(base.meta['matrix_payload_bytes']+total)/base.meta['matrix_parameters'],transformation={'name':'cardinal response correction','columns':k,'coefficient_bits':4,'damping':.1,'target':'Q4 minus Q3 projections on original Q8 activation values','selection':'256 evenly spaced output rows; activation-square times residual column energy; training only','split':'whole documents 0..11 training / 12..15 validation','compiler_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'calibration_manifest_sha256':hashlib.sha256(pathlib.Path('phase3/models/calibration/manifest.json').read_bytes()).hexdigest(),'runtime_source_sha256':hashlib.sha256(pathlib.Path('phase5/runtime/native.cpp').read_bytes()).hexdigest()})
out.with_suffix('.json').write_text(json.dumps(meta,indent=2));print(json.dumps({'artifact':str(out),'bytes':meta['file_bytes'],'bpw':meta['total_matrix_effective_bpw'],'sha256':meta['sha256']}),flush=True)
