#pragma once
// Four positions share unpacked weights. Explicit accumulators; no j unrolling.
// WeightStride is compiled from the execution image, not a runtime tensor stride.
template<int WeightStride,bool Continue> __attribute__((noinline)) static void q4_panel4(const uint8_t*w,const X8*x,int qs,int groups,float*out,int os){
 const X8*x0=x,*x1=x+qs,*x2=x+2*qs,*x3=x+3*qs;
 __m256 t0=Continue?_mm256_loadu_ps(out+0*os):_mm256_setzero_ps();
 __m256 t1=Continue?_mm256_loadu_ps(out+1*os):_mm256_setzero_ps();
 __m256 t2=Continue?_mm256_loadu_ps(out+2*os):_mm256_setzero_ps();
 __m256 t3=Continue?_mm256_loadu_ps(out+3*os):_mm256_setzero_ps();
 const __m256i mask=_mm256_set1_epi8(15),ones=_mm256_set1_epi16(1);
 for(int g=0;g<groups;g++){
  __m256i a0=_mm256_setzero_si256();
  __m256i a1=_mm256_setzero_si256();
  __m256i a2=_mm256_setzero_si256();
  __m256i a3=_mm256_setzero_si256();
  #pragma GCC unroll 1
  for(int j=0;j<8;j++){
   auto packed=_mm256_loadu_si256((const __m256i*)(w+size_t(g)*WeightStride+32+j*32));
   auto lo=_mm256_and_si256(packed,mask),hi=_mm256_and_si256(_mm256_srli_epi16(packed,4),mask);
   a0=_mm256_add_epi32(a0,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,_mm256_set1_epi32(*(const int32_t*)(x0[g].q+j*8))),_mm256_maddubs_epi16(hi,_mm256_set1_epi32(*(const int32_t*)(x0[g].q+j*8+4)))),ones));
   a1=_mm256_add_epi32(a1,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,_mm256_set1_epi32(*(const int32_t*)(x1[g].q+j*8))),_mm256_maddubs_epi16(hi,_mm256_set1_epi32(*(const int32_t*)(x1[g].q+j*8+4)))),ones));
   a2=_mm256_add_epi32(a2,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,_mm256_set1_epi32(*(const int32_t*)(x2[g].q+j*8))),_mm256_maddubs_epi16(hi,_mm256_set1_epi32(*(const int32_t*)(x2[g].q+j*8+4)))),ones));
   a3=_mm256_add_epi32(a3,_mm256_madd_epi16(_mm256_add_epi16(_mm256_maddubs_epi16(lo,_mm256_set1_epi32(*(const int32_t*)(x3[g].q+j*8))),_mm256_maddubs_epi16(hi,_mm256_set1_epi32(*(const int32_t*)(x3[g].q+j*8+4)))),ones));
  }
  auto scale=_mm256_loadu_ps((const float*)(w+size_t(g)*WeightStride));
  t0=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(a0,_mm256_set1_epi32(x0[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(x0[g].d)),t0);
  t1=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(a1,_mm256_set1_epi32(x1[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(x1[g].d)),t1);
  t2=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(a2,_mm256_set1_epi32(x2[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(x2[g].d)),t2);
  t3=_mm256_fmadd_ps(_mm256_cvtepi32_ps(_mm256_sub_epi32(a3,_mm256_set1_epi32(x3[g].sum*8))),_mm256_mul_ps(scale,_mm256_set1_ps(x3[g].d)),t3);
 }
 _mm256_storeu_ps(out+0*os,t0);
 _mm256_storeu_ps(out+1*os,t1);
 _mm256_storeu_ps(out+2*os,t2);
 _mm256_storeu_ps(out+3*os,t3);
}
