from run import run
import os
os.environ['SHUTTLE_Q4_QUAD']='1'
for temp,seed in [(.7,7),(1.,19)]:
 for which in (['serial','lookup'] if temp==.7 else ['lookup','serial']):
  run(f'sampled-{temp}-{seed}-{which}',180,['python3','phase5/tests/bench_sampled.py',str(temp),str(seed),which])
