from run import run
import os,subprocess,sys
os.environ['SHUTTLE_Q4_QUAD']='1'
run('base-ablation',120,['python3','phase5/tests/check_base_ablation.py'])
run('q2-channel-screen',120,['python3','phase5/tools/channel_probe_q2.py'])
for task in ['run_protected.py','run_continuation.py','run_sampled.py','run_counters.py']:
 subprocess.run([sys.executable,'phase5/tools/'+task],check=True)
