#pragma once
// Layer-major position blocks. Each dot retains the scalar FP32 reduction order.
template<int P> static void q8_panel(const uint8_t * p,const float *const * x,int n,float * out) {
    __m256 sum[P];for(int t=0;t<P;++t)sum[t]=_mm256_setzero_ps();
    for(int b=0;b<n/32;++b,p+=34) {
        __m256 d=_mm256_set1_ps(half(p));
        for(int j=0;j<32;j+=8) {
            __m256 q=_mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(_mm_loadl_epi64((const __m128i *)(p+2+j))));
            __m256 v=_mm256_mul_ps(d,q);
            for(int t=0;t<P;++t)sum[t]=_mm256_fmadd_ps(v,_mm256_loadu_ps(x[t]+b*32+j),sum[t]);
        }
    }
    for(int t=0;t<P;++t)out[t]=hsum(sum[t]);
}
static void many(const uint8_t * p,const float *const * x,int type,int n,int count,float * out) {
    if(type==12) {
        switch(count) {
            case 1:out[0]=dot(p,x[0],type,n);break;
            case 2:dot_panel<2>(p,x,type,n,out);break;
            case 3:dot_panel<3>(p,x,type,n,out);break;
            case 4:dot_panel<4>(p,x,type,n,out);break;
            case 5:dot_panel<5>(p,x,type,n,out);break;
            case 6:dot_panel<6>(p,x,type,n,out);break;
            case 7:dot_panel<7>(p,x,type,n,out);break;
            case 8:dot_panel<8>(p,x,type,n,out);break;
        }
    } else {
        switch(count) {
            case 1:out[0]=dot(p,x[0],type,n);break;
            case 2:q8_panel<2>(p,x,n,out);break;
            case 3:q8_panel<3>(p,x,n,out);break;
            case 4:q8_panel<4>(p,x,n,out);break;
            case 5:q8_panel<5>(p,x,n,out);break;
            case 6:q8_panel<6>(p,x,n,out);break;
            case 7:q8_panel<7>(p,x,n,out);break;
            case 8:q8_panel<8>(p,x,n,out);break;
        }
    }
}
static void many_row(const Weight & w,int r,const float *const * x,int count,float * out) {
    if(w.type==0){for(int t=0;t<count;++t)out[t]=row(w,r,x[t]);return;}
    many(w.p+size_t(r)*rb(w.type,w.columns),x,w.type,w.columns,count,out);
}
extern "C" int r3_native_commit(Stage * s,int keep) {
    if(!s || !s->valid || !s->pending_count || keep<0 || keep>s->pending_count)return 1;
    const int end=s->pending_start+s->pending_count,retained=s->pending_start+keep;
    #pragma omp parallel for num_threads(s->threads) schedule(static)
    for(int il=0;il<s->last-s->first;++il) {
        auto & l=s->layers[il];
        if(l.recurrent) {
            memcpy(l.state.data(),l.saved_state.data()+keep*l.state.size(),l.state.size()*4);
            memcpy(l.conv.data(),l.saved_conv.data()+keep*l.conv.size(),l.conv.size()*4);
        } else {
            std::fill(l.key.begin()+retained*512,l.key.begin()+end*512,0);
            std::fill(l.value.begin()+retained*512,l.value.begin()+end*512,0);
        }
    }
    s->position=retained;s->pending_count=0;return 0;
}
extern "C" int r3_native_run(Stage * stage,const float * input,float * output,int count,int position) {
    if(!stage || !stage->valid || !input || !output || count<1 || count>8 || position!=stage->position || position+count>stage->ctx)return 1;
    if(count==1){stage->pending_count=0;return r3_native_run_serial(stage,input,output,count,position);}
    for(int i=0;i<count*2048;++i)if(!std::isfinite(input[i]))return 2;
    stage->pending_start=position;stage->pending_count=count;
    #pragma omp parallel num_threads(stage->threads)
    {
        #pragma omp for schedule(static)
        for(int t=0;t<count;++t)memcpy(stage->block[t].x,input+t*2048,8192);
        for(int il=stage->first;il<stage->last;++il) {
            auto & l=stage->layers[il-stage->first];auto & w=l.w;
            #pragma omp single
            {stage->layer_start=ns();stage->stamp=ns();}
            #pragma omp for schedule(static)
            for(int t=0;t<count;++t)rms(stage->block[t].x,stage->block[t].norm,w[AN].f(),2048);
            #pragma omp for schedule(static)
            for(int h=0;h<(l.recurrent?32:0);++h) {
                memcpy(l.saved_state.data()+h*128*128,l.state.data()+h*128*128,128*128*4);
                memcpy(l.saved_conv.data()+h*768,l.conv.data()+h*768,768*4);
            }
            #pragma omp for schedule(static)
            for(int j=0;j<(l.recurrent?12352:9216);++j) {
                const float * x[8];float v[8];for(int t=0;t<count;++t)x[t]=stage->block[t].norm;
                int kind,r;
                if(l.recurrent) {kind=j<8192?QKV:j<12288?Z:j<12320?ALPHA:BETA;r=j<(8192)?j:j<12288?j-8192:j<12320?j-12288:j-12320;}
                else {kind=j<8192?Q:j<8704?K:V;r=j<8192?j:j<8704?j-8192:j-8704;}
                many_row(w[kind],r,x,count,v);
                for(int t=0;t<count;++t) {
                    auto & s=stage->block[t];float * dest=kind==QKV||kind==Q?s.qkv:kind==Z?s.z:kind==ALPHA?s.alpha:kind==BETA?s.beta:kind==K?s.key:s.value;
                    dest[r]=v[t];
                }
            }
            #pragma omp single
            {l.nanos[0]+=ns()-stage->stamp;stage->stamp=ns();}
            for(int token=0;token<count;++token) {
                auto * s=&stage->block[token];
                if(l.recurrent) {
                    #include "block_recurrent.inc"
                    #pragma omp for schedule(static)
                    for(int h=0;h<32;++h) {
                        memcpy(l.saved_state.data()+(token+1)*l.state.size()+h*128*128,l.state.data()+h*128*128,128*128*4);
                        memcpy(l.saved_conv.data()+(token+1)*l.conv.size()+h*768,l.conv.data()+h*768,768*4);
                    }
                } else {
                    #include "block_attention.inc"
                }
            }
            #pragma omp single
            {l.nanos[1]+=ns()-stage->stamp;stage->stamp=ns();}
            #pragma omp for schedule(static)
            for(int j=0;j<2048;++j) {
                const float * x[8];float v[8];for(int t=0;t<count;++t)x[t]=stage->block[t].attn;
                many_row(w[l.recurrent?SO:O],j,x,count,v);
                for(int t=0;t<count;++t)stage->block[t].projected[j]=v[t];
            }
            #pragma omp single
            {l.nanos[0]+=ns()-stage->stamp;stage->stamp=ns();}
            #pragma omp for schedule(static)
            for(int t=0;t<count;++t) {
                auto * s=&stage->block[t];for(int j=0;j<2048;++j)s->x[j]+=s->projected[j];rms(s->x,s->norm,w[PN].f(),2048);
            }
            #pragma omp for schedule(static)
            for(int task=0;task<count*256;++task)stage->block[task/256].scores[task%256]=row(w[ROUTER],task%256,stage->block[task/256].norm);
            #pragma omp for schedule(static)
            for(int token=0;token<count;++token) {
                auto * s=&stage->block[token];
                #include "block_router.inc"
                if(stage->trace_norm){size_t i=token*(stage->last-stage->first)+il-stage->first;memcpy(stage->trace_norm+i*2048,s->norm,8192);memcpy(stage->trace_ids+i*8,s->ids,32);}
            }
            #pragma omp single
            {
                int jobs[64];for(int i=0;i<count*8;++i)jobs[i]=i;
                auto expert=[&](int job){return stage->block[job/8].ids[job%8];};
                std::sort(jobs,jobs+count*8,[&](int a,int b){return expert(a)<expert(b)||(expert(a)==expert(b)&&a<b);});
                stage->group_count=0;
                for(int i=0;i<count*8;++i) {
                    int job=jobs[i],e=expert(job);
                    if(!stage->group_count || stage->groups[stage->group_count-1].expert!=e)stage->groups[stage->group_count++]={e,0,{}};
                    auto & group=stage->groups[stage->group_count-1];group.jobs[group.count++]=job;
                }
                l.nanos[4]+=ns()-stage->stamp;stage->stamp=ns();
            }
            #pragma omp for schedule(static)
            for(int gr=0;gr<stage->group_count*512;++gr) {
                auto & group=stage->groups[gr/512];int r=gr%512;const float * x[8];float g[8],u[8];
                for(int t=0;t<group.count;++t)x[t]=stage->block[group.jobs[t]/8].norm;
                many(w[EG].p+size_t(group.expert)*589824+size_t(r)*rb(12,2048),x,12,2048,group.count,g);
                many(w[EU].p+size_t(group.expert)*589824+size_t(r)*rb(12,2048),x,12,2048,group.count,u);
                for(int t=0;t<group.count;++t)stage->block[group.jobs[t]/8].mid[(group.jobs[t]%8)*512+r]=silu(g[t])*u[t];
            }
            #pragma omp for schedule(static)
            for(int gr=0;gr<stage->group_count*2048;++gr) {
                auto & group=stage->groups[gr/2048];int r=gr%2048;const float * x[8];float v[8];
                for(int t=0;t<group.count;++t)x[t]=stage->block[group.jobs[t]/8].mid+(group.jobs[t]%8)*512;
                many(w[ED].p+size_t(group.expert)*589824+size_t(r)*rb(12,512),x,12,512,group.count,v);
                for(int t=0;t<group.count;++t)stage->block[group.jobs[t]/8].out[(group.jobs[t]%8)*2048+r]=v[t];
            }
            #pragma omp single
            {l.nanos[2]+=ns()-stage->stamp;stage->stamp=ns();}
            #pragma omp for schedule(static)
            for(int r=0;r<512;++r) {
                const float * x[8];float g[8],u[8];for(int t=0;t<count;++t)x[t]=stage->block[t].norm;
                many_row(w[SG],r,x,count,g);many_row(w[SU],r,x,count,u);
                for(int t=0;t<count;++t)stage->block[t].shared[r]=silu(g[t])*u[t];
            }
            #pragma omp for schedule(static)
            for(int r=0;r<2048;++r) {
                const float * x[8];float v[8];for(int t=0;t<count;++t)x[t]=stage->block[t].shared;
                many_row(w[SD],r,x,count,v);
                for(int t=0;t<count;++t)stage->block[t].shared_out[r]=v[t]*stage->block[t].shared_gate;
            }
            #pragma omp single
            {l.nanos[3]+=ns()-stage->stamp;stage->stamp=ns();}
            #pragma omp for schedule(static)
            for(int token=0;token<count;++token) {
                auto * s=&stage->block[token];
                for(int j=0;j<2048;++j){float v=s->out[j]*s->route[0];for(int k=1;k<8;++k)v+=s->out[k*2048+j]*s->route[k];v+=s->shared_out[j];s->x[j]+=v;}
                if(stage->trace_out)memcpy(stage->trace_out+(token*(stage->last-stage->first)+il-stage->first)*2048,s->x,8192);
            }
            #pragma omp single
            {l.nanos[4]+=ns()-stage->stamp;l.nanos[5]+=ns()-stage->layer_start;}
        }
        #pragma omp for schedule(static)
        for(int t=0;t<count;++t)memcpy(output+t*2048,stage->block[t].x,8192);
    }
    for(int i=0;i<count*2048;++i)if(!std::isfinite(output[i])){stage->valid=false;return 3;}
    stage->position+=count;stage->calls+=count;return 0;
}
