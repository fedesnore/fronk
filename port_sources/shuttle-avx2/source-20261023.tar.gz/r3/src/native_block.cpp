// Retain the qualified Q4_K panel arithmetic and add the actual Qwen3.6 stage.
#define main r3_unused_preserved_worker_main
#include "../../phase6/src/worker.cpp"
#undef main
#include <array>
#include <memory>
#include <string>

enum Kind { AN, PN, ROUTER, EG, EU, ED, SG, SU, SD, SHG, QKV, Z, ALPHA,
            BETA, CONV, DT, A, SN, SO, Q, K, V, O, QN, KN, NKIND };
struct Desc { uint64_t offset, bytes; uint32_t layer, kind, type, columns, rows; };
struct Weight {
    const uint8_t * p=nullptr; int type=0, columns=0, rows=0;
    const float * f() const { return reinterpret_cast<const float *>(p); }
};
static float f32dot(const float * a,const float * b,int n) {
    __m256 s=_mm256_setzero_ps();
    for(int i=0;i<n;i+=8) s=_mm256_fmadd_ps(_mm256_loadu_ps(a+i),_mm256_loadu_ps(b+i),s);
    return hsum(s);
}
static float row(const Weight & w,int r,const float * x) {
    if(w.type==0) return f32dot(w.f()+size_t(r)*w.columns,x,w.columns);
    return dot(w.p+size_t(r)*rb(w.type,w.columns),x,w.type,w.columns);
}
static void rms(const float * x,float * y,const float * weight,int n,float eps=1e-6f) {
    float scale=1.f/sqrtf(f32dot(x,x,n)/n+eps);
    for(int i=0;i<n;++i) y[i]=(x[i]*scale)*(weight?weight[i]:1.f);
}
static float sigmoid(float v) { return 1.f/(1.f+expf(-v)); }
static void rope(float * x,int pos) {
    // Text positions have identical IMRoPE temporal/height/width components.
    for(int i=0;i<32;++i) {
        float angle=float(pos)*powf(10000000.f,-float(2*i)/64.f);
        float c=cosf(angle),s=sinf(angle),a=x[i],b=x[i+32];
        x[i]=a*c-b*s; x[i+32]=a*s+b*c;
    }
}
struct Layer {
    std::array<Weight,NKIND> w;
    std::vector<float> conv, state, saved_conv, saved_state;
    std::vector<uint16_t> key,value;
    bool recurrent;
    std::array<uint64_t,6> nanos{}; // projections, state, routed, shared, glue, full layer
};
struct alignas(64) Position {
    alignas(64) float x[2048],norm[2048],qkv[8192],z[4096],convolved[8192];
    alignas(64) float attn[4096],projected[2048],alpha[32],beta[32],query[4096],key[512],value[512];
    alignas(64) float scores[256],prob[256],route[8],mid[8*512],out[8*2048],shared[512],shared_out[2048];
    int ids[8],order[8]; float shared_gate=0;
};
struct alignas(64) Stage : Position {
    int first,last,ctx,threads,position=0; bool valid=true;
    std::vector<Layer> layers;
    std::array<Position,8> block;
    struct Group {int expert,count,jobs[8];};
    std::array<Group,64> groups;
    int group_count=0,pending_start=0,pending_count=0;
    std::vector<float> attn_scores;
    uint64_t stamp=0,layer_start=0,calls=0;
    float * trace_norm=nullptr,* trace_out=nullptr; int * trace_ids=nullptr;
    Stage(int a,int b,int c,int t):first(a),last(b),ctx(c),threads(t),layers(b-a),attn_scores(16*c) {}
};

extern "C" void * r3_native_open(const uint8_t * base,uint64_t bytes,const Desc * desc,
                                  uint32_t count,int first,int last,int context,int threads) {
    if(!base || !desc || first<0 || last>40 || first>=last || context!=2048 || threads<1 || threads>8) return nullptr;
    std::unique_ptr<Stage> s(new Stage(first,last,context,threads));
    for(uint32_t i=0;i<count;++i) {
        auto & d=desc[i];
        if(d.layer<uint32_t(first) || d.layer>=uint32_t(last)) continue;
        if(d.kind>=NKIND || d.offset>bytes || d.bytes>bytes-d.offset || (d.type!=0 && d.type!=8 && d.type!=12)) return nullptr;
        auto & w=s->layers[d.layer-first].w[d.kind];
        if(w.p) return nullptr;
        w={base+d.offset,int(d.type),int(d.columns),int(d.rows)};
    }
    for(int il=first;il<last;++il) {
        auto & l=s->layers[il-first]; l.recurrent=(il+1)%4!=0;
        const int common[]={AN,PN,ROUTER,EG,EU,ED,SG,SU,SD,SHG};
        for(int k:common) if(!l.w[k].p) return nullptr;
        if(l.recurrent) {
            for(int k=QKV;k<=SO;++k) if(!l.w[k].p) return nullptr;
            l.conv.resize(8192*3); l.state.resize(32*128*128);
            l.saved_conv.resize(9*l.conv.size());l.saved_state.resize(9*l.state.size());
        } else {
            for(int k=Q;k<NKIND;++k) if(!l.w[k].p) return nullptr;
            l.key.resize(context*512); l.value.resize(context*512);
        }
    }
    omp_set_dynamic(0); omp_set_num_threads(threads);
    return s.release();
}

extern "C" int r3_native_run_serial(Stage * s,const float * input,float * output,int count,int position) {
    if(!s || !s->valid || !input || !output || count<1 || count>8 || position!=s->position || position+count>s->ctx) return 1;
    for(int i=0;i<count*2048;++i) if(!std::isfinite(input[i])) return 2;
    #pragma omp parallel num_threads(s->threads)
    {
        for(int token=0;token<count;++token) {
            #pragma omp single
            memcpy(s->x,input+token*2048,8192);
            for(int il=s->first;il<s->last;++il) {
                auto & l=s->layers[il-s->first]; auto & w=l.w;
                #pragma omp single
                { s->layer_start=ns(); rms(s->x,s->norm,w[AN].f(),2048); s->stamp=ns(); }
                if(l.recurrent) {
                    #pragma omp for schedule(static)
                    for(int j=0;j<12352;++j) {
                        if(j<8192) s->qkv[j]=row(w[QKV],j,s->norm);
                        else if(j<12288) s->z[j-8192]=row(w[Z],j-8192,s->norm);
                        else if(j<12320) s->alpha[j-12288]=row(w[ALPHA],j-12288,s->norm);
                        else s->beta[j-12320]=row(w[BETA],j-12320,s->norm);
                    }
                    #pragma omp single
                    { l.nanos[0]+=ns()-s->stamp; s->stamp=ns(); }
                    #pragma omp for schedule(static)
                    for(int j=0;j<8192;++j) {
                        float * history=l.conv.data()+3*j; const float * k=w[CONV].f()+4*j;
                        float a=history[0]*k[0]; a+=history[1]*k[1];a+=history[2]*k[2];a+=s->qkv[j]*k[3];
                        history[0]=history[1];history[1]=history[2];history[2]=s->qkv[j];
                        s->convolved[j]=silu(a);
                    }
                    #pragma omp for schedule(static)
                    for(int h=0;h<32;++h) {
                        float * q=s->convolved+h*128;
                        rms(q,q,nullptr,128,1e-6f/128.f);
                        for(int i=0;i<128;++i)q[i]*=1.f/sqrtf(128.f);
                    }
                    #pragma omp for schedule(static)
                    for(int h=0;h<32;++h) {
                        const float * q=s->convolved+(h%16)*128;
                        const float * k=s->convolved+2048+(h%16)*128;
                        const float * v=s->convolved+4096+h*128;
                        float a=s->alpha[h]+w[DT].f()[h];
                        float sp=a>20.f?a:log1pf(expf(a));
                        float decay=expf(sp*w[A].f()[h]); float beta=sigmoid(s->beta[h]);
                        __m256 vd=_mm256_set1_ps(decay);
                        for(int j=0;j<128;++j) {
                            float * state=l.state.data()+(h*128+j)*128;
                            __m256 dotk=_mm256_setzero_ps();
                            for(int i=0;i<128;i+=8) {
                                __m256 vstate=_mm256_mul_ps(_mm256_loadu_ps(state+i),vd);
                                _mm256_storeu_ps(state+i,vstate);
                                dotk=_mm256_fmadd_ps(vstate,_mm256_loadu_ps(k+i),dotk);
                            }
                            float delta=(v[j]-hsum(dotk))*beta; __m256 dd=_mm256_set1_ps(delta),dotq=_mm256_setzero_ps();
                            for(int i=0;i<128;i+=8) {
                                __m256 vstate=_mm256_add_ps(_mm256_loadu_ps(state+i),_mm256_mul_ps(dd,_mm256_loadu_ps(k+i)));
                                _mm256_storeu_ps(state+i,vstate);
                                dotq=_mm256_fmadd_ps(vstate,_mm256_loadu_ps(q+i),dotq);
                            }
                            s->attn[h*128+j]=hsum(dotq)*(1.f/sqrtf(128.f));
                        }
                        rms(s->attn+h*128,s->attn+h*128,w[SN].f(),128);
                        for(int j=0;j<128;++j)s->attn[h*128+j]*=silu(s->z[h*128+j]);
                    }
                    #pragma omp single
                    { l.nanos[1]+=ns()-s->stamp; s->stamp=ns(); }
                    #pragma omp for schedule(static)
                    for(int j=0;j<2048;++j)s->projected[j]=row(w[SO],j,s->attn);
                } else {
                    #pragma omp for schedule(static)
                    for(int j=0;j<9216;++j) {
                        if(j<8192)s->qkv[j]=row(w[Q],j,s->norm);
                        else if(j<8704)s->key[j-8192]=row(w[K],j-8192,s->norm);
                        else s->value[j-8704]=row(w[V],j-8704,s->norm);
                    }
                    #pragma omp single
                    { l.nanos[0]+=ns()-s->stamp; s->stamp=ns(); }
                    #pragma omp for schedule(static)
                    for(int h=0;h<18;++h) {
                        if(h<16) {
                            float * q=s->query+h*256;rms(s->qkv+h*512,q,w[QN].f(),256);rope(q,position+token);
                            // Match the retained Metal flash-attention query staging type.
                            for(int j=0;j<256;j+=8)_mm256_storeu_ps(q+j,_mm256_cvtph_ps(_mm256_cvtps_ph(_mm256_loadu_ps(q+j),0)));
                        }
                        else {rms(s->key+(h-16)*256,s->key+(h-16)*256,w[KN].f(),256);rope(s->key+(h-16)*256,position+token);}
                    }
                    #pragma omp for schedule(static)
                    for(int j=0;j<512;++j) {
                        l.key[(position+token)*512+j]=_cvtss_sh(s->key[j],0);
                        l.value[(position+token)*512+j]=_cvtss_sh(s->value[j],0);
                    }
                    #pragma omp for schedule(static)
                    for(int h=0;h<16;++h) {
                        const float * q=s->query+h*256; float * scores=s->attn_scores.data()+h*s->ctx;
                        float maximum=-INFINITY;
                        for(int t=0;t<=position+token;++t) {
                            const auto * k=l.key.data()+t*512+(h/8)*256; __m256 sum=_mm256_setzero_ps();
                            for(int i=0;i<256;i+=8)sum=_mm256_fmadd_ps(_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)(k+i))),_mm256_loadu_ps(q+i),sum);
                            scores[t]=hsum(sum)*(1.f/16.f);maximum=std::max(maximum,scores[t]);
                        }
                        double total=0;for(int t=0;t<=position+token;++t) {scores[t]=expf(scores[t]-maximum);total+=scores[t];}
                        for(int j=0;j<256;j+=8) {
                            __m256 sum=_mm256_setzero_ps();
                            for(int t=0;t<=position+token;++t) {
                                const auto * v=l.value.data()+t*512+(h/8)*256+j;
                                sum=_mm256_fmadd_ps(_mm256_set1_ps(scores[t]/float(total)),_mm256_cvtph_ps(_mm_loadu_si128((const __m128i*)v)),sum);
                            }
                            _mm256_storeu_ps(s->attn+h*256+j,sum);
                        }
                        for(int j=0;j<256;++j)s->attn[h*256+j]*=sigmoid(s->qkv[h*512+256+j]);
                    }
                    #pragma omp single
                    {l.nanos[1]+=ns()-s->stamp;s->stamp=ns();}
                    #pragma omp for schedule(static)
                    for(int j=0;j<2048;++j)s->projected[j]=row(w[O],j,s->attn);
                }
                #pragma omp single
                {l.nanos[0]+=ns()-s->stamp;s->stamp=ns();for(int j=0;j<2048;++j)s->x[j]+=s->projected[j];rms(s->x,s->norm,w[PN].f(),2048);}
                #pragma omp for schedule(static)
                for(int j=0;j<256;++j)s->scores[j]=row(w[ROUTER],j,s->norm);
                #pragma omp single
                {
                    float maximum=*std::max_element(s->scores,s->scores+256);double total=0;
                    for(int j=0;j<256;++j){s->prob[j]=expf(s->scores[j]-maximum);total+=s->prob[j];}
                    for(int j=0;j<256;++j)s->prob[j]/=float(total);
                    for(int slot=0;slot<8;++slot){int id=-1;for(int j=0;j<256;++j){bool used=false;for(int q=0;q<slot;++q)used|=s->ids[q]==j;if(!used && (id<0 || s->prob[j]>s->prob[id]))id=j;}s->ids[slot]=id;}
                    float sum=0;for(int j=0;j<8;++j)sum+=s->prob[s->ids[j]];
                    for(int j=0;j<8;++j){s->route[j]=s->prob[s->ids[j]]/sum;s->order[j]=j;}
                    std::sort(s->order,s->order+8,[&](int a,int b){return s->ids[a]<s->ids[b];});
                    s->shared_gate=sigmoid(f32dot(w[SHG].f(),s->norm,2048));
                    if(s->trace_norm){size_t i=token*(s->last-s->first)+il-s->first;memcpy(s->trace_norm+i*2048,s->norm,8192);memcpy(s->trace_ids+i*8,s->ids,32);}
                    l.nanos[4]+=ns()-s->stamp;s->stamp=ns();
                }
                #pragma omp for schedule(static)
                for(int gr=0;gr<8*512;++gr) {
                    int slot=s->order[gr/512],r=gr%512,e=s->ids[slot];
                    const float * inputs[]={s->norm};float g,u;
                    panel(w[EG].p+size_t(e)*589824+size_t(r)*rb(12,2048),inputs,12,2048,1,&g);
                    panel(w[EU].p+size_t(e)*589824+size_t(r)*rb(12,2048),inputs,12,2048,1,&u);
                    s->mid[slot*512+r]=silu(g)*u;
                }
                #pragma omp for schedule(static)
                for(int gr=0;gr<8*2048;++gr) {
                    int slot=s->order[gr/2048],r=gr%2048,e=s->ids[slot];const float * inputs[]={s->mid+slot*512};
                    panel(w[ED].p+size_t(e)*589824+size_t(r)*rb(12,512),inputs,12,512,1,s->out+slot*2048+r);
                }
                #pragma omp single
                {l.nanos[2]+=ns()-s->stamp;s->stamp=ns();}
                #pragma omp for schedule(static)
                for(int r=0;r<512;++r)s->shared[r]=silu(row(w[SG],r,s->norm))*row(w[SU],r,s->norm);
                #pragma omp for schedule(static)
                for(int r=0;r<2048;++r)s->shared_out[r]=row(w[SD],r,s->shared)*s->shared_gate;
                #pragma omp single
                {
                    l.nanos[3]+=ns()-s->stamp;s->stamp=ns();
                    for(int j=0;j<2048;++j){float v=s->out[j]*s->route[0];for(int k=1;k<8;++k)v+=s->out[k*2048+j]*s->route[k];v+=s->shared_out[j];s->x[j]+=v;}
                    if(s->trace_out)memcpy(s->trace_out+(token*(s->last-s->first)+il-s->first)*2048,s->x,8192);
                    l.nanos[4]+=ns()-s->stamp;l.nanos[5]+=ns()-s->layer_start;
                }
            }
            #pragma omp single
            memcpy(output+token*2048,s->x,8192);
        }
    }
    for(int i=0;i<count*2048;++i)if(!std::isfinite(output[i])){s->valid=false;return 3;}
    s->position+=count;s->calls+=count;return 0;
}
extern "C" void r3_native_reset(Stage * s) {
    if(!s)return;
    for(auto & l:s->layers){std::fill(l.state.begin(),l.state.end(),0);std::fill(l.conv.begin(),l.conv.end(),0);std::fill(l.key.begin(),l.key.end(),0);std::fill(l.value.begin(),l.value.end(),0);l.nanos.fill(0);}
    s->position=0;s->calls=0;s->valid=true;s->pending_count=0;
}
extern "C" int r3_native_metrics(Stage * s,uint64_t * out) {
    if(!s || !out)return 1;
    out[0]=s->calls;out[1]=s->position;
    for(int i=0;i<s->last-s->first;++i)for(int k=0;k<6;++k)out[2+i*6+k]=s->layers[i].nanos[k];return 0;
}
extern "C" uint64_t r3_native_state(Stage * s,int layer,int kind,float * output) {
    if(!s || layer<s->first || layer>=s->last)return 0;auto & l=s->layers[layer-s->first];
    if(kind<2){auto & v=kind==0?l.state:l.conv;if(output)memcpy(output,v.data(),v.size()*4);return v.size();}
    auto & v=kind==2?l.key:l.value;if(output)for(size_t i=0;i<v.size();++i)output[i]=_cvtsh_ss(v[i]);return v.size();
}
extern "C" void r3_native_close(Stage * s) {delete s;}
extern "C" void r3_native_trace(Stage * s,float * norm,float * output,int * ids) {s->trace_norm=norm;s->trace_out=output;s->trace_ids=ids;}

#include "block_execution.h"
